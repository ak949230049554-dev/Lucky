import { HindiTrackId } from '../types/game';

interface TrackPattern {
  stepMs: number;
  bass: number[];
  lead: number[];
  dholKick: number[]; // 1 = low dhol boom, 2 = high tabla/dhol slap, 0 = rest
  leadWave: OscillatorType;
  bassWave: OscillatorType;
  filterHz: number;
}

const TRACK_PATTERNS: Record<HindiTrackId, TrackPattern> = {
  // Upbeat Bollywood Highway Pop (Raag Bilawal / Khamaj vibe, 122 BPM 16th/8th feel)
  desi_highway: {
    stepMs: 175,
    bass: [130.81, 0, 130.81, 146.83, 164.81, 0, 146.83, 130.81, 110, 0, 110, 123.47, 130.81, 146.83, 164.81, 0],
    lead: [523.25, 587.33, 659.25, 0, 783.99, 659.25, 587.33, 523.25, 440, 523.25, 587.33, 659.25, 587.33, 523.25, 493.88, 0],
    dholKick: [1, 0, 2, 1, 2, 0, 1, 2, 1, 0, 2, 1, 2, 2, 1, 0],
    leadWave: 'triangle',
    bassWave: 'sawtooth',
    filterHz: 680,
  },
  // Punjabi Turbo Dhol (Bhangra Tumbi + Dhol Chaal, 132 BPM)
  punjabi_dhol: {
    stepMs: 152,
    bass: [146.83, 146.83, 0, 146.83, 174.61, 0, 164.81, 146.83, 146.83, 146.83, 0, 130.81, 146.83, 0, 196.0, 174.61],
    lead: [587.33, 659.25, 587.33, 698.46, 587.33, 659.25, 523.25, 587.33, 587.33, 783.99, 698.46, 659.25, 587.33, 523.25, 587.33, 0],
    dholKick: [1, 2, 0, 1, 1, 2, 1, 2, 1, 2, 0, 1, 2, 1, 2, 2],
    leadWave: 'sawtooth',
    bassWave: 'triangle',
    filterHz: 840,
  },
  // Mumbai Night Lofi (Raag Yaman — Tivra Ma F#4/F#5 chill night drive)
  mumbai_lofi: {
    stepMs: 225,
    bass: [130.81, 0, 0, 196.0, 146.83, 0, 0, 185.0, 110.0, 0, 0, 164.81, 123.47, 0, 146.83, 0],
    lead: [493.88, 587.33, 739.99, 0, 659.25, 587.33, 493.88, 0, 440.0, 493.88, 587.33, 739.99, 783.99, 739.99, 587.33, 0],
    dholKick: [1, 0, 0, 2, 0, 0, 1, 0, 1, 0, 0, 2, 0, 2, 0, 0],
    leadWave: 'sine',
    bassWave: 'triangle',
    filterHz: 420,
  },
  // 90s Bollywood Retro Synth Groove
  retro_90s: {
    stepMs: 185,
    bass: [110, 0, 164.81, 110, 130.81, 0, 196, 130.81, 146.83, 0, 220, 146.83, 123.47, 0, 185, 164.81],
    lead: [440, 523.25, 659.25, 587.33, 523.25, 0, 493.88, 523.25, 587.33, 659.25, 783.99, 659.25, 587.33, 523.25, 493.88, 440],
    dholKick: [1, 0, 2, 0, 1, 2, 0, 2, 1, 0, 2, 0, 1, 2, 2, 0],
    leadWave: 'square',
    bassWave: 'sawtooth',
    filterHz: 620,
  },
  // Original PolyDrift Arcade Synth
  arcade_synth: {
    stepMs: 180,
    bass: [110, 110, 130.81, 146.83, 98, 98, 130.81, 164.81],
    lead: [440, 0, 523.25, 659.25, 587.33, 0, 523.25, 392],
    dholKick: [1, 0, 2, 0, 1, 0, 2, 0],
    leadWave: 'square',
    bassWave: 'sawtooth',
    filterHz: 540,
  },
};

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicGain: GainNode | null = null;

  // Continuous engine & drift nodes
  private engineOsc: OscillatorNode | null = null;
  private engineSubOsc: OscillatorNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private engineGain: GainNode | null = null;

  private driftNoise: AudioBufferSourceNode | null = null;
  private driftFilter: BiquadFilterNode | null = null;
  private driftGain: GainNode | null = null;

  private sirenOsc: OscillatorNode | null = null;
  private sirenGain: GainNode | null = null;

  private noiseBuffer: AudioBuffer | null = null;
  private sfxMuted = false;
  private musicMuted = false;
  private musicVolume = 0.75;
  private currentTrackId: HindiTrackId = 'desi_highway';
  private customAudioActive = false;

  private musicTimer: number | null = null;
  private musicStep = 0;
  private isPlayingDriveLoop = false;
  private isPreviewingRadio = false;
  private coinCombo = 0;
  private lastCoinTime = 0;

  public unlock(): void {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      try {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.value = 0.76;
        this.masterGain.connect(this.ctx.destination);

        this.sfxGain = this.ctx.createGain();
        this.sfxGain.gain.value = this.sfxMuted ? 0 : 0.85;
        this.sfxGain.connect(this.masterGain);

        this.musicGain = this.ctx.createGain();
        this.musicGain.gain.value = this.getEffectiveMusicGain();
        this.musicGain.connect(this.masterGain);

        this.buildNoiseBuffer();
        this.setupContinuousNodes();
      } catch {
        this.ctx = null;
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  private getEffectiveMusicGain(): number {
    if (this.musicMuted || this.customAudioActive) return 0;
    return 0.34 * this.musicVolume;
  }

  private buildNoiseBuffer(): void {
    if (!this.ctx) return;
    const len = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    this.noiseBuffer = buf;
  }

  private setupContinuousNodes(): void {
    if (!this.ctx || !this.sfxGain) return;

    this.engineFilter = this.ctx.createBiquadFilter();
    this.engineFilter.type = 'lowpass';
    this.engineFilter.frequency.value = 320;
    this.engineFilter.Q.value = 3.2;

    this.engineGain = this.ctx.createGain();
    this.engineGain.gain.value = 0;

    this.engineOsc = this.ctx.createOscillator();
    this.engineOsc.type = 'sawtooth';
    this.engineOsc.frequency.value = 64;

    this.engineSubOsc = this.ctx.createOscillator();
    this.engineSubOsc.type = 'triangle';
    this.engineSubOsc.frequency.value = 32;

    this.engineOsc.connect(this.engineFilter);
    this.engineSubOsc.connect(this.engineFilter);
    this.engineFilter.connect(this.engineGain);
    this.engineGain.connect(this.sfxGain);

    this.engineOsc.start();
    this.engineSubOsc.start();

    if (this.noiseBuffer) {
      this.driftNoise = this.ctx.createBufferSource();
      this.driftNoise.buffer = this.noiseBuffer;
      this.driftNoise.loop = true;

      this.driftFilter = this.ctx.createBiquadFilter();
      this.driftFilter.type = 'bandpass';
      this.driftFilter.frequency.value = 1450;
      this.driftFilter.Q.value = 5.5;

      this.driftGain = this.ctx.createGain();
      this.driftGain.gain.value = 0;

      this.driftNoise.connect(this.driftFilter);
      this.driftFilter.connect(this.driftGain);
      this.driftGain.connect(this.sfxGain);
      this.driftNoise.start();
    }

    this.sirenOsc = this.ctx.createOscillator();
    this.sirenOsc.type = 'triangle';
    this.sirenOsc.frequency.value = 660;
    this.sirenGain = this.ctx.createGain();
    this.sirenGain.gain.value = 0;
    this.sirenOsc.connect(this.sirenGain);
    this.sirenGain.connect(this.sfxGain);
    this.sirenOsc.start();
  }

  public setMuted(sfxMuted: boolean, musicMuted: boolean): void {
    this.sfxMuted = sfxMuted;
    this.musicMuted = musicMuted;
    if (this.ctx && this.sfxGain && this.musicGain) {
      const now = this.ctx.currentTime;
      this.sfxGain.gain.setTargetAtTime(sfxMuted ? 0 : 0.85, now, 0.03);
      this.musicGain.gain.setTargetAtTime(this.getEffectiveMusicGain(), now, 0.05);
    }
  }

  public setMusicConfig(trackId: HindiTrackId, volume: number, customAudioPlaying: boolean): void {
    const trackChanged = this.currentTrackId !== trackId;
    this.currentTrackId = trackId;
    this.musicVolume = Math.max(0, Math.min(1, volume));
    this.customAudioActive = customAudioPlaying;
    if (this.ctx && this.musicGain) {
      this.musicGain.gain.setTargetAtTime(this.getEffectiveMusicGain(), this.ctx.currentTime, 0.04);
    }
    if (trackChanged && (this.isPlayingDriveLoop || this.isPreviewingRadio)) {
      this.stopMusicLoop();
      this.musicStep = 0;
      this.startMusicLoop();
    }
  }

  public setRadioPreview(active: boolean): void {
    this.isPreviewingRadio = active;
    if (active) {
      this.unlock();
      this.startMusicLoop();
    } else if (!this.isPlayingDriveLoop) {
      this.stopMusicLoop();
    }
  }

  public setDriveLoopActive(active: boolean): void {
    this.isPlayingDriveLoop = active;
    if (!active && this.ctx) {
      const now = this.ctx.currentTime;
      this.engineGain?.gain.setTargetAtTime(0, now, 0.06);
      this.driftGain?.gain.setTargetAtTime(0, now, 0.05);
      this.sirenGain?.gain.setTargetAtTime(0, now, 0.06);
      if (!this.isPreviewingRadio) {
        this.stopMusicLoop();
      }
    } else if (active) {
      this.startMusicLoop();
    }
  }

  public updateDrivingAudio(
    rpmNorm: number,
    isDrifting: boolean,
    isBoosting: boolean,
    policeActive: boolean,
    elapsedTime: number
  ): void {
    if (!this.ctx || !this.isPlayingDriveLoop || this.sfxMuted) return;
    const now = this.ctx.currentTime;

    if (this.engineOsc && this.engineSubOsc && this.engineFilter && this.engineGain) {
      const baseHz = 56 + rpmNorm * 138 + (isBoosting ? 36 : 0);
      this.engineOsc.frequency.setTargetAtTime(baseHz, now, 0.04);
      this.engineSubOsc.frequency.setTargetAtTime(baseHz * 0.5, now, 0.04);
      this.engineFilter.frequency.setTargetAtTime(
        280 + rpmNorm * 1250 + (isBoosting ? 700 : 0),
        now,
        0.05
      );
      this.engineGain.gain.setTargetAtTime(isBoosting ? 0.16 : 0.1, now, 0.05);
    }

    if (this.driftGain && this.driftFilter) {
      this.driftGain.gain.setTargetAtTime(isDrifting ? 0.12 : 0, now, 0.04);
      this.driftFilter.frequency.setTargetAtTime(1250 + rpmNorm * 650, now, 0.06);
    }

    if (this.sirenOsc && this.sirenGain) {
      if (policeActive) {
        const wail = 640 + Math.sin(elapsedTime * 5.2) * 230;
        this.sirenOsc.frequency.setTargetAtTime(wail, now, 0.03);
        this.sirenGain.gain.setTargetAtTime(0.065, now, 0.06);
      } else {
        this.sirenGain.gain.setTargetAtTime(0, now, 0.06);
      }
    }
  }

  public playCoin(): void {
    if (!this.ctx || !this.sfxGain || this.sfxMuted) return;
    const now = this.ctx.currentTime;
    if (now - this.lastCoinTime < 0.7) {
      this.coinCombo = Math.min(8, this.coinCombo + 1);
    } else {
      this.coinCombo = 0;
    }
    this.lastCoinTime = now;

    const pitch = 880 * Math.pow(1.06, this.coinCombo);
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(pitch, now);
    osc.frequency.setValueAtTime(pitch * 1.334, now + 0.05);
    g.gain.setValueAtTime(0.18, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.19);
  }

  public playGem(): void {
    if (!this.ctx || !this.sfxGain || this.sfxMuted) return;
    const now = this.ctx.currentTime;
    const notes = [1046.5, 1318.5, 1568, 2093];
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'triangle';
      const t = now + idx * 0.045;
      osc.frequency.setValueAtTime(freq, t);
      g.gain.setValueAtTime(0.16, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.19);
    });
  }

  public playPowerup(): void {
    if (!this.ctx || !this.sfxGain || this.sfxMuted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(340, now);
    osc.frequency.exponentialRampToValueAtTime(1180, now + 0.24);
    g.gain.setValueAtTime(0.14, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.29);
  }

  public playJump(): void {
    if (!this.ctx || !this.sfxGain || this.sfxMuted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(520, now + 0.22);
    g.gain.setValueAtTime(0.2, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.27);
  }

  public playNearMiss(): void {
    if (!this.ctx || !this.sfxGain || !this.noiseBuffer || this.sfxMuted) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(900, now);
    filter.frequency.exponentialRampToValueAtTime(240, now + 0.18);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.14, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
    src.connect(filter);
    filter.connect(g);
    g.connect(this.sfxGain);
    src.start(now);
    src.stop(now + 0.21);
  }

  public playCrash(shieldAbsorbed = false): void {
    if (!this.ctx || !this.sfxGain || this.sfxMuted) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = shieldAbsorbed ? 'triangle' : 'sawtooth';
    osc.frequency.setValueAtTime(shieldAbsorbed ? 420 : 140, now);
    osc.frequency.exponentialRampToValueAtTime(shieldAbsorbed ? 110 : 32, now + 0.32);
    g.gain.setValueAtTime(0.32, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.36);

    if (this.noiseBuffer) {
      const src = this.ctx.createBufferSource();
      src.buffer = this.noiseBuffer;
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(shieldAbsorbed ? 2200 : 1200, now);
      filter.frequency.exponentialRampToValueAtTime(160, now + 0.32);
      const ng = this.ctx.createGain();
      ng.gain.setValueAtTime(0.28, now);
      ng.gain.exponentialRampToValueAtTime(0.001, now + 0.34);
      src.connect(filter);
      filter.connect(ng);
      ng.connect(this.sfxGain);
      src.start(now);
      src.stop(now + 0.35);
    }
  }

  public playUiClick(): void {
    if (!this.ctx || !this.sfxGain || this.sfxMuted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(760, now + 0.045);
    g.gain.setValueAtTime(0.11, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.065);
  }

  private triggerDholHit(kind: number, now: number): void {
    if (!this.ctx || !this.musicGain) return;
    if (kind === 1) {
      // Deep resonant dhol/bayan boom
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(132, now);
      osc.frequency.exponentialRampToValueAtTime(54, now + 0.12);
      g.gain.setValueAtTime(0.36, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
      osc.connect(g);
      g.connect(this.musicGain);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (kind === 2) {
      // Crisp tabla/dhol high slap
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(340, now);
      osc.frequency.exponentialRampToValueAtTime(210, now + 0.065);
      g.gain.setValueAtTime(0.22, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.075);
      osc.connect(g);
      g.connect(this.musicGain);
      osc.start(now);
      osc.stop(now + 0.08);
    }
  }

  private startMusicLoop(): void {
    if (this.musicTimer !== null) return;
    const pat = TRACK_PATTERNS[this.currentTrackId] ?? TRACK_PATTERNS.desi_highway;

    this.musicTimer = window.setInterval(() => {
      if (
        !this.ctx ||
        !this.musicGain ||
        this.musicMuted ||
        this.customAudioActive ||
        (!this.isPlayingDriveLoop && !this.isPreviewingRadio)
      ) {
        return;
      }
      const now = this.ctx.currentTime;
      const curPat = TRACK_PATTERNS[this.currentTrackId] ?? TRACK_PATTERNS.desi_highway;

      // Dhol / Tabla beat
      const dholHit = curPat.dholKick[this.musicStep % curPat.dholKick.length];
      if (dholHit > 0) {
        this.triggerDholHit(dholHit, now);
      }

      // Bassline
      const bassHz = curPat.bass[this.musicStep % curPat.bass.length];
      if (bassHz > 0) {
        const bOsc = this.ctx.createOscillator();
        const bGain = this.ctx.createGain();
        const bFilter = this.ctx.createBiquadFilter();
        bOsc.type = curPat.bassWave;
        bOsc.frequency.setValueAtTime(bassHz, now);
        bFilter.type = 'lowpass';
        bFilter.frequency.setValueAtTime(curPat.filterHz, now);
        bGain.gain.setValueAtTime(0.22, now);
        bGain.gain.exponentialRampToValueAtTime(0.001, now + curPat.stepMs / 1000 * 0.92);
        bOsc.connect(bFilter);
        bFilter.connect(bGain);
        bGain.connect(this.musicGain);
        bOsc.start(now);
        bOsc.stop(now + curPat.stepMs / 1000);
      }

      // Desi melody / Tumbi / Flute hook
      const leadHz = curPat.lead[this.musicStep % curPat.lead.length];
      if (leadHz > 0) {
        const lOsc = this.ctx.createOscillator();
        const lGain = this.ctx.createGain();
        lOsc.type = curPat.leadWave;
        lOsc.frequency.setValueAtTime(leadHz, now);
        lGain.gain.setValueAtTime(0.12, now);
        lGain.gain.exponentialRampToValueAtTime(0.001, now + curPat.stepMs / 1000 * 0.88);
        lOsc.connect(lGain);
        lGain.connect(this.musicGain);
        lOsc.start(now);
        lOsc.stop(now + curPat.stepMs / 1000);
      }

      this.musicStep++;
    }, pat.stepMs);
  }

  private stopMusicLoop(): void {
    if (this.musicTimer !== null) {
      window.clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }

  public dispose(): void {
    this.stopMusicLoop();
    try {
      this.engineOsc?.stop();
      this.engineSubOsc?.stop();
      this.driftNoise?.stop();
      this.sirenOsc?.stop();
      this.ctx?.close();
    } catch {
      // Ignore already stopped audio nodes
    }
    this.ctx = null;
  }
}
