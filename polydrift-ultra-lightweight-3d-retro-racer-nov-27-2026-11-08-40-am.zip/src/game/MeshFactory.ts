import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import { CarSpec } from '../types/game';

export const PLAYER_CAR_GLB_URL =
  'https://raw.githubusercontent.com/ak949230049554-dev/sky/main/scene-v1.glb';

export const CITY_ROAD_GLB_URL =
  'https://raw.githubusercontent.com/ak949230049554-dev/sky/main/free_city_road_layout_mockup.glb';

const TARGET_PLAYER_CAR_LENGTH = 4.65;
const ROAD_SURFACE_CLEARANCE_Y = 0.015;

let sharedGltfLoader: GLTFLoader | null = null;
let sharedDracoLoader: DRACOLoader | null = null;
let cachedPlayerCarTemplate: THREE.Group | null = null;
let cachedPlayerCarPromise: Promise<THREE.Group> | null = null;

function getSharedGltfLoader(): GLTFLoader {
  if (!sharedGltfLoader) {
    sharedDracoLoader = new DRACOLoader();
    sharedDracoLoader.setDecoderPath(
      'https://www.gstatic.com/draco/versioned/decoders/1.5.7/'
    );
    sharedDracoLoader.preload();

    sharedGltfLoader = new GLTFLoader();
    sharedGltfLoader.setDRACOLoader(sharedDracoLoader);
    sharedGltfLoader.setMeshoptDecoder(MeshoptDecoder);
  }
  return sharedGltfLoader;
}

export interface CityRoadAsset {
  root: THREE.Group;
  roadMeshes: THREE.Mesh[];
  bounds: THREE.Box3;
  spawnY: number;
}

/**
 * Loads the custom 3D city road GLB model using GLTFLoader with MeshoptDecoder
 * and DRACOLoader support, aligns the wide main city boulevard to (0, 0, 0)
 * facing straight along -Z, and returns raycastable road meshes & world bounds.
 */
export function loadCityRoadModel(maxAnisotropy: number): Promise<CityRoadAsset> {
  const loader = getSharedGltfLoader();
  return new Promise<CityRoadAsset>((resolve, reject) => {
    loader.load(
      CITY_ROAD_GLB_URL,
      (gltf) => {
        const rawScene = gltf.scene;
        rawScene.updateMatrixWorld(true);

        const roadMeshes: THREE.Mesh[] = [];
        const drivableMeshes: THREE.Mesh[] = [];

        rawScene.traverse((obj) => {
          const mesh = obj as THREE.Mesh;
          if (!mesh.isMesh) return;
          mesh.receiveShadow = true;
          mesh.castShadow = false;
          roadMeshes.push(mesh);

          const lowerName = (mesh.name || '').toLowerCase();
          if (
            lowerName.includes('road') ||
            lowerName.includes('asphalt') ||
            lowerName.includes('crossing') ||
            lowerName.includes('bike')
          ) {
            drivableMeshes.push(mesh);
          }

          const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
          for (const mat of mats) {
            if (!mat) continue;
            const stdMat = mat as THREE.MeshStandardMaterial;
            if (stdMat.map) {
              stdMat.map.anisotropy = maxAnisotropy;
              stdMat.map.needsUpdate = true;
            }
            if ('envMapIntensity' in stdMat) {
              stdMat.envMapIntensity = Math.min(stdMat.envMapIntensity || 0.75, 0.85);
            }
          }
        });

        // 1. Center raw city road network horizontally (eliminates large FBX world offset)
        const rawBox = new THREE.Box3().setFromObject(rawScene);
        const rawCenter = rawBox.getCenter(new THREE.Vector3());

        const centeredGroup = new THREE.Group();
        rawScene.position.set(-rawCenter.x, -rawBox.min.y, -rawCenter.z);
        centeredGroup.add(rawScene);
        centeredGroup.updateMatrixWorld(true);

        // 2. Shift the wide 21m southern boulevard midpoint (-14.5, +160) to origin (0, 0)
        //    and rotate -0.352 rad around Y so the boulevard runs straight forward along -Z
        const root = new THREE.Group();
        root.name = 'CustomCityRoadGLB';
        const pivot = new THREE.Group();
        centeredGroup.position.set(14.5, 0, -160);
        pivot.add(centeredGroup);
        pivot.rotation.y = -0.352;
        root.add(pivot);
        root.updateMatrixWorld(true);

        // 3. Raycast straight down at spawn origin (0, 0) to align asphalt height to Y = 0
        const raycaster = new THREE.Raycaster();
        const targets = drivableMeshes.length > 0 ? drivableMeshes : roadMeshes;
        raycaster.set(new THREE.Vector3(0, 80, 0), new THREE.Vector3(0, -1, 0));
        const hits = raycaster.intersectObjects(targets, false);

        if (hits.length > 0) {
          root.position.y = -hits[0].point.y;
        } else {
          // Fallback: search a small grid around origin to guarantee snapping onto road asphalt
          let foundY: number | null = null;
          for (let r = 2; r <= 24 && foundY === null; r += 4) {
            for (let a = 0; a < 8; a++) {
              const ang = (a / 8) * Math.PI * 2;
              raycaster.set(
                new THREE.Vector3(Math.cos(ang) * r, 80, Math.sin(ang) * r),
                new THREE.Vector3(0, -1, 0)
              );
              const nearby = raycaster.intersectObjects(targets, false);
              if (nearby.length > 0) {
                foundY = nearby[0].point.y;
                break;
              }
            }
          }
          if (foundY !== null) {
            root.position.y = -foundY;
          }
        }
        root.updateMatrixWorld(true);

        const finalBounds = new THREE.Box3().setFromObject(root);
        resolve({
          root,
          roadMeshes,
          bounds: finalBounds,
          spawnY: 0,
        });
      },
      undefined,
      (error) => reject(error)
    );
  });
}

type WheelCorner = 'FL' | 'FR' | 'RL' | 'RR';

interface ExtractedCornerGeo {
  geometry: THREE.BufferGeometry;
  center: THREE.Vector3;
  radius: number;
}

function meshMatchesPattern(mesh: THREE.Mesh, pattern: RegExp): boolean {
  let cur: THREE.Object3D | null = mesh;
  while (cur) {
    if (cur.name && pattern.test(cur.name)) return true;
    cur = cur.parent;
  }
  const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
  for (const m of mats) {
    if (m && m.name && pattern.test(m.name)) return true;
  }
  return false;
}

/**
 * Splits a BufferGeometry (indexed or non-indexed, interleaved or standard) into
 * up to 4 corner sub-geometries (FL, FR, RL, RR) in normalized car-wrapper space
 * (front = -Z, rear = +Z, left = -X, right = +X).
 */
function splitGeometryByWheelQuadrant(
  srcGeo: THREE.BufferGeometry,
  worldMatrix: THREE.Matrix4,
  centerToLocalOrigin: boolean
): Partial<Record<WheelCorner, ExtractedCornerGeo>> {
  const posAttr = srcGeo.getAttribute('position');
  if (!posAttr) return {};

  const indexAttr = srcGeo.getIndex();
  const triCount = indexAttr ? Math.floor(indexAttr.count / 3) : Math.floor(posAttr.count / 3);
  if (triCount === 0) return {};

  const flipWinding = worldMatrix.determinant() < 0;
  const normalMatrix = new THREE.Matrix3().getNormalMatrix(worldMatrix);

  const cornerTris: Record<WheelCorner, number[]> = {
    FL: [],
    FR: [],
    RL: [],
    RR: [],
  };

  const p0 = new THREE.Vector3();
  const p1 = new THREE.Vector3();
  const p2 = new THREE.Vector3();

  for (let t = 0; t < triCount; t++) {
    const i0 = indexAttr ? indexAttr.getX(t * 3) : t * 3;
    const i1 = indexAttr ? indexAttr.getX(t * 3 + 1) : t * 3 + 1;
    const i2 = indexAttr ? indexAttr.getX(t * 3 + 2) : t * 3 + 2;

    p0.set(posAttr.getX(i0), posAttr.getY(i0), posAttr.getZ(i0)).applyMatrix4(worldMatrix);
    p1.set(posAttr.getX(i1), posAttr.getY(i1), posAttr.getZ(i1)).applyMatrix4(worldMatrix);
    p2.set(posAttr.getX(i2), posAttr.getY(i2), posAttr.getZ(i2)).applyMatrix4(worldMatrix);

    const cx = (p0.x + p1.x + p2.x) / 3;
    const cz = (p0.z + p1.z + p2.z) / 3;
    const corner: WheelCorner = cz < 0 ? (cx < 0 ? 'FL' : 'FR') : cx < 0 ? 'RL' : 'RR';

    if (flipWinding) {
      cornerTris[corner].push(i0, i2, i1);
    } else {
      cornerTris[corner].push(i0, i1, i2);
    }
  }

  const results: Partial<Record<WheelCorner, ExtractedCornerGeo>> = {};
  const attrNames = Object.keys(srcGeo.attributes);
  const tmpVec = new THREE.Vector3();

  (['FL', 'FR', 'RL', 'RR'] as WheelCorner[]).forEach((corner) => {
    const tris = cornerTris[corner];
    if (tris.length === 0) return;

    const oldToNew = new Map<number, number>();
    const uniqueOld: number[] = [];
    const newIndices = new Uint32Array(tris.length);

    for (let k = 0; k < tris.length; k++) {
      const oldIdx = tris[k];
      let mapped = oldToNew.get(oldIdx);
      if (mapped === undefined) {
        mapped = uniqueOld.length;
        oldToNew.set(oldIdx, mapped);
        uniqueOld.push(oldIdx);
      }
      newIndices[k] = mapped;
    }

    const vertCount = uniqueOld.length;
    const outGeo = new THREE.BufferGeometry();

    // Transform positions into wrapper space and measure exact bounding box
    const outPos = new Float32Array(vertCount * 3);
    let minX = Infinity;
    let minY = Infinity;
    let minZ = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    let maxZ = -Infinity;

    for (let v = 0; v < vertCount; v++) {
      const srcIdx = uniqueOld[v];
      tmpVec
        .set(posAttr.getX(srcIdx), posAttr.getY(srcIdx), posAttr.getZ(srcIdx))
        .applyMatrix4(worldMatrix);
      outPos[v * 3] = tmpVec.x;
      outPos[v * 3 + 1] = tmpVec.y;
      outPos[v * 3 + 2] = tmpVec.z;
      if (tmpVec.x < minX) minX = tmpVec.x;
      if (tmpVec.y < minY) minY = tmpVec.y;
      if (tmpVec.z < minZ) minZ = tmpVec.z;
      if (tmpVec.x > maxX) maxX = tmpVec.x;
      if (tmpVec.y > maxY) maxY = tmpVec.y;
      if (tmpVec.z > maxZ) maxZ = tmpVec.z;
    }

    const center = new THREE.Vector3(
      (minX + maxX) * 0.5,
      (minY + maxY) * 0.5,
      (minZ + maxZ) * 0.5
    );
    const radius = Math.max(0.24, (maxY - minY) * 0.5);

    if (centerToLocalOrigin) {
      for (let v = 0; v < vertCount; v++) {
        outPos[v * 3] -= center.x;
        outPos[v * 3 + 1] -= center.y;
        outPos[v * 3 + 2] -= center.z;
      }
    }

    outGeo.setAttribute('position', new THREE.BufferAttribute(outPos, 3));

    // Copy & transform normals and all other attributes (UVs, colors, tangents)
    for (const name of attrNames) {
      if (name === 'position') continue;
      const attr = srcGeo.getAttribute(name);
      if (!attr) continue;
      const itemSize = attr.itemSize;
      const outArr = new Float32Array(vertCount * itemSize);

      if (name === 'normal' && itemSize === 3) {
        for (let v = 0; v < vertCount; v++) {
          const srcIdx = uniqueOld[v];
          tmpVec
            .set(attr.getX(srcIdx), attr.getY(srcIdx), attr.getZ(srcIdx))
            .applyMatrix3(normalMatrix)
            .normalize();
          outArr[v * 3] = tmpVec.x;
          outArr[v * 3 + 1] = tmpVec.y;
          outArr[v * 3 + 2] = tmpVec.z;
        }
      } else {
        for (let v = 0; v < vertCount; v++) {
          const srcIdx = uniqueOld[v];
          const base = v * itemSize;
          if (itemSize >= 1) outArr[base] = attr.getX(srcIdx);
          if (itemSize >= 2) outArr[base + 1] = attr.getY(srcIdx);
          if (itemSize >= 3) outArr[base + 2] = attr.getZ(srcIdx);
          if (itemSize >= 4) outArr[base + 3] = attr.getW(srcIdx);
        }
      }
      outGeo.setAttribute(name, new THREE.BufferAttribute(outArr, itemSize, attr.normalized));
    }

    if (vertCount <= 65535) {
      outGeo.setIndex(new THREE.BufferAttribute(new Uint16Array(newIndices), 1));
    } else {
      outGeo.setIndex(new THREE.BufferAttribute(newIndices, 1));
    }

    if (!outGeo.getAttribute('normal')) {
      outGeo.computeVertexNormals();
    }
    outGeo.computeBoundingBox();
    outGeo.computeBoundingSphere();

    results[corner] = { geometry: outGeo, center, radius };
  });

  return results;
}

/**
 * Finds all wheel meshes (and brake calipers) inside the normalized car model and
 * rigs every wheel with an axle-centered steering pivot (for front wheels) and
 * rolling spin pivot (for all 4 wheels). Handles both separate wheel nodes and
 * fused 4-wheel meshes (such as Koenigsegg Gemera's polySurface1).
 */
function rigCarWheels(wrapper: THREE.Group): void {
  wrapper.updateMatrixWorld(true);

  const wheelMeshes: THREE.Mesh[] = [];
  const caliperMeshes: THREE.Mesh[] = [];
  const wheelRegex = /wheel|tire|tyre|rim/i;
  const caliperRegex = /calliper|caliper/i;

  wrapper.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (!mesh.isMesh) return;
    if (meshMatchesPattern(mesh, caliperRegex)) {
      caliperMeshes.push(mesh);
    } else if (meshMatchesPattern(mesh, wheelRegex)) {
      wheelMeshes.push(mesh);
    }
  });

  const steerPivotByCorner: Partial<Record<WheelCorner, THREE.Group>> = {};
  const spinPivotByCorner: Partial<Record<WheelCorner, THREE.Group>> = {};
  const wheelCenterByCorner: Partial<Record<WheelCorner, THREE.Vector3>> = {};

  const getOrCreateCornerPivots = (
    corner: WheelCorner,
    center: THREE.Vector3,
    radius: number
  ): { steerPivot: THREE.Group; spinPivot: THREE.Group } => {
    if (steerPivotByCorner[corner] && spinPivotByCorner[corner]) {
      return {
        steerPivot: steerPivotByCorner[corner]!,
        spinPivot: spinPivotByCorner[corner]!,
      };
    }

    const isFront = corner === 'FL' || corner === 'FR';
    const steerPivot = new THREE.Group();
    steerPivot.name = `WheelSteer_${corner}`;
    steerPivot.position.copy(center);
    steerPivot.userData.wheelRole = 'steer';
    steerPivot.userData.wheelCorner = corner;
    steerPivot.userData.isFront = isFront;

    const spinPivot = new THREE.Group();
    spinPivot.name = `WheelSpin_${corner}`;
    spinPivot.userData.wheelRole = 'spin';
    spinPivot.userData.wheelCorner = corner;
    spinPivot.userData.isFront = isFront;
    spinPivot.userData.wheelRadius = radius;

    steerPivot.add(spinPivot);
    wrapper.add(steerPivot);

    steerPivotByCorner[corner] = steerPivot;
    spinPivotByCorner[corner] = spinPivot;
    wheelCenterByCorner[corner] = center.clone();

    return { steerPivot, spinPivot };
  };

  for (const mesh of wheelMeshes) {
    const quadrants = splitGeometryByWheelQuadrant(mesh.geometry, mesh.matrixWorld, true);
    const corners = Object.keys(quadrants) as WheelCorner[];
    if (corners.length === 0) continue;

    for (const corner of corners) {
      const part = quadrants[corner]!;
      const { spinPivot } = getOrCreateCornerPivots(corner, part.center, part.radius);
      const subMesh = new THREE.Mesh(part.geometry, mesh.material);
      subMesh.name = `WheelMesh_${corner}`;
      subMesh.castShadow = true;
      subMesh.receiveShadow = true;

      // Align sub-mesh if multiple meshes share the same wheel corner
      const cornerOrigin = wheelCenterByCorner[corner]!;
      subMesh.position.copy(part.center).sub(cornerOrigin);
      spinPivot.add(subMesh);
    }

    mesh.parent?.remove(mesh);
  }

  // Attach front brake calipers to the front steering knuckles so they turn with the wheels without spinning
  for (const caliperMesh of caliperMeshes) {
    const quadrants = splitGeometryByWheelQuadrant(caliperMesh.geometry, caliperMesh.matrixWorld, false);
    const corners = Object.keys(quadrants) as WheelCorner[];
    if (corners.length === 0) continue;

    for (const corner of corners) {
      const part = quadrants[corner]!;
      const isFront = corner === 'FL' || corner === 'FR';
      const frontSteerPivot = steerPivotByCorner[corner];
      const frontCenter = wheelCenterByCorner[corner];

      const subMesh = new THREE.Mesh(part.geometry, caliperMesh.material);
      subMesh.name = `CaliperMesh_${corner}`;
      subMesh.castShadow = true;
      subMesh.receiveShadow = true;

      if (isFront && frontSteerPivot && frontCenter) {
        part.geometry.translate(-frontCenter.x, -frontCenter.y, -frontCenter.z);
        part.geometry.computeBoundingBox();
        part.geometry.computeBoundingSphere();
        frontSteerPivot.add(subMesh);
      } else {
        wrapper.add(subMesh);
      }
    }

    caliperMesh.parent?.remove(caliperMesh);
  }
}

function normalizeLoadedCarModel(rawScene: THREE.Group): THREE.Group {
  const wrapper = new THREE.Group();
  wrapper.name = 'CustomPlayerCarGLB';

  // Enable shadows and clean IBL response across all meshes in the GLB
  rawScene.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.isMesh) {
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      for (const mat of mats) {
        if (mat && 'envMapIntensity' in mat) {
          const stdMat = mat as THREE.MeshStandardMaterial;
          if (!stdMat.envMapIntensity || stdMat.envMapIntensity < 1.1) {
            stdMat.envMapIntensity = 1.15;
          }
        }
      }
    }
  });

  // Model's native front nose points along +Z; rotate 180 deg so it faces -Z (forward)
  rawScene.rotation.set(0, Math.PI, 0);
  rawScene.position.set(0, 0, 0);
  rawScene.scale.set(1, 1, 1);
  rawScene.updateMatrixWorld(true);

  // Measure rotated bounds to normalize scale uniformly to real-world road proportions
  const initialBox = new THREE.Box3().setFromObject(rawScene);
  const initialSize = initialBox.getSize(new THREE.Vector3());
  const lengthAxis = Math.max(initialSize.z, initialSize.x, 0.001);
  const uniformScale = TARGET_PLAYER_CAR_LENGTH / lengthAxis;
  rawScene.scale.setScalar(uniformScale);
  rawScene.updateMatrixWorld(true);

  // Recompute bounds after scaling to center X/Z and place tire bottoms flush on road
  const scaledBox = new THREE.Box3().setFromObject(rawScene);
  const scaledCenter = scaledBox.getCenter(new THREE.Vector3());
  rawScene.position.set(
    -scaledCenter.x,
    -scaledBox.min.y + ROAD_SURFACE_CLEARANCE_Y,
    -scaledCenter.z
  );
  rawScene.updateMatrixWorld(true);

  wrapper.add(rawScene);

  // Rig all 4 wheels (spin pivots + front steering pivots + front steering calipers)
  rigCarWheels(wrapper);

  return wrapper;
}

function loadCustomPlayerCarTemplate(): Promise<THREE.Group> {
  if (cachedPlayerCarTemplate) {
    return Promise.resolve(cachedPlayerCarTemplate);
  }
  if (!cachedPlayerCarPromise) {
    const loader = getSharedGltfLoader();
    cachedPlayerCarPromise = new Promise<THREE.Group>((resolve, reject) => {
      loader.load(
        PLAYER_CAR_GLB_URL,
        (gltf) => {
          const normalized = normalizeLoadedCarModel(gltf.scene);
          cachedPlayerCarTemplate = normalized;
          resolve(normalized);
        },
        undefined,
        (error) => {
          cachedPlayerCarPromise = null;
          reject(error);
        }
      );
    });
  }
  return cachedPlayerCarPromise;
}

export interface WheelSpinEntry {
  pivot: THREE.Object3D;
  radius: number;
}

export interface PlayerCarRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  wheels: THREE.Object3D[];
  wheelSpinPivots: WheelSpinEntry[];
  frontSteerPivots: THREE.Object3D[];
  nitroFlames: THREE.Mesh[];
  shieldMesh: THREE.Mesh;
  magnetRing: THREE.Mesh;
  headlightBeams: THREE.Mesh[];
  brakeLightMat: THREE.MeshStandardMaterial;
}

function bindWheelPivotsFromModel(instance: THREE.Object3D, rig: PlayerCarRig): void {
  rig.wheels.length = 0;
  rig.wheelSpinPivots.length = 0;
  rig.frontSteerPivots.length = 0;

  instance.traverse((obj) => {
    if (obj.userData?.wheelRole === 'steer' && obj.userData?.isFront === true) {
      rig.frontSteerPivots.push(obj);
    } else if (obj.userData?.wheelRole === 'spin') {
      const radius =
        typeof obj.userData.wheelRadius === 'number' && obj.userData.wheelRadius > 0.1
          ? obj.userData.wheelRadius
          : 0.36;
      rig.wheelSpinPivots.push({ pivot: obj, radius });
      rig.wheels.push(obj);
    }
  });
}

export function createRampTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#f59e0b';
  ctx.fillRect(0, 0, 256, 256);

  ctx.fillStyle = '#0f172a';
  for (let y = -64; y < 320; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y + 36);
    ctx.lineTo(128, y);
    ctx.lineTo(256, y + 36);
    ctx.lineTo(256, y + 60);
    ctx.lineTo(128, y + 24);
    ctx.lineTo(0, y + 60);
    ctx.closePath();
    ctx.fill();
  }

  ctx.fillStyle = '#fef3c7';
  ctx.fillRect(8, 0, 12, 256);
  ctx.fillRect(236, 0, 12, 256);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(64, 64, 12, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.72)');
  grad.addColorStop(0.6, 'rgba(0, 0, 0, 0.36)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function buildPlayerCar(_spec: CarSpec, shadowTex: THREE.CanvasTexture): PlayerCarRig {
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const modelHolder = new THREE.Group();
  bodyGroup.add(modelHolder);

  const brakeLightMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0xdc2626,
    emissiveIntensity: 0.9,
    roughness: 0.25,
  });

  // 1. Ground contact shadow directly beneath the custom GLB car
  const contactShadow = new THREE.Mesh(
    new THREE.PlaneGeometry(2.95, 5.4),
    new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.62,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    })
  );
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.04;
  root.add(contactShadow);

  // 2. Twin Nitro exhaust flame cones aligned to the rear diffuser
  const nitroFlames: THREE.Mesh[] = [];
  const flameGeo = new THREE.ConeGeometry(0.16, 1.35, 8);
  flameGeo.rotateX(Math.PI / 2);
  const flameMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.9,
  });
  for (const sx of [-0.46, 0.46]) {
    const flame = new THREE.Mesh(flameGeo, flameMat);
    flame.position.set(sx, 0.4, 2.95);
    flame.visible = false;
    bodyGroup.add(flame);
    nitroFlames.push(flame);
  }

  // 3. Night / rain headlight ground beams projecting forward (-Z)
  const headlightBeams: THREE.Mesh[] = [];
  const beamGeo = new THREE.ConeGeometry(1.9, 13, 10, 1, true);
  beamGeo.rotateX(-Math.PI / 2);
  const beamMat = new THREE.MeshBasicMaterial({
    color: 0xfef9c3,
    transparent: true,
    opacity: 0.14,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
  for (const sx of [-0.66, 0.66]) {
    const beam = new THREE.Mesh(beamGeo, beamMat);
    beam.position.set(sx, 0.48, -8.5);
    beam.visible = false;
    bodyGroup.add(beam);
    headlightBeams.push(beam);
  }

  // 4. Shield energy bubble
  const shieldMesh = new THREE.Mesh(
    new THREE.IcosahedronGeometry(2.75, 1),
    new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.65,
      transparent: true,
      opacity: 0.24,
      wireframe: false,
      roughness: 0.1,
      depthWrite: false,
    })
  );
  shieldMesh.position.y = 0.85;
  shieldMesh.scale.set(0.9, 0.6, 1.18);
  shieldMesh.visible = false;
  root.add(shieldMesh);

  // 5. Magnet ring aura
  const magnetRing = new THREE.Mesh(
    new THREE.TorusGeometry(2.45, 0.08, 8, 24),
    new THREE.MeshBasicMaterial({
      color: 0xf43f5e,
      transparent: true,
      opacity: 0.72,
    })
  );
  magnetRing.rotation.x = Math.PI / 2;
  magnetRing.position.y = 0.26;
  magnetRing.visible = false;
  root.add(magnetRing);

  const rig: PlayerCarRig = {
    root,
    bodyGroup,
    wheels: [],
    wheelSpinPivots: [],
    frontSteerPivots: [],
    nitroFlames,
    shieldMesh,
    magnetRing,
    headlightBeams,
    brakeLightMat,
  };

  // 6. Mount ONLY the custom 3D GLB car model (cached after first download) & bind wheel pivots
  if (cachedPlayerCarTemplate) {
    const clone = cachedPlayerCarTemplate.clone(true);
    modelHolder.add(clone);
    bindWheelPivotsFromModel(clone, rig);
  } else {
    loadCustomPlayerCarTemplate()
      .then((template) => {
        modelHolder.clear();
        const clone = template.clone(true);
        modelHolder.add(clone);
        bindWheelPivotsFromModel(clone, rig);
      })
      .catch((err) => {
        console.error('Failed to load custom player car GLB:', err);
      });
  }

  return rig;
}

export function buildJumpRamp(rampTex: THREE.CanvasTexture): THREE.Group {
  const g = new THREE.Group();

  const shape = new THREE.Shape();
  shape.moveTo(0, 0);
  shape.lineTo(6.4, 0);
  shape.lineTo(0, 1.55);
  shape.closePath();

  const wedgeGeo = new THREE.ExtrudeGeometry(shape, { depth: 3.1, bevelEnabled: false });
  wedgeGeo.rotateY(Math.PI / 2);
  wedgeGeo.translate(-1.55, 0, 3.2);

  const sideMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.75,
    flatShading: true,
  });
  const wedge = new THREE.Mesh(wedgeGeo, sideMat);
  wedge.castShadow = true;
  wedge.receiveShadow = true;
  g.add(wedge);

  const deckLength = Math.hypot(6.4, 1.55);
  const deckGeo = new THREE.PlaneGeometry(3.04, deckLength);
  const deckMat = new THREE.MeshStandardMaterial({
    map: rampTex,
    roughness: 0.55,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const deck = new THREE.Mesh(deckGeo, deckMat);
  deck.rotation.x = -Math.PI / 2 + Math.atan2(1.55, 6.4);
  deck.position.set(0, 0.79, 0);
  g.add(deck);

  const railMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    emissive: 0xd97706,
    emissiveIntensity: 0.45,
  });
  for (const sx of [-1.58, 1.58]) {
    const rail = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.22, deckLength), railMat);
    rail.rotation.x = Math.atan2(1.55, 6.4);
    rail.position.set(sx, 0.88, 0);
    g.add(rail);
  }

  return g;
}

export function buildCoinMesh(): THREE.Group {
  const g = new THREE.Group();
  const goldMat = new THREE.MeshStandardMaterial({
    color: 0xfacc15,
    emissive: 0xca8a04,
    emissiveIntensity: 0.45,
    roughness: 0.22,
    metalness: 0.82,
    flatShading: true,
  });
  const coreMat = new THREE.MeshStandardMaterial({
    color: 0xfef08a,
    roughness: 0.3,
    metalness: 0.65,
  });

  const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.54, 0.54, 0.14, 10), goldMat);
  disc.rotation.x = Math.PI / 2;
  g.add(disc);

  const inner = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.17, 6), coreMat);
  inner.rotation.x = Math.PI / 2;
  g.add(inner);

  return g;
}

export function buildGemMesh(): THREE.Group {
  const g = new THREE.Group();
  const gemMat = new THREE.MeshStandardMaterial({
    color: 0x22d3ee,
    emissive: 0x0891b2,
    emissiveIntensity: 0.65,
    roughness: 0.12,
    metalness: 0.55,
    flatShading: true,
  });
  const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.56, 0), gemMat);
  crystal.scale.set(0.85, 1.25, 0.85);
  g.add(crystal);
  return g;
}

export function buildPowerupMesh(kind: 'magnet' | 'nitro' | 'shield'): THREE.Group {
  const g = new THREE.Group();
  const palette =
    kind === 'magnet'
      ? { color: 0xf43f5e, emissive: 0xbe123c }
      : kind === 'nitro'
      ? { color: 0xf97316, emissive: 0xc2410c }
      : { color: 0x38bdf8, emissive: 0x0284c7 };

  const mat = new THREE.MeshStandardMaterial({
    color: palette.color,
    emissive: palette.emissive,
    emissiveIntensity: 0.7,
    roughness: 0.2,
    metalness: 0.5,
    flatShading: true,
  });

  const core = new THREE.Mesh(
    kind === 'nitro'
      ? new THREE.CylinderGeometry(0.34, 0.34, 0.95, 8)
      : kind === 'magnet'
      ? new THREE.TorusGeometry(0.45, 0.16, 6, 12, Math.PI * 1.35)
      : new THREE.IcosahedronGeometry(0.56, 0),
    mat
  );
  g.add(core);

  const halo = new THREE.Mesh(
    new THREE.TorusGeometry(0.76, 0.05, 6, 18),
    new THREE.MeshBasicMaterial({ color: palette.color, transparent: true, opacity: 0.78 })
  );
  halo.rotation.x = Math.PI / 2;
  g.add(halo);

  return g;
}
