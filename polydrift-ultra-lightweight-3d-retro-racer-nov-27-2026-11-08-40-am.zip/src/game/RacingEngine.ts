import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  CameraMode,
  CarSpec,
  CarUpgrades,
  GameScreen,
  HudSnapshot,
  MinimapBlip,
  MissionDef,
  RunSummary,
  TouchDriveInput,
  WeatherMode,
} from '../types/game';
import { getCarEffectiveStats } from '../data/gameCatalog';
import { AudioEngine } from './AudioEngine';
import {
  buildCoinMesh,
  buildGemMesh,
  buildJumpRamp,
  buildPlayerCar,
  buildPowerupMesh,
  createContactShadowTexture,
  createRampTexture,
  loadCityRoadModel,
  PlayerCarRig,
} from './MeshFactory';

// Reusable module-scope math & raycast helpers (zero GC in render loop)
const _vTargetPos = new THREE.Vector3();
const _vLookPos = new THREE.Vector3();
const _raycaster = new THREE.Raycaster();
const _rayOrigin = new THREE.Vector3();
const _rayDown = new THREE.Vector3(0, -1, 0);
const _cSky = new THREE.Color();
const _cSun = new THREE.Color();
const _cHemiSky = new THREE.Color();
const _cHemiGround = new THREE.Color();
const _cWhite = new THREE.Color(0xffffff);
const _cDaySky = new THREE.Color('#60b6f7');
const _cSunsetSky = new THREE.Color('#f97352');
const _cNightSky = new THREE.Color('#0c1428');
const _cRainTint = new THREE.Color('#475569');
const _cDaySun = new THREE.Color('#fff4d6');
const _cSunsetSun = new THREE.Color('#ff9a44');
const _cNightSun = new THREE.Color('#8ab4f8');

interface PickupEntity {
  mesh: THREE.Group;
  active: boolean;
  kind: 'coin' | 'gem' | 'magnet' | 'nitro' | 'shield';
  x: number;
  y: number;
  z: number;
  baseY: number;
}

interface RampEntity {
  mesh: THREE.Group;
  active: boolean;
  x: number;
  y: number;
  z: number;
  heading: number;
  triggered: boolean;
}

interface ParticleItem {
  mesh: THREE.Mesh;
  active: boolean;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  grow: number;
}

interface SkidMarkItem {
  mesh: THREE.Mesh;
  active: boolean;
  life: number;
}

export interface RacingEngineCallbacks {
  onHudUpdate: (hud: HudSnapshot) => void;
  onGameOver: (summary: RunSummary) => void;
  onContextLost: () => void;
}

export class RacingEngine {
  private container: HTMLElement;
  private callbacks: RacingEngineCallbacks;
  public audio: AudioEngine;

  private isSoftwareGl: boolean;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private fog: THREE.FogExp2;
  private shadowTex!: THREE.CanvasTexture;
  private rampTex!: THREE.CanvasTexture;

  // Custom 3D City Road Environment
  private cityRoadRoot: THREE.Group | null = null;
  private cityRoadMeshes: THREE.Mesh[] = [];
  private cityBounds = new THREE.Box3(
    new THREE.Vector3(-240, -15, -340),
    new THREE.Vector3(240, 25, 240)
  );
  private fallbackGround!: THREE.Mesh;
  private terrainFloorY = 0;

  // ONLY the custom player car (all traffic & police cars removed)
  private playerRig!: PlayerCarRig;
  private pickupPool: PickupEntity[] = [];
  private rampPool: RampEntity[] = [];
  private smokePool: ParticleItem[] = [];
  private sparkPool: ParticleItem[] = [];
  private skidPool: SkidMarkItem[] = [];
  private rainLines!: THREE.LineSegments;
  private rainPositions!: Float32Array;
  private rainCount = 260;

  // Game mode & configuration
  private screen: GameScreen = 'title';
  private garageShowcase = false;
  private cameraMode: CameraMode = 'chase';
  private activeCarSpec: CarSpec;
  private activeUpgrades: CarUpgrades;
  private activeMission: MissionDef;
  private currentHighScore = 0;

  // Simulation state
  private frameId = 0;
  private disposed = false;
  private lastTimestamp = 0;
  private elapsedTime = 0;
  private runElapsedSec = 0;
  private hudEmitAccum = 0;
  private hitstopTimer = 0;
  private cameraShake = 0;
  private bannerText: string | null = null;
  private bannerTone: 'amber' | 'cyan' | 'red' | 'emerald' = 'amber';
  private bannerTimer = 0;

  // Player kinematics (360-degree city road driving)
  private playerX = 0;
  private playerY = 0;
  private playerZ = 0;
  private groundY = 0;
  private playerVy = 0;
  private carHeading = 0; // radians; 0 = facing -Z
  private speed = 16; // signed world units/sec (>0 forward, <0 reverse)
  private driveGear: 'drive' | 'stop' | 'reverse' = 'drive';
  private customMaxSpeedKmh = 200; // user-adjustable top speed cap (40..360 km/h)
  private steerNorm = 0; // -1..1 smooth steering wheel angle
  private frontWheelAngle = 0; // radians; smooth front wheel turn angle
  private visualYaw = 0;
  private visualRoll = 0;
  private visualPitch = 0;
  private suspensionSquash = 1;
  private nitro = 80;
  private isDrifting = false;
  private isBoosting = false;
  private isAirborne = false;
  private gasActive = false;
  private brakeActive = false;
  private skidAccum = 0;
  private smokeAccum = 0;

  // Run progression & counters
  private score = 0;
  private distanceM = 0;
  private runCoins = 0;
  private runGems = 0;
  private nearMissCount = 0;
  private driftDistanceM = 0;
  private driftScore = 0;
  private magnetTimer = 0;
  private shieldActive = false;
  private missionCompletedInRun = false;

  // Environment cycle & weather
  private dayCyclePhase = 0.08;
  private weather: WeatherMode = 'sunny';
  private weatherTimer = 26;

  // Distance-based spawner cursors
  private nextPickupSpawnDist = 28;
  private nextRampSpawnDist = 85;

  // Camera smoothing state
  private camPos = new THREE.Vector3(0, 4, 10);
  private camLook = new THREE.Vector3(0, 1, -10);
  private showcaseAngle = 0.45;

  // Input state (continuous keyboard + analog steering wheel & touch pedals)
  private keys: Record<string, boolean> = {};
  private touchSteer = 0; // -1..1 continuous analog from steering wheel
  private touchGas = false;
  private touchBrake = false;
  private touchDrift = false;
  private touchNitro = false;

  constructor(
    container: HTMLElement,
    initialCar: CarSpec,
    initialUpgrades: CarUpgrades,
    initialMission: MissionDef,
    initialCamera: CameraMode,
    highScore: number,
    callbacks: RacingEngineCallbacks
  ) {
    this.container = container;
    this.activeCarSpec = initialCar;
    this.activeUpgrades = initialUpgrades;
    this.activeMission = initialMission;
    this.cameraMode = initialCamera;
    this.currentHighScore = highScore;
    this.callbacks = callbacks;
    this.audio = new AudioEngine();

    // 1. Detect software WebGL strictly from renderer string
    this.isSoftwareGl = (() => {
      try {
        const probeCanvas = document.createElement('canvas');
        const gl = probeCanvas.getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    // 2. Renderer setup
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(
      container.clientWidth || window.innerWidth,
      container.clientHeight || window.innerHeight
    );

    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    // 3. Scene, Camera, RoomEnvironment IBL & Horizon Fog
    this.scene = new THREE.Scene();
    this.scene.background = _cDaySky.clone();
    this.fog = new THREE.FogExp2(_cDaySky.getHex(), 0.0022);
    this.scene.fog = this.fog;

    const aspect =
      (container.clientWidth || window.innerWidth) /
      (container.clientHeight || window.innerHeight);
    this.camera = new THREE.PerspectiveCamera(62, aspect, 0.2, 750);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // 4. Warm Key Directional + Cool Hemisphere Fill
    this.hemiLight = new THREE.HemisphereLight(0x9bd6ff, 0x3b4d3f, 0.95);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff4d6, 1.55);
    this.sunLight.position.set(28, 52, 22);
    if (!this.isSoftwareGl) {
      this.sunLight.castShadow = true;
      this.sunLight.shadow.mapSize.set(1024, 1024);
      const d = 38;
      this.sunLight.shadow.camera.left = -d;
      this.sunLight.shadow.camera.right = d;
      this.sunLight.shadow.camera.top = d;
      this.sunLight.shadow.camera.bottom = -d;
      this.sunLight.shadow.camera.near = 2;
      this.sunLight.shadow.camera.far = 160;
      this.sunLight.shadow.bias = -0.0005;
      this.sunLight.shadow.normalBias = 0.02;
    }
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    // 5. Textures, custom 3D City Road GLB, custom Player Car GLB & pools
    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    this.shadowTex = createContactShadowTexture();
    this.rampTex = createRampTexture(maxAniso);

    this.initCityRoadWorld(maxAniso);
    this.rebuildPlayerCar(initialCar);
    this.initPools();
    this.initRainSystem();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    // 6. Bind DOM listeners
    window.addEventListener('resize', this.handleResize);
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('blur', this.handleBlur);
    this.renderer.domElement.addEventListener('webglcontextlost', this.handleContextLost);

    this.lastTimestamp = performance.now();
    this.scheduleNextFrame();
  }

  private initCityRoadWorld(maxAnisotropy: number): void {
    // Extended subtle terrain base beneath the city so there is never an empty void
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x3b4a3f,
      roughness: 0.94,
      metalness: 0.04,
    });
    this.fallbackGround = new THREE.Mesh(new THREE.PlaneGeometry(1800, 1800), groundMat);
    this.fallbackGround.rotation.x = -Math.PI / 2;
    this.fallbackGround.position.y = -0.02;
    this.fallbackGround.receiveShadow = true;
    this.scene.add(this.fallbackGround);

    // Load the user's custom 3D City Road GLB via GLTFLoader + MeshoptDecoder + DRACOLoader
    loadCityRoadModel(maxAnisotropy)
      .then((asset) => {
        if (this.disposed) return;
        this.cityRoadRoot = asset.root;
        this.cityRoadMeshes = asset.roadMeshes;
        this.cityBounds.copy(asset.bounds);
        this.scene.add(asset.root);

        // Move subtle base terrain safely below the lowest road elevation
        this.terrainFloorY = asset.bounds.min.y - 0.35;
        this.fallbackGround.position.y = this.terrainFloorY;

        // Snap player car immediately onto the road surface at its current X/Z
        const surfaceY = this.sampleRoadHeight(this.playerX, this.playerZ, this.playerY);
        this.groundY = surfaceY;
        if (!this.isAirborne) {
          this.playerY = surfaceY;
        }
      })
      .catch((err) => {
        console.error('Failed to load custom city road GLB:', err);
      });
  }

  private sampleRoadHeight(x: number, z: number, refY: number): number {
    if (this.cityRoadMeshes.length === 0) {
      return 0;
    }
    _rayOrigin.set(x, refY + 14, z);
    _raycaster.set(_rayOrigin, _rayDown);
    _raycaster.far = 36;

    const hits = _raycaster.intersectObjects(this.cityRoadMeshes, false);
    if (hits.length > 0) {
      // Pick the hit closest to current car height so slopes/overpasses transition smoothly
      let bestY = hits[0].point.y;
      let bestDelta = Math.abs(bestY - refY);
      for (let i = 1; i < hits.length; i++) {
        const py = hits[i].point.y;
        const delta = Math.abs(py - refY);
        if (delta < bestDelta && py <= refY + 4.5) {
          bestY = py;
          bestDelta = delta;
        }
      }
      return bestY;
    }
    return this.terrainFloorY;
  }

  public rebuildPlayerCar(spec: CarSpec): void {
    this.activeCarSpec = spec;
    if (this.playerRig) {
      this.scene.remove(this.playerRig.root);
    }
    this.playerRig = buildPlayerCar(spec, this.shadowTex);
    this.playerRig.root.position.set(this.playerX, this.playerY, this.playerZ);
    this.playerRig.root.rotation.set(0, this.carHeading, 0);
    this.scene.add(this.playerRig.root);
  }

  private initPools(): void {
    // Collectibles & Power-ups Pool (no AI traffic or police cars)
    for (let i = 0; i < 42; i++) {
      const mesh = buildCoinMesh();
      mesh.visible = false;
      this.scene.add(mesh);
      this.pickupPool.push({ mesh, active: false, kind: 'coin', x: 0, y: 1, z: 100, baseY: 0.9 });
    }
    for (let i = 0; i < 8; i++) {
      const mesh = buildGemMesh();
      mesh.visible = false;
      this.scene.add(mesh);
      this.pickupPool.push({ mesh, active: false, kind: 'gem', x: 0, y: 1, z: 100, baseY: 1.05 });
    }
    const powerKinds: ('magnet' | 'nitro' | 'shield')[] = ['magnet', 'nitro', 'shield'];
    for (const kind of powerKinds) {
      for (let i = 0; i < 2; i++) {
        const mesh = buildPowerupMesh(kind);
        mesh.visible = false;
        this.scene.add(mesh);
        this.pickupPool.push({ mesh, active: false, kind, x: 0, y: 1, z: 100, baseY: 1.1 });
      }
    }

    // Jump Ramps Pool
    for (let i = 0; i < 3; i++) {
      const mesh = buildJumpRamp(this.rampTex);
      mesh.visible = false;
      this.scene.add(mesh);
      this.rampPool.push({ mesh, active: false, x: 0, y: 0, z: 100, heading: 0, triggered: false });
    }

    // Tire Smoke Pool (36 puffs)
    const smokeGeo = new THREE.DodecahedronGeometry(0.32, 0);
    for (let i = 0; i < 36; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xe2e8f0, transparent: true, opacity: 0.55 });
      const mesh = new THREE.Mesh(smokeGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.smokePool.push({ mesh, active: false, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 0.5, grow: 1.8 });
    }

    // Impact / Nitro Spark Pool (28 sparks)
    const sparkGeo = new THREE.BoxGeometry(0.16, 0.16, 0.45);
    for (let i = 0; i < 28; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xfbbf24, transparent: true, opacity: 0.95 });
      const mesh = new THREE.Mesh(sparkGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.sparkPool.push({ mesh, active: false, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 0.45, grow: -0.5 });
    }

    // Drift Skid Mark Pool (60 quads)
    const skidGeo = new THREE.PlaneGeometry(0.34, 1.35);
    skidGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < 60; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0x090d16,
        transparent: true,
        opacity: 0.48,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -2,
        polygonOffsetUnits: -2,
      });
      const mesh = new THREE.Mesh(skidGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.skidPool.push({ mesh, active: false, life: 0 });
    }
  }

  private initRainSystem(): void {
    const geo = new THREE.BufferGeometry();
    this.rainPositions = new Float32Array(this.rainCount * 6);
    for (let i = 0; i < this.rainCount; i++) {
      const rx = (Math.random() - 0.5) * 44;
      const ry = Math.random() * 24;
      const rz = (Math.random() - 0.5) * 60;
      const idx = i * 6;
      this.rainPositions[idx] = rx;
      this.rainPositions[idx + 1] = ry;
      this.rainPositions[idx + 2] = rz;
      this.rainPositions[idx + 3] = rx - 0.15;
      this.rainPositions[idx + 4] = ry - 1.35;
      this.rainPositions[idx + 5] = rz + 0.55;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(this.rainPositions, 3));
    const mat = new THREE.LineBasicMaterial({
      color: 0xcbd5e1,
      transparent: true,
      opacity: 0.48,
    });
    this.rainLines = new THREE.LineSegments(geo, mat);
    this.rainLines.frustumCulled = false;
    this.rainLines.visible = false;
    this.scene.add(this.rainLines);
  }

  // Public API called by React shell
  public updateConfig(
    car: CarSpec,
    upgrades: CarUpgrades,
    mission: MissionDef,
    highScore: number,
    sfxMuted: boolean,
    musicMuted: boolean
  ): void {
    const carChanged = car.id !== this.activeCarSpec.id;
    this.activeUpgrades = upgrades;
    this.activeMission = mission;
    this.currentHighScore = highScore;
    this.audio.setMuted(sfxMuted, musicMuted);
    if (carChanged) {
      this.rebuildPlayerCar(car);
    }
  }

  public setGarageShowcase(active: boolean): void {
    this.garageShowcase = active;
  }

  public setCameraMode(mode: CameraMode): void {
    this.cameraMode = mode;
  }

  public setTouchInput(input: TouchDriveInput): void {
    this.touchSteer = THREE.MathUtils.clamp(input.steer, -1, 1);
    this.touchGas = input.gas;
    this.touchBrake = input.brake;
    this.touchDrift = input.drift;
    this.touchNitro = input.nitro;
  }

  public setMaxSpeedKmh(kmh: number): void {
    const clamped = Math.round(THREE.MathUtils.clamp(kmh, 40, 360));
    this.customMaxSpeedKmh = clamped;
    if (this.driveGear === 'stop' && clamped > 40) {
      this.driveGear = 'drive';
    }
    if (this.screen === 'playing') {
      this.emitHud();
    }
  }

  public adjustMaxSpeedKmh(delta: number): void {
    if (delta > 0 && this.driveGear !== 'drive') {
      this.driveGear = 'drive';
    }
    this.setMaxSpeedKmh(this.customMaxSpeedKmh + delta);
  }

  public startRun(mission: MissionDef): void {
    this.audio.unlock();
    this.activeMission = mission;
    this.screen = 'playing';
    this.garageShowcase = false;

    const stats = getCarEffectiveStats(this.activeCarSpec, this.activeUpgrades);
    const levelSpeedScale = mission.speedScale ?? 1.0;
    this.customMaxSpeedKmh = THREE.MathUtils.clamp(
      Math.round((stats.topSpeedKmh * levelSpeedScale) / 10) * 10,
      80,
      340
    );

    // Reset player onto the main city boulevard facing straight down the road (-Z)
    this.playerX = 0;
    this.playerZ = 0;
    this.groundY = this.sampleRoadHeight(0, 0, 0);
    this.playerY = this.groundY;
    this.playerVy = 0;
    this.carHeading = 0;
    this.driveGear = 'drive';
    this.speed = Math.min(20, this.customMaxSpeedKmh * 0.34 * 0.45);
    this.steerNorm = 0;
    this.frontWheelAngle = 0;
    this.visualYaw = 0;
    this.visualRoll = 0;
    this.visualPitch = 0;
    this.suspensionSquash = 1;
    this.nitro = 80;
    this.isDrifting = false;
    this.isBoosting = false;
    this.isAirborne = false;
    this.gasActive = false;
    this.brakeActive = false;
    this.touchSteer = 0;
    this.touchGas = false;
    this.touchBrake = false;
    this.touchDrift = false;
    this.touchNitro = false;

    // Reset run counters
    this.score = 0;
    this.distanceM = 0;
    this.runElapsedSec = 0;
    this.runCoins = 0;
    this.runGems = 0;
    this.nearMissCount = 0;
    this.driftDistanceM = 0;
    this.driftScore = 0;
    this.magnetTimer = 0;
    this.shieldActive = false;
    this.missionCompletedInRun = false;
    this.hitstopTimer = 0;
    this.cameraShake = 0;

    // Reset environment preset for mission
    if (mission.timePreset === 'day') this.dayCyclePhase = 0.08;
    else if (mission.timePreset === 'sunset') this.dayCyclePhase = 0.35;
    else if (mission.timePreset === 'night') this.dayCyclePhase = 0.68;
    else this.dayCyclePhase = 0.05;

    this.weather = mission.weather === 'rain' ? 'rain' : 'sunny';
    this.weatherTimer = 24;

    // Reset pools
    for (const p of this.pickupPool) {
      p.active = false;
      p.mesh.visible = false;
    }
    for (const r of this.rampPool) {
      r.active = false;
      r.mesh.visible = false;
    }
    for (const s of this.skidPool) {
      s.active = false;
      s.mesh.visible = false;
    }

    this.nextPickupSpawnDist = 26;
    this.nextRampSpawnDist = 88;

    this.showBanner(mission.title.toUpperCase(), 'amber', 2.2);

    this.audio.setDriveLoopActive(true);
    this.emitHud();
  }

  public setPaused(paused: boolean): void {
    if (this.screen !== 'playing' && this.screen !== 'paused') return;
    this.screen = paused ? 'paused' : 'playing';
    this.audio.setDriveLoopActive(!paused);
    if (!paused) {
      this.lastTimestamp = performance.now();
    }
  }

  public returnToTitle(): void {
    this.screen = 'title';
    this.audio.setDriveLoopActive(false);
    this.playerX = 0;
    this.playerZ = 0;
    this.carHeading = 0;
    this.groundY = this.sampleRoadHeight(0, 0, 0);
    this.playerY = this.groundY;
    this.playerVy = 0;
    this.steerNorm = 0;
    this.isAirborne = false;
    this.isBoosting = false;
    this.isDrifting = false;
    this.weather = 'sunny';
    this.dayCyclePhase = 0.14;
    for (const p of this.pickupPool) {
      p.active = false;
      p.mesh.visible = false;
    }
    for (const r of this.rampPool) {
      r.active = false;
      r.mesh.visible = false;
    }
  }

  private showBanner(text: string, tone: 'amber' | 'cyan' | 'red' | 'emerald', duration = 1.6): void {
    this.bannerText = text;
    this.bannerTone = tone;
    this.bannerTimer = duration;
  }

  // Event listeners
  private handleResize = (): void => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private handleKeyDown = (e: KeyboardEvent): void => {
    this.keys[e.code] = true;
  };

  private handleKeyUp = (e: KeyboardEvent): void => {
    this.keys[e.code] = false;
  };

  private handleBlur = (): void => {
    this.keys = {};
    this.touchSteer = 0;
    this.touchGas = false;
    this.touchBrake = false;
    this.touchDrift = false;
    this.touchNitro = false;
  };

  private handleContextLost = (e: Event): void => {
    e.preventDefault();
    this.callbacks.onContextLost();
  };

  // Software-WebGL-safe frame pacing
  private scheduleNextFrame(): void {
    if (this.disposed) return;
    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || !gl.fenceSync) {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = (): void => {
    if (this.disposed) return;
    const now = performance.now();
    const rawDt = (now - this.lastTimestamp) / 1000;
    this.lastTimestamp = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    if (this.screen === 'playing') {
      if (this.hitstopTimer > 0) {
        this.hitstopTimer -= dt;
      } else {
        this.updatePlaying(dt);
      }
    } else if (this.screen === 'title' || this.screen === 'gameover') {
      this.updateTitleShowcase(dt);
    }

    this.updateCamera(dt);
    this.renderer.render(this.scene, this.camera);
    this.scheduleNextFrame();
  };

  private updateTitleShowcase(dt: number): void {
    this.elapsedTime += dt;
    // Keep the custom car grounded cleanly on the main city boulevard while camera orbits
    this.groundY = this.sampleRoadHeight(this.playerX, this.playerZ, this.groundY);
    this.playerY = THREE.MathUtils.damp(this.playerY, this.groundY, 10, dt);

    this.playerRig.root.position.set(this.playerX, this.playerY, this.playerZ);
    this.playerRig.root.rotation.set(0, this.carHeading, 0);
    this.playerRig.bodyGroup.rotation.set(0, 0, 0);
    this.playerRig.bodyGroup.scale.set(1, 1, 1);

    // Keep front wheels neatly centered on showcase
    this.frontWheelAngle = THREE.MathUtils.damp(this.frontWheelAngle, 0, 8, dt);
    for (const steerPivot of this.playerRig.frontSteerPivots) {
      steerPivot.rotation.y = this.frontWheelAngle;
    }

    this.playerRig.shieldMesh.visible = false;
    this.playerRig.magnetRing.visible = false;
    for (const f of this.playerRig.nitroFlames) f.visible = false;

    this.updateEnvironmentLighting(dt, false);
    this.updateParticles(dt);
  }

  private updatePlaying(dt: number): void {
    this.elapsedTime += dt;
    this.runElapsedSec += dt;
    if (this.bannerTimer > 0) {
      this.bannerTimer -= dt;
      if (this.bannerTimer <= 0) this.bannerText = null;
    }

    const stats = getCarEffectiveStats(this.activeCarSpec, this.activeUpgrades);
    const maxForwardUnits = this.customMaxSpeedKmh * 0.34;
    const maxReverseUnits = Math.min(24, Math.max(10, maxForwardUnits * 0.42));

    // Read continuous keyboard + analog steering wheel + on-screen Gas/Brake pedals
    const keyLeft = Boolean(this.keys['ArrowLeft'] || this.keys['KeyA']);
    const keyRight = Boolean(this.keys['ArrowRight'] || this.keys['KeyD']);
    const gasInput = Boolean(this.keys['ArrowUp'] || this.keys['KeyW'] || this.touchGas);
    const brakeInput = Boolean(this.keys['ArrowDown'] || this.keys['KeyS'] || this.touchBrake);
    const driftKey = Boolean(this.keys['KeyZ'] || this.touchDrift);
    const nitroKey = Boolean(
      this.keys['Space'] || this.keys['ShiftLeft'] || this.keys['ShiftRight'] || this.touchNitro
    );

    this.gasActive = gasInput;
    this.brakeActive = brakeInput;

    const keyboardSteer = (keyRight ? 1 : 0) - (keyLeft ? 1 : 0);
    const rawSteerInput =
      Math.abs(this.touchSteer) > 0.01 ? this.touchSteer : keyboardSteer;

    // Smooth steering wheel value (-1..1), crisply responsive & smoothly centering when released
    const steerSmoothRate = Math.abs(rawSteerInput) > 0.01 ? 15 : 11;
    this.steerNorm = THREE.MathUtils.damp(this.steerNorm, rawSteerInput, steerSmoothRate, dt);
    if (Math.abs(this.steerNorm) < 0.004 && Math.abs(rawSteerInput) < 0.01) {
      this.steerNorm = 0;
    }

    // Drift & Nitro activation
    this.isBoosting = nitroKey && this.nitro > 1.5 && !brakeInput;
    this.isDrifting =
      !this.isAirborne &&
      this.speed > 18 &&
      Math.abs(this.steerNorm) > 0.2 &&
      (driftKey || (brakeInput && gasInput));

    // Longitudinal speed dynamics:
    // - Auto-drives smoothly at cruise (74% of Max Speed) so mouse/one-hand steering always works!
    // - Holding Gas accelerates to 100% of Max Speed (and resumes forward drive from stop/reverse).
    // - Holding Brake slows cleanly to 0 (Stop) and continues into Reverse if held.
    const cruiseForwardUnits = maxForwardUnits * 0.74;
    const accelRate = Math.max(20, maxForwardUnits * 0.62);
    const reverseAccelRate = Math.max(15, maxReverseUnits * 0.95);
    const brakeDecel = Math.max(44, stats.brakeForce * 1.45);
    const coastDrag = Math.max(12, Math.abs(this.speed) * 0.5 + 8);

    if (this.isBoosting) {
      this.driveGear = 'drive';
      const boostTarget = maxForwardUnits * 1.32;
      this.nitro = Math.max(0, this.nitro - 26 * dt);
      if (this.speed < 0) {
        this.speed = Math.min(0, this.speed + brakeDecel * dt);
      } else {
        this.speed = THREE.MathUtils.damp(this.speed, boostTarget, 4.5, dt);
      }
    } else if (this.isDrifting) {
      this.driveGear = 'drive';
      const driftCap = maxForwardUnits * 0.86;
      this.speed = THREE.MathUtils.damp(this.speed, Math.min(this.speed, driftCap), 2.5, dt);
      this.nitro = Math.min(100, this.nitro + 19 * dt);
      const dDist = Math.max(0, this.speed) * dt * 0.55;
      this.driftDistanceM += dDist;
      this.driftScore += Math.round(dDist * 14);
      this.score += dDist * 14;
    } else if (brakeInput && !gasInput) {
      // Brake smoothly down to 0, then shift seamlessly into Reverse if held
      if (this.speed > 0.6) {
        this.speed = Math.max(0, this.speed - brakeDecel * dt);
        if (this.speed <= 0.6) {
          this.speed = 0;
          this.driveGear = 'stop';
        }
      } else {
        this.driveGear = 'reverse';
        this.speed = Math.max(-maxReverseUnits, this.speed - reverseAccelRate * dt);
      }
      if (this.driftScore > 0) this.driftScore = 0;
    } else if (gasInput && !brakeInput) {
      this.driveGear = 'drive';
      this.nitro = Math.min(100, this.nitro + 3.2 * dt);
      if (this.speed < -0.5) {
        this.speed = Math.min(0, this.speed + brakeDecel * dt);
      } else if (this.speed <= maxForwardUnits) {
        const headRoom = 1 - THREE.MathUtils.clamp(this.speed / Math.max(1, maxForwardUnits), 0, 1);
        const stepAccel = accelRate * (0.42 + headRoom * 0.85) * dt;
        this.speed = Math.min(maxForwardUnits, this.speed + stepAccel);
      } else {
        this.speed = THREE.MathUtils.damp(this.speed, maxForwardUnits, 3.8, dt);
      }
      if (this.driftScore > 0) this.driftScore = 0;
    } else {
      this.nitro = Math.min(100, this.nitro + 2.8 * dt);
      if (this.driveGear === 'drive') {
        // Maintain smooth forward cruise so you can freely steer with the on-screen wheel
        this.speed = THREE.MathUtils.damp(this.speed, cruiseForwardUnits, 2.2, dt);
      } else {
        // If user braked to a stop or released Reverse, settle cleanly to 0 km/h
        if (Math.abs(this.speed) <= coastDrag * dt) {
          this.speed = 0;
          this.driveGear = 'stop';
        } else {
          this.speed -= Math.sign(this.speed) * coastDrag * dt;
        }
      }
      if (this.driftScore > 0) this.driftScore = 0;
    }

    // Smooth 360-degree heading steering around the 3D city road network (flips naturally in reverse)
    const absSpeed = Math.abs(this.speed);
    if (absSpeed > 0.2) {
      const speedFactor = THREE.MathUtils.clamp(absSpeed / 16, 0.35, 1.3);
      const turnRate =
        (1.52 + (stats.steerSpeed - 12) * 0.045) *
        (this.isDrifting ? 1.36 : 1.0) *
        speedFactor;
      const dirSign = this.speed >= 0 ? 1 : -1;
      this.carHeading -= this.steerNorm * turnRate * dirSign * dt;
    }

    // Forward & right basis vectors from carHeading (heading 0 => forward is -Z)
    const fwdX = -Math.sin(this.carHeading);
    const fwdZ = -Math.cos(this.carHeading);
    const rightX = Math.cos(this.carHeading);
    const rightZ = -Math.sin(this.carHeading);

    // Advance car across the city road (plus subtle lateral slide while drifting)
    const stepDist = this.speed * dt;
    const driftSlide = this.isDrifting ? -this.steerNorm * stepDist * 0.16 : 0;
    this.playerX += fwdX * stepDist + rightX * driftSlide;
    this.playerZ += fwdZ * stepDist + rightZ * driftSlide;

    // Keep car cleanly inside the city road map bounds
    const pad = 10;
    const minX = this.cityBounds.min.x + pad;
    const maxX = this.cityBounds.max.x - pad;
    const minZ = this.cityBounds.min.z + pad;
    const maxZ = this.cityBounds.max.z - pad;
    if (this.playerX < minX) this.playerX = minX;
    else if (this.playerX > maxX) this.playerX = maxX;
    if (this.playerZ < minZ) this.playerZ = minZ;
    else if (this.playerZ > maxZ) this.playerZ = maxZ;

    if (stepDist > 0) {
      this.distanceM += stepDist * 0.55;
      this.score += stepDist * (this.isBoosting ? 2.4 : 1.35);
    }

    // Raycast road elevation so car drives right on top of city hills & asphalt
    const sampledY = this.sampleRoadHeight(this.playerX, this.playerZ, this.groundY);
    this.groundY = THREE.MathUtils.damp(this.groundY, sampledY, 16, dt);

    // Airborne jump arc physics vs road-surface contact
    if (this.isAirborne) {
      this.playerVy -= 36 * dt;
      this.playerY += this.playerVy * dt;
      if (this.playerY <= this.groundY) {
        this.playerY = this.groundY;
        this.playerVy = 0;
        this.isAirborne = false;
        this.suspensionSquash = 0.78;
        this.cameraShake = Math.max(this.cameraShake, 0.25);
        this.spawnBurst(this.playerX, this.groundY + 0.2, this.playerZ, 6, 0xe2e8f0, 'smoke');
      }
    } else {
      this.playerY = this.groundY;
    }

    // Visual body kinematics (drift yaw, body roll, slope/jump pitch, suspension spring)
    const speedLeanScale = THREE.MathUtils.clamp(absSpeed / 16, 0, 1);
    const targetYaw = -this.steerNorm * (this.isDrifting ? 0.34 : 0.06) * speedLeanScale;
    const targetRoll = -this.steerNorm * (this.isDrifting ? 0.12 : 0.045) * speedLeanScale;
    const slopeAheadY = this.sampleRoadHeight(
      this.playerX + fwdX * 2.4,
      this.playerZ + fwdZ * 2.4,
      this.groundY
    );
    const roadSlopePitch = THREE.MathUtils.clamp(
      Math.atan2(slopeAheadY - this.groundY, 2.4),
      -0.2,
      0.2
    );
    const targetPitch = this.isAirborne
      ? THREE.MathUtils.clamp(this.playerVy * 0.025, -0.22, 0.34)
      : roadSlopePitch;

    this.visualYaw = THREE.MathUtils.damp(this.visualYaw, targetYaw, 10, dt);
    this.visualRoll = THREE.MathUtils.damp(this.visualRoll, targetRoll, 10, dt);
    this.visualPitch = THREE.MathUtils.damp(this.visualPitch, targetPitch, 9, dt);
    this.suspensionSquash = THREE.MathUtils.damp(this.suspensionSquash, 1.0, 12, dt);

    this.playerRig.root.position.set(this.playerX, this.playerY, this.playerZ);
    this.playerRig.root.rotation.set(0, this.carHeading, 0);
    this.playerRig.bodyGroup.rotation.set(this.visualPitch, this.visualYaw, this.visualRoll);
    this.playerRig.bodyGroup.scale.set(
      1 + (1 - this.suspensionSquash) * 0.35,
      this.suspensionSquash,
      1 + (1 - this.suspensionSquash) * 0.2
    );

    // Animate all 4 wheels continuously (forward/reverse rolling spin + smooth front-wheel steering)
    for (const w of this.playerRig.wheelSpinPivots) {
      w.pivot.rotation.x -= (this.speed * dt) / w.radius;
    }
    const targetFrontSteerRad = -this.steerNorm * 0.48; // ~27.5 deg smooth left/right lock
    this.frontWheelAngle = THREE.MathUtils.damp(this.frontWheelAngle, targetFrontSteerRad, 14, dt);
    for (const steerPivot of this.playerRig.frontSteerPivots) {
      steerPivot.rotation.y = this.frontWheelAngle;
    }

    // Brake lights intensity
    this.playerRig.brakeLightMat.emissiveIntensity = brakeInput || this.isDrifting ? 3.2 : 0.9;

    // Nitro exhaust flames
    for (const flame of this.playerRig.nitroFlames) {
      flame.visible = this.isBoosting;
      if (this.isBoosting) {
        const flicker = 0.78 + Math.sin(this.elapsedTime * 65) * 0.3;
        flame.scale.set(1, 1, flicker * 1.35);
      }
    }

    // Power-up visuals
    if (this.magnetTimer > 0) {
      this.magnetTimer = Math.max(0, this.magnetTimer - dt);
      this.playerRig.magnetRing.visible = true;
      const pulse = 0.95 + Math.sin(this.elapsedTime * 10) * 0.12;
      this.playerRig.magnetRing.scale.set(pulse, pulse, 1);
    } else {
      this.playerRig.magnetRing.visible = false;
    }
    this.playerRig.shieldMesh.visible = this.shieldActive;
    if (this.shieldActive) {
      this.playerRig.shieldMesh.rotation.y += dt * 1.4;
    }

    // Emit drift skid marks & tire smoke behind rear wheels along carHeading
    const rearOffset = -1.35;
    const rearCenterX = this.playerX + fwdX * rearOffset;
    const rearCenterZ = this.playerZ + fwdZ * rearOffset;
    if (this.isDrifting) {
      this.skidAccum += dt;
      if (this.skidAccum >= 0.032) {
        this.skidAccum = 0;
        this.spawnSkidMark(
          rearCenterX - rightX * 0.92,
          this.groundY + 0.04,
          rearCenterZ - rightZ * 0.92
        );
        this.spawnSkidMark(
          rearCenterX + rightX * 0.92,
          this.groundY + 0.04,
          rearCenterZ + rightZ * 0.92
        );
      }
      this.smokeAccum += dt;
      if (this.smokeAccum >= 0.04) {
        this.smokeAccum = 0;
        this.spawnSmoke(
          rearCenterX - rightX * 0.92,
          this.groundY + 0.22,
          rearCenterZ - rightZ * 0.92
        );
        this.spawnSmoke(
          rearCenterX + rightX * 0.92,
          this.groundY + 0.22,
          rearCenterZ + rightZ * 0.92
        );
      }
    } else if (this.isBoosting) {
      this.smokeAccum += dt;
      if (this.smokeAccum >= 0.06) {
        this.smokeAccum = 0;
        const jitter = (Math.random() - 0.5) * 1.0;
        this.spawnSpark(
          this.playerX - fwdX * 2.4 + rightX * jitter,
          this.groundY + 0.35,
          this.playerZ - fwdZ * 2.4 + rightZ * jitter,
          0x38bdf8
        );
      }
    }

    // World & collectibles updates (NO traffic or police cars)
    this.updateSpawners(fwdX, fwdZ, rightX, rightZ);
    this.updatePickups(dt);
    this.updateRamps();
    this.updateEnvironmentLighting(dt, true);
    this.updateRain(dt);
    this.updateParticles(dt);
    this.checkMissionCompletion();

    // Procedural driving audio
    const speedNorm = THREE.MathUtils.clamp(absSpeed / Math.max(12, maxForwardUnits * 1.15), 0, 1);
    const rpmNorm =
      absSpeed < 0.3
        ? gasInput
          ? 0.28
          : 0.1
        : ((speedNorm * 5) % 1) * 0.65 + speedNorm * 0.35;
    this.audio.updateDrivingAudio(
      rpmNorm,
      this.isDrifting,
      this.isBoosting,
      false,
      this.elapsedTime
    );

    // Throttled HUD update (~25Hz so steering wheel rotation feels ultra smooth)
    this.hudEmitAccum += dt;
    if (this.hudEmitAccum >= 0.04) {
      this.hudEmitAccum = 0;
      this.emitHud();
    }
  }

  private updateSpawners(
    fwdX: number,
    fwdZ: number,
    rightX: number,
    rightZ: number
  ): void {
    // 1. Spawn Jump Ramps ahead along current driving heading
    if (this.distanceM >= this.nextRampSpawnDist) {
      const ramp = this.rampPool.find((r) => !r.active);
      if (ramp) {
        const distAhead = 68;
        const latOffset = (Math.random() - 0.5) * 6.5;
        const rx = this.playerX + fwdX * distAhead + rightX * latOffset;
        const rz = this.playerZ + fwdZ * distAhead + rightZ * latOffset;
        const ry = this.sampleRoadHeight(rx, rz, this.groundY);

        ramp.active = true;
        ramp.x = rx;
        ramp.y = ry;
        ramp.z = rz;
        ramp.heading = this.carHeading;
        ramp.triggered = false;
        ramp.mesh.position.set(rx, ry + 0.02, rz);
        ramp.mesh.rotation.set(0, this.carHeading, 0);
        ramp.mesh.visible = true;

        // Place 5 coins in a parabolic arc above/beyond the ramp
        for (let c = 0; c < 5; c++) {
          const coin = this.pickupPool.find((p) => !p.active && p.kind === 'coin');
          if (!coin) break;
          const arcT = (c + 1) / 6;
          const cx = rx + fwdX * (5 + c * 4.5);
          const cz = rz + fwdZ * (5 + c * 4.5);
          const cy = ry + 1.6 + Math.sin(arcT * Math.PI) * 3.8;
          coin.active = true;
          coin.x = cx;
          coin.baseY = cy;
          coin.y = cy;
          coin.z = cz;
          coin.mesh.position.set(cx, cy, cz);
          coin.mesh.visible = true;
        }
      }
      this.nextRampSpawnDist = this.distanceM + 85 + Math.random() * 45;
    }

    // 2. Spawn Coins, Gems & Power-ups ahead on the road surface
    if (this.distanceM >= this.nextPickupSpawnDist) {
      const roll = Math.random();
      const distAhead = 52;
      const latOffset = (Math.random() - 0.5) * 7.5;
      const baseX = this.playerX + fwdX * distAhead + rightX * latOffset;
      const baseZ = this.playerZ + fwdZ * distAhead + rightZ * latOffset;
      const surfY = this.sampleRoadHeight(baseX, baseZ, this.groundY);

      if (roll < 0.16) {
        const pKinds: ('magnet' | 'nitro' | 'shield')[] = ['magnet', 'nitro', 'shield'];
        const chosen = pKinds[Math.floor(Math.random() * pKinds.length)];
        const item = this.pickupPool.find((p) => !p.active && p.kind === chosen);
        if (item) {
          item.active = true;
          item.x = baseX;
          item.baseY = surfY + 1.1;
          item.y = item.baseY;
          item.z = baseZ;
          item.mesh.position.set(item.x, item.y, item.z);
          item.mesh.visible = true;
        }
      } else if (roll < 0.3) {
        const gem = this.pickupPool.find((p) => !p.active && p.kind === 'gem');
        if (gem) {
          gem.active = true;
          gem.x = baseX;
          gem.baseY = surfY + 1.05;
          gem.y = gem.baseY;
          gem.z = baseZ;
          gem.mesh.position.set(gem.x, gem.y, gem.z);
          gem.mesh.visible = true;
        }
      } else {
        for (let c = 0; c < 5; c++) {
          const coin = this.pickupPool.find((p) => !p.active && p.kind === 'coin');
          if (!coin) break;
          const cx = baseX + fwdX * (c * 3.8);
          const cz = baseZ + fwdZ * (c * 3.8);
          const cy = this.sampleRoadHeight(cx, cz, surfY) + 0.9;
          coin.active = true;
          coin.x = cx;
          coin.baseY = cy;
          coin.y = cy;
          coin.z = cz;
          coin.mesh.position.set(cx, cy, cz);
          coin.mesh.visible = true;
        }
      }
      this.nextPickupSpawnDist = this.distanceM + 26 + Math.random() * 14;
    }
  }

  private updatePickups(dt: number): void {
    for (const p of this.pickupPool) {
      if (!p.active) continue;

      const distSq = (p.x - this.playerX) ** 2 + (p.z - this.playerZ) ** 2;
      if (distSq > 135 * 135) {
        p.active = false;
        p.mesh.visible = false;
        continue;
      }

      // Spin & bob animation
      p.mesh.rotation.y += dt * 3.4;
      p.y = p.baseY + Math.sin(this.elapsedTime * 4.5 + p.z * 0.2) * 0.16;

      // Magnet pull on coins & gems
      if (this.magnetTimer > 0 && (p.kind === 'coin' || p.kind === 'gem')) {
        if (distSq < 256) {
          p.x = THREE.MathUtils.damp(p.x, this.playerX, 9.5, dt);
          p.z = THREE.MathUtils.damp(p.z, this.playerZ, 9.5, dt);
          p.y = THREE.MathUtils.damp(p.y, this.playerY + 0.9, 9.5, dt);
        }
      }

      p.mesh.position.set(p.x, p.y, p.z);

      // Pickup collision
      const dx = this.playerX - p.x;
      const dz = this.playerZ - p.z;
      const dy = Math.abs(this.playerY + 0.85 - p.y);
      if (dx * dx + dz * dz < 2.6 * 2.6 && dy < 2.0) {
        p.active = false;
        p.mesh.visible = false;
        if (p.kind === 'coin') {
          this.runCoins += 1;
          this.score += 25;
          this.audio.playCoin();
          this.spawnBurst(p.x, p.y, p.z, 4, 0xfacc15, 'spark');
        } else if (p.kind === 'gem') {
          this.runGems += 1;
          this.score += 120;
          this.audio.playGem();
          this.spawnBurst(p.x, p.y, p.z, 6, 0x22d3ee, 'spark');
          this.showBanner('GEM +1', 'cyan', 1.0);
        } else if (p.kind === 'magnet') {
          this.magnetTimer = 10;
          this.audio.playPowerup();
          this.showBanner('COIN MAGNET ACTIVE', 'amber', 1.5);
        } else if (p.kind === 'nitro') {
          this.nitro = 100;
          this.audio.playPowerup();
          this.showBanner('NITRO TANK FULL', 'amber', 1.4);
        } else if (p.kind === 'shield') {
          this.shieldActive = true;
          this.audio.playPowerup();
          this.showBanner('ENERGY SHIELD ARMED', 'cyan', 1.5);
        }
      }
    }
  }

  private updateRamps(): void {
    for (const r of this.rampPool) {
      if (!r.active) continue;
      const distSq = (r.x - this.playerX) ** 2 + (r.z - this.playerZ) ** 2;
      if (distSq > 140 * 140) {
        r.active = false;
        r.mesh.visible = false;
        continue;
      }
      if (!r.triggered && !this.isAirborne && distSq < 3.2 * 3.2) {
        r.triggered = true;
        this.isAirborne = true;
        this.playerVy = 17.8;
        this.score += 110;
        this.nitro = Math.min(100, this.nitro + 18);
        this.audio.playJump();
        this.showBanner('RAMP LAUNCH +110', 'emerald', 1.3);
      }
    }
  }

  private checkMissionCompletion(): void {
    if (this.missionCompletedInRun || this.activeMission.goalType === 'endless') return;
    const val = this.getMissionCurrentValue();
    if (val >= this.activeMission.targetValue) {
      this.missionCompletedInRun = true;
      this.audio.playGem();
      this.showBanner('MISSION COMPLETE!', 'emerald', 2.4);
      this.finishRun('finished');
    }
  }

  private getMissionCurrentValue(): number {
    switch (this.activeMission.goalType) {
      case 'coins':
        return this.runCoins;
      case 'drift':
        return Math.round(this.driftDistanceM);
      case 'distance':
      case 'endless':
        return Math.round(this.distanceM);
      case 'police':
        return Math.round(this.runElapsedSec);
    }
  }

  private finishRun(reason: 'traffic' | 'police' | 'finished'): void {
    this.screen = 'gameover';
    this.audio.setDriveLoopActive(false);
    if (reason !== 'finished') {
      this.audio.playCrash(false);
      this.cameraShake = 0.95;
      this.spawnBurst(this.playerX, this.playerY + 0.9, this.playerZ, 18, 0xf97316, 'spark');
      this.spawnBurst(this.playerX, this.playerY + 0.7, this.playerZ, 10, 0x94a3b8, 'smoke');
    }

    const finalScore = Math.round(this.score);
    const isNewHighScore = finalScore > this.currentHighScore;
    const summary: RunSummary = {
      score: finalScore,
      isNewHighScore,
      distanceM: Math.round(this.distanceM),
      coinsEarned: this.runCoins,
      gemsEarned: this.runGems,
      nearMisses: this.nearMissCount,
      driftDistanceM: Math.round(this.driftDistanceM),
      missionCompletedNow: this.missionCompletedInRun,
      missionBonusCoins: this.missionCompletedInRun ? this.activeMission.rewardCoins : 0,
      missionBonusGems: this.missionCompletedInRun ? this.activeMission.rewardGems : 0,
      missionTitle: this.activeMission.title,
      levelNumber: this.activeMission.levelNumber,
      crashReason: reason,
    };

    this.emitHud();
    this.callbacks.onGameOver(summary);
  }

  private updateEnvironmentLighting(dt: number, allowWeatherCycle: boolean): void {
    if (this.screen === 'playing' && this.activeMission.timePreset === 'cycle') {
      this.dayCyclePhase = (this.dayCyclePhase + dt / 75) % 1;
    }

    if (allowWeatherCycle && this.activeMission.weather === 'dynamic') {
      this.weatherTimer -= dt;
      if (this.weatherTimer <= 0) {
        this.weather = this.weather === 'sunny' ? 'rain' : 'sunny';
        this.weatherTimer = this.weather === 'rain' ? 16 : 26;
        this.showBanner(
          this.weather === 'rain' ? 'LIGHT RAIN MOVING IN' : 'SKIES CLEARING',
          'cyan',
          1.5
        );
      }
    }

    const p = this.dayCyclePhase;
    let isNight = false;
    if (p < 0.32) {
      const t = THREE.MathUtils.smoothstep(p, 0.2, 0.32);
      _cSky.copy(_cDaySky).lerp(_cSunsetSky, t);
      _cSun.copy(_cDaySun).lerp(_cSunsetSun, t);
      this.sunLight.intensity = THREE.MathUtils.lerp(1.6, 1.35, t);
      this.hemiLight.intensity = THREE.MathUtils.lerp(0.95, 0.72, t);
    } else if (p < 0.56) {
      const t = THREE.MathUtils.smoothstep(p, 0.36, 0.56);
      _cSky.copy(_cSunsetSky).lerp(_cNightSky, t);
      _cSun.copy(_cSunsetSun).lerp(_cNightSun, t);
      this.sunLight.intensity = THREE.MathUtils.lerp(1.35, 0.55, t);
      this.hemiLight.intensity = THREE.MathUtils.lerp(0.72, 0.42, t);
      isNight = t > 0.45;
    } else if (p < 0.85) {
      _cSky.copy(_cNightSky);
      _cSun.copy(_cNightSun);
      this.sunLight.intensity = 0.55;
      this.hemiLight.intensity = 0.42;
      isNight = true;
    } else {
      const t = THREE.MathUtils.smoothstep(p, 0.85, 1.0);
      _cSky.copy(_cNightSky).lerp(_cDaySky, t);
      _cSun.copy(_cNightSun).lerp(_cDaySun, t);
      this.sunLight.intensity = THREE.MathUtils.lerp(0.55, 1.6, t);
      this.hemiLight.intensity = THREE.MathUtils.lerp(0.42, 0.95, t);
      isNight = t < 0.4;
    }

    if (this.weather === 'rain') {
      _cSky.lerp(_cRainTint, isNight ? 0.25 : 0.48);
    }

    (this.scene.background as THREE.Color).copy(_cSky);
    this.fog.color.copy(_cSky);
    this.fog.density = this.weather === 'rain' ? 0.0042 : 0.0022;
    this.sunLight.color.copy(_cSun);
    this.sunLight.position.set(
      this.playerX + 26,
      this.playerY + (isNight ? 32 : 48),
      this.playerZ + 18
    );
    this.sunLight.target.position.set(this.playerX, this.playerY, this.playerZ);
    this.sunLight.target.updateMatrixWorld();

    _cHemiSky.copy(_cSky).lerp(_cWhite, 0.25);
    _cHemiGround.set(isNight ? 0x1e293b : 0x3b4d3f);
    this.hemiLight.color.copy(_cHemiSky);
    this.hemiLight.groundColor.copy(_cHemiGround);

    for (const beam of this.playerRig.headlightBeams) {
      beam.visible = isNight || this.weather === 'rain';
    }
  }

  private updateRain(dt: number): void {
    const showRain = this.weather === 'rain' && this.screen === 'playing';
    this.rainLines.visible = showRain;
    if (!showRain) return;

    const attr = this.rainLines.geometry.attributes.position as THREE.BufferAttribute;
    const arr = this.rainPositions;
    for (let i = 0; i < this.rainCount; i++) {
      const idx = i * 6;
      arr[idx + 1] -= 32 * dt;
      arr[idx + 4] -= 32 * dt;
      arr[idx + 2] += 18 * dt;
      arr[idx + 5] += 18 * dt;
      if (arr[idx + 1] < this.playerY - 2) {
        const rx = this.playerX + (Math.random() - 0.5) * 44;
        const ry = this.playerY + 14 + Math.random() * 10;
        const rz = this.playerZ + (Math.random() - 0.5) * 44;
        arr[idx] = rx;
        arr[idx + 1] = ry;
        arr[idx + 2] = rz;
        arr[idx + 3] = rx - 0.14;
        arr[idx + 4] = ry - 1.3;
        arr[idx + 5] = rz + 0.65;
      }
    }
    attr.needsUpdate = true;
  }

  private spawnSkidMark(x: number, y: number, z: number): void {
    const item = this.skidPool.find((s) => !s.active) ?? this.skidPool[0];
    item.active = true;
    item.life = 1.6;
    item.mesh.position.set(x, y, z);
    item.mesh.rotation.y = this.carHeading + this.visualYaw * 0.4;
    item.mesh.visible = true;
    (item.mesh.material as THREE.MeshBasicMaterial).opacity = 0.5;
  }

  private spawnSmoke(x: number, y: number, z: number): void {
    const p = this.smokePool.find((s) => !s.active);
    if (!p) return;
    p.active = true;
    p.life = 0;
    p.maxLife = 0.42 + Math.random() * 0.18;
    p.vx = (Math.random() - 0.5) * 2.2;
    p.vy = 1.4 + Math.random() * 1.4;
    p.vz = (Math.random() - 0.5) * 2.2;
    p.mesh.position.set(x, y, z);
    p.mesh.scale.setScalar(0.55);
    (p.mesh.material as THREE.MeshBasicMaterial).opacity = 0.55;
    p.mesh.visible = true;
  }

  private spawnSpark(x: number, y: number, z: number, colorHex: number): void {
    const p = this.sparkPool.find((s) => !s.active);
    if (!p) return;
    p.active = true;
    p.life = 0;
    p.maxLife = 0.34 + Math.random() * 0.18;
    p.vx = (Math.random() - 0.5) * 11;
    p.vy = 3.5 + Math.random() * 7;
    p.vz = (Math.random() - 0.5) * 11;
    p.mesh.position.set(x, y, z);
    p.mesh.scale.setScalar(1);
    (p.mesh.material as THREE.MeshBasicMaterial).color.setHex(colorHex);
    (p.mesh.material as THREE.MeshBasicMaterial).opacity = 0.95;
    p.mesh.visible = true;
  }

  private spawnBurst(
    x: number,
    y: number,
    z: number,
    count: number,
    colorHex: number,
    kind: 'spark' | 'smoke'
  ): void {
    for (let i = 0; i < count; i++) {
      if (kind === 'spark') this.spawnSpark(x, y, z, colorHex);
      else this.spawnSmoke(x + (Math.random() - 0.5) * 1.4, y, z + (Math.random() - 0.5) * 1.4);
    }
  }

  private updateParticles(dt: number): void {
    for (const p of this.smokePool) {
      if (!p.active) continue;
      p.life += dt;
      if (p.life >= p.maxLife) {
        p.active = false;
        p.mesh.visible = false;
        continue;
      }
      const t = p.life / p.maxLife;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      p.mesh.scale.setScalar(0.55 + t * 1.65);
      (p.mesh.material as THREE.MeshBasicMaterial).opacity = 0.52 * (1 - t);
    }

    for (const p of this.sparkPool) {
      if (!p.active) continue;
      p.life += dt;
      if (p.life >= p.maxLife) {
        p.active = false;
        p.mesh.visible = false;
        continue;
      }
      const t = p.life / p.maxLife;
      p.vy -= 18 * dt;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y = Math.max(this.groundY + 0.08, p.mesh.position.y + p.vy * dt);
      p.mesh.position.z += p.vz * dt;
      p.mesh.scale.setScalar(1 - t * 0.7);
      (p.mesh.material as THREE.MeshBasicMaterial).opacity = 1 - t;
    }

    for (const s of this.skidPool) {
      if (!s.active) continue;
      s.life -= dt;
      if (s.life <= 0) {
        s.active = false;
        s.mesh.visible = false;
        continue;
      }
      (s.mesh.material as THREE.MeshBasicMaterial).opacity = Math.min(0.48, s.life * 0.35);
    }
  }

  private updateCamera(dt: number): void {
    const fwdX = -Math.sin(this.carHeading);
    const fwdZ = -Math.cos(this.carHeading);
    const rightX = Math.cos(this.carHeading);
    const rightZ = -Math.sin(this.carHeading);

    if (this.screen === 'title' || this.garageShowcase) {
      // Smooth orbital showcase around the custom car on the 3D city road
      this.showcaseAngle += dt * (this.garageShowcase ? 0.55 : 0.24);
      const radius = this.garageShowcase ? 6.6 : 8.2;
      const elev = this.garageShowcase ? 2.4 : 3.2;
      _vTargetPos.set(
        this.playerX + Math.sin(this.showcaseAngle) * radius,
        this.playerY + elev,
        this.playerZ + Math.cos(this.showcaseAngle) * radius
      );
      _vLookPos.set(
        this.playerX + fwdX * (this.garageShowcase ? 0 : 1.5),
        this.playerY + 0.9,
        this.playerZ + fwdZ * (this.garageShowcase ? 0 : 1.5)
      );
      this.camPos.x = THREE.MathUtils.damp(this.camPos.x, _vTargetPos.x, 5, dt);
      this.camPos.y = THREE.MathUtils.damp(this.camPos.y, _vTargetPos.y, 5, dt);
      this.camPos.z = THREE.MathUtils.damp(this.camPos.z, _vTargetPos.z, 8, dt);
      this.camLook.lerp(_vLookPos, 1 - Math.exp(-6 * dt));
      this.camera.position.copy(this.camPos);
      this.camera.lookAt(this.camLook);
      this.camera.fov = THREE.MathUtils.damp(this.camera.fov, 54, 5, dt);
      this.camera.updateProjectionMatrix();
      return;
    }

    // 4-Mode Multi-Camera Switcher oriented smoothly behind carHeading
    let targetFov = 62;
    const dampPos = this.cameraMode === 'bonnet' ? 18 : 9.5;
    switch (this.cameraMode) {
      case 'bonnet':
        _vTargetPos.set(
          this.playerX + fwdX * 0.65,
          this.playerY + 1.48,
          this.playerZ + fwdZ * 0.65
        );
        _vLookPos.set(
          this.playerX + fwdX * 26 - rightX * this.visualYaw * 4,
          this.playerY + 1.12,
          this.playerZ + fwdZ * 26 - rightZ * this.visualYaw * 4
        );
        targetFov = this.isBoosting ? 78 : 66;
        break;
      case 'wheel':
        _vTargetPos.set(
          this.playerX - rightX * 2.35 - fwdX * 2.7,
          this.playerY + 0.78,
          this.playerZ - rightZ * 2.35 - fwdZ * 2.7
        );
        _vLookPos.set(
          this.playerX + fwdX * 14 + rightX * 0.4,
          this.playerY + 0.68,
          this.playerZ + fwdZ * 14 + rightZ * 0.4
        );
        targetFov = this.isBoosting ? 74 : 62;
        break;
      case 'topdown':
        _vTargetPos.set(
          this.playerX - fwdX * 5.8,
          this.playerY + 23.5,
          this.playerZ - fwdZ * 5.8
        );
        _vLookPos.set(
          this.playerX + fwdX * 11,
          this.playerY,
          this.playerZ + fwdZ * 11
        );
        targetFov = 54;
        break;
      case 'chase':
      default: {
        const backDist = this.isBoosting ? 8.6 : 7.6;
        const sideSwing = -this.visualYaw * 2.0;
        _vTargetPos.set(
          this.playerX - fwdX * backDist + rightX * sideSwing,
          this.playerY + 3.55,
          this.playerZ - fwdZ * backDist + rightZ * sideSwing
        );
        _vLookPos.set(
          this.playerX + fwdX * 15,
          this.playerY + 1.1,
          this.playerZ + fwdZ * 15
        );
        targetFov = this.isBoosting ? 75 : this.isDrifting ? 66 : 62;
        break;
      }
    }

    this.camPos.x = THREE.MathUtils.damp(this.camPos.x, _vTargetPos.x, dampPos, dt);
    this.camPos.y = THREE.MathUtils.damp(this.camPos.y, _vTargetPos.y, dampPos, dt);
    this.camPos.z = THREE.MathUtils.damp(this.camPos.z, _vTargetPos.z, dampPos, dt);
    this.camLook.x = THREE.MathUtils.damp(this.camLook.x, _vLookPos.x, 12, dt);
    this.camLook.y = THREE.MathUtils.damp(this.camLook.y, _vLookPos.y, 12, dt);
    this.camLook.z = THREE.MathUtils.damp(this.camLook.z, _vLookPos.z, 12, dt);

    this.camera.position.copy(this.camPos);
    if (this.cameraShake > 0.01) {
      this.camera.position.x += (Math.random() - 0.5) * this.cameraShake * 0.7;
      this.camera.position.y += (Math.random() - 0.5) * this.cameraShake * 0.5;
      this.cameraShake = THREE.MathUtils.damp(this.cameraShake, 0, 8, dt);
    }

    this.camera.lookAt(this.camLook);
    this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 6, dt);
    this.camera.updateProjectionMatrix();
  }

  private getTimeOfDayLabel(): string {
    const p = this.dayCyclePhase;
    if (p < 0.28) return 'Daylight';
    if (p < 0.5) return 'Sunset';
    if (p < 0.85) return 'Midnight';
    return 'Dawn';
  }

  private emitHud(): void {
    const absSpeed = Math.abs(this.speed);
    const speedKmh = Math.round(absSpeed / 0.34);
    const isReversing = this.speed < -0.35;
    const speedRatio = THREE.MathUtils.clamp(
      speedKmh / Math.max(40, this.customMaxSpeedKmh),
      0,
      1
    );
    const gear = isReversing ? 0 : speedKmh === 0 ? 0 : Math.min(6, Math.max(1, Math.ceil(speedRatio * 6)));
    const gearLabel = isReversing ? 'R' : speedKmh === 0 ? 'N' : `G${gear}`;
    const rpmNorm =
      speedKmh === 0
        ? 0.1
        : isReversing
        ? THREE.MathUtils.clamp(0.24 + (speedKmh / 65) * 0.55, 0.2, 0.85)
        : THREE.MathUtils.clamp(((speedRatio * 6) % 1) * 0.72 + 0.22, 0.16, 1);

    const fwdX = -Math.sin(this.carHeading);
    const fwdZ = -Math.cos(this.carHeading);
    const rightX = Math.cos(this.carHeading);
    const rightZ = -Math.sin(this.carHeading);

    const blips: MinimapBlip[] = [];
    let blipId = 1;
    for (const r of this.rampPool) {
      if (!r.active) continue;
      const dx = r.x - this.playerX;
      const dz = r.z - this.playerZ;
      const ahead = dx * fwdX + dz * fwdZ;
      const side = dx * rightX + dz * rightZ;
      if (ahead > -10 && ahead < 130 && Math.abs(side) < 24) {
        blips.push({
          id: blipId++,
          laneNorm: THREE.MathUtils.clamp(side / 14, -1, 1),
          relZ: ahead / 130,
          kind: 'ramp',
        });
      }
    }

    const missionVal = this.getMissionCurrentValue();
    const missionProgress = THREE.MathUtils.clamp(
      missionVal / Math.max(1, this.activeMission.targetValue),
      0,
      1
    );

    this.callbacks.onHudUpdate({
      speedKmh,
      maxSpeedKmh: this.customMaxSpeedKmh,
      rpmNorm,
      gear,
      gearLabel,
      isReversing,
      gasActive: this.gasActive,
      brakeActive: this.brakeActive,
      score: Math.round(this.score),
      distanceM: Math.round(this.distanceM),
      runCoins: this.runCoins,
      runGems: this.runGems,
      nitro: Math.round(this.nitro),
      isBoosting: this.isBoosting,
      isDrifting: this.isDrifting,
      driftScore: Math.round(this.driftScore),
      driftDistanceM: Math.round(this.driftDistanceM),
      isAirborne: this.isAirborne,
      magnetTimer: Number(this.magnetTimer.toFixed(1)),
      shieldActive: this.shieldActive,
      policeActive: false,
      policeDistanceM: 0,
      policeSurviveSec: 0,
      wantedStars: 0,
      nearMissCount: this.nearMissCount,
      timeOfDayLabel: this.getTimeOfDayLabel(),
      weather: this.weather,
      missionProgress,
      missionCurrentValue: missionVal,
      missionComplete: this.missionCompletedInRun,
      bannerText: this.bannerText,
      bannerTone: this.bannerTone,
      minimapBlips: blips,
      playerLaneNorm: 0,
      steerNorm: this.steerNorm,
    });
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);
    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('blur', this.handleBlur);
    this.renderer.domElement.removeEventListener('webglcontextlost', this.handleContextLost);
    if (this.cityRoadRoot) {
      this.scene.remove(this.cityRoadRoot);
      this.cityRoadRoot = null;
    }
    this.cityRoadMeshes = [];
    this.audio.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
