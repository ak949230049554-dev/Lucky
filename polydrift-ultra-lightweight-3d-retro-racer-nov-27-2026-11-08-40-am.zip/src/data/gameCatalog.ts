import {
  CarSpec,
  CarUpgrades,
  DailyRewardDay,
  DifficultyTier,
  HindiTrackPreset,
  MissionDef,
  MissionGoalType,
  SaveData,
  TimePreset,
  WeatherMode,
} from '../types/game';

export const SAVE_STORAGE_KEY = 'polydrift_retro_4mb_save_v2';
export const TOTAL_LEVELS = 500;

export const HINDI_TRACK_PRESETS: HindiTrackPreset[] = [
  {
    id: 'desi_highway',
    title: 'Desi Highway Beat',
    hindiTitle: 'देसी हाईवे बीट',
    vibe: 'Bollywood Pop · Dhol + Synth Hook',
    bpm: 122,
  },
  {
    id: 'punjabi_dhol',
    title: 'Punjabi Turbo Dhol',
    hindiTitle: 'पंजाबी टर्बो ढोल',
    vibe: 'High-Energy Bhangra · Tumbi Riff',
    bpm: 132,
  },
  {
    id: 'mumbai_lofi',
    title: 'Mumbai Night Lofi',
    hindiTitle: 'मुंबई नाइट लोफ़ी',
    vibe: 'Raag Yaman Chill · Highway Cruise',
    bpm: 94,
  },
  {
    id: 'retro_90s',
    title: '90s Bollywood Retro',
    hindiTitle: '90s बॉलीवुड रेट्रो',
    vibe: 'Classic Filmi Synth Groove',
    bpm: 116,
  },
  {
    id: 'arcade_synth',
    title: 'PolyDrift Arcade',
    hindiTitle: 'आर्केड रेट्रो सिंथ',
    vibe: '80s Turbo Outrun Arpeggio',
    bpm: 128,
  },
];

export interface LevelChapter {
  index: number;
  startLevel: number;
  endLevel: number;
  name: string;
  timePreset: TimePreset;
  weather: WeatherMode | 'dynamic';
}

export const LEVEL_CHAPTERS: LevelChapter[] = [
  { index: 0, startLevel: 1, endLevel: 50, name: 'Goa Coastal Easy', timePreset: 'day', weather: 'sunny' },
  { index: 1, startLevel: 51, endLevel: 100, name: 'Marine Drive Sprint', timePreset: 'sunset', weather: 'sunny' },
  { index: 2, startLevel: 101, endLevel: 150, name: 'Lonavala Ghat Drift', timePreset: 'sunset', weather: 'dynamic' },
  { index: 3, startLevel: 151, endLevel: 200, name: 'Jaipur Pink Highway', timePreset: 'day', weather: 'sunny' },
  { index: 4, startLevel: 201, endLevel: 250, name: 'Yamuna Express Rush', timePreset: 'cycle', weather: 'sunny' },
  { index: 5, startLevel: 251, endLevel: 300, name: 'Mumbai Monsoon Storm', timePreset: 'sunset', weather: 'rain' },
  { index: 6, startLevel: 301, endLevel: 350, name: 'Shimla Midnight Run', timePreset: 'night', weather: 'rain' },
  { index: 7, startLevel: 351, endLevel: 400, name: 'Deccan Police Chase', timePreset: 'night', weather: 'dynamic' },
  { index: 8, startLevel: 401, endLevel: 450, name: 'GT Turbo Masters', timePreset: 'cycle', weather: 'dynamic' },
  { index: 9, startLevel: 451, endLevel: 500, name: 'Highway King Legend', timePreset: 'cycle', weather: 'dynamic' },
];

export function getChapterForLevel(level: number): LevelChapter {
  const clamped = Math.max(1, Math.min(TOTAL_LEVELS, Math.floor(level)));
  const idx = Math.min(LEVEL_CHAPTERS.length - 1, Math.floor((clamped - 1) / 50));
  return LEVEL_CHAPTERS[idx];
}

export function getLevelDef(rawLevel: number): MissionDef {
  const level = Math.max(1, Math.min(TOTAL_LEVELS, Math.floor(rawLevel)));
  const chapter = getChapterForLevel(level);
  const progress = (level - 1) / (TOTAL_LEVELS - 1); // 0.0 at Lv 1 -> 1.0 at Lv 500

  // Smooth difficulty tiers — Level 1 to 15 are extra gentle ("Halka")
  let difficultyLabel: DifficultyTier = 'Legend';
  if (level <= 15) difficultyLabel = 'Halka (Easy)';
  else if (level <= 60) difficultyLabel = 'Easy';
  else if (level <= 160) difficultyLabel = 'Medium';
  else if (level <= 300) difficultyLabel = 'Hard';
  else if (level <= 420) difficultyLabel = 'Pro';

  // Speed scale: Lv 1 starts very light (0.72x), gradually reaches 1.48x at Lv 500
  const speedScale = Number((0.72 + Math.pow(progress, 0.85) * 0.76).toFixed(3));

  // Traffic gap scale: Lv 1 has super wide forgiving spacing (1.52x), tightens to 0.58x at Lv 500
  const trafficGapScale = Number((1.52 - Math.pow(progress, 0.8) * 0.94).toFixed(3));

  // Max simultaneous traffic cars per wave: Lv 1-14 only 1 car per wave (halka!), Lv 15-220 max 2, Lv 221+ up to 3
  const maxTrafficWave = level <= 14 ? 1 : level <= 220 ? 2 : 3;

  // Police chase appears on boss/pursuit levels (every 10th level from Lv 20+, or chapter 8+)
  const isBossPolice = (level >= 20 && level % 10 === 0) || (level >= 351 && level <= 400 && level % 3 === 0);

  // Rotate objective type cleanly so gameplay stays fresh across all 500 levels
  let goalType: MissionGoalType = 'distance';
  let targetValue = 300;
  let subtitle = '';

  if (level === 1) {
    // Level 1: Extra Halka introductory cruise!
    goalType = 'distance';
    targetValue = 280;
    subtitle = 'Halka Start — Easy cruise 280m with wide open traffic';
  } else if (isBossPolice) {
    goalType = 'police';
    targetValue = Math.round(18 + progress * 42);
    subtitle = `Boss Pursuit — Evade Police Interceptor for ${targetValue}s`;
  } else if (level % 4 === 2) {
    goalType = 'coins';
    targetValue = Math.round(10 + progress * 85);
    subtitle = `Collect ${targetValue} Gold Coins along ${chapter.name}`;
  } else if (level % 4 === 3 && level >= 7) {
    goalType = 'drift';
    targetValue = Math.round(120 + progress * 680);
    subtitle = `Drift ${targetValue}m through ${chapter.name}`;
  } else {
    goalType = 'distance';
    targetValue = Math.round(300 + progress * 2400);
    subtitle = `Reach ${targetValue.toLocaleString()}m on ${chapter.name}`;
  }

  const rewardCoins = Math.round(65 + level * 2.4 + (isBossPolice ? 120 : 0));
  const rewardGems = level % 5 === 0 || isBossPolice ? Math.max(2, Math.floor(2 + level / 35)) : 1;

  return {
    id: `level_${level}`,
    title: `Level ${level} · ${chapter.name}`,
    subtitle,
    goalType,
    targetValue,
    rewardCoins,
    rewardGems,
    timePreset: chapter.timePreset,
    weather: chapter.weather,
    policeFromStart: isBossPolice,
    difficulty: Math.min(6, Math.max(1, Math.ceil(level / 85))),
    levelNumber: level,
    chapterName: chapter.name,
    difficultyLabel,
    speedScale,
    trafficGapScale,
    maxTrafficWave,
  };
}

export const ENDLESS_MISSION: MissionDef = {
  id: 'endless_arcade',
  title: 'Endless Highway',
  subtitle: 'Free Endless Mode — Dynamic Day/Night, Rain & Police Heat',
  goalType: 'endless',
  targetValue: 2000,
  rewardCoins: 150,
  rewardGems: 3,
  timePreset: 'cycle',
  weather: 'dynamic',
  policeFromStart: false,
  difficulty: 1,
  difficultyLabel: 'Medium',
  speedScale: 0.96,
  trafficGapScale: 1.0,
  maxTrafficWave: 2,
};

export const CAR_CATALOG: CarSpec[] = [
  {
    id: 'custom_gemera',
    name: 'Koenigsegg Gemera GT',
    era: 'Custom 3D Hyper-GT',
    style: 'hyper',
    primaryColor: '#f8fafc',
    accentColor: '#f59e0b',
    stripeColor: '#ef4444',
    rimColor: '#e2e8f0',
    priceCoins: 0,
    priceGems: 0,
    baseTopSpeed: 240,
    baseHandling: 8.6,
    baseBrakes: 8.5,
  },
];

export const DAILY_REWARDS: DailyRewardDay[] = [
  { day: 1, coins: 120, gems: 2, label: 'Day 1' },
  { day: 2, coins: 180, gems: 3, label: 'Day 2' },
  { day: 3, coins: 250, gems: 5, label: 'Day 3' },
  { day: 4, coins: 340, gems: 7, label: 'Day 4' },
  { day: 5, coins: 450, gems: 10, label: 'Day 5' },
  { day: 6, coins: 600, gems: 14, label: 'Day 6' },
  { day: 7, coins: 900, gems: 25, label: 'Jackpot' },
];

export const MAX_UPGRADE_LEVEL = 4; // 0..4 => Displays as Lv.1..Lv.5

export function getUpgradeCost(currentLevel: number): number {
  return Math.round(90 * Math.pow(1.65, currentLevel));
}

export function getCarEffectiveStats(car: CarSpec, up: CarUpgrades) {
  return {
    topSpeedKmh: Math.round(car.baseTopSpeed + up.speed * 14),
    handling: Math.min(10, Number((car.baseHandling + up.handling * 0.45).toFixed(1))),
    brakes: Math.min(10, Number((car.baseBrakes + up.brakes * 0.45).toFixed(1))),
    maxSpeedUnits: (car.baseTopSpeed + up.speed * 14) * 0.34,
    steerSpeed: 10.5 + (car.baseHandling + up.handling * 0.45) * 1.15,
    brakeForce: 32 + (car.baseBrakes + up.brakes * 0.45) * 4.2,
  };
}

export function getTodayKey(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

export function createDefaultSaveData(): SaveData {
  const upgrades: Record<string, CarUpgrades> = {};
  for (const car of CAR_CATALOG) {
    upgrades[car.id] = { speed: 0, handling: 0, brakes: 0 };
  }
  return {
    coins: 220,
    gems: 4,
    highScore: 0,
    bestDistance: 0,
    selectedCarId: CAR_CATALOG[0].id,
    unlockedCarIds: [CAR_CATALOG[0].id],
    upgrades,
    completedMissionIds: [],
    completedLevels: [],
    selectedLevel: 1,
    highestLevelUnlocked: 1,
    dailyStreak: 0,
    lastClaimDate: null,
    sfxMuted: false,
    musicMuted: false,
    musicVolume: 0.75,
    selectedHindiTrackId: 'desi_highway',
    cameraMode: 'chase',
    selectedHighway: null,
  };
}

export function loadSaveData(): SaveData {
  const fallback = createDefaultSaveData();
  try {
    const raw =
      window.localStorage.getItem(SAVE_STORAGE_KEY) ||
      window.localStorage.getItem('polydrift_retro_4mb_save_v1');
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    const upgrades: Record<string, CarUpgrades> = { ...fallback.upgrades };
    if (parsed.upgrades) {
      for (const car of CAR_CATALOG) {
        if (parsed.upgrades[car.id]) {
          upgrades[car.id] = {
            speed: Math.min(MAX_UPGRADE_LEVEL, Math.max(0, parsed.upgrades[car.id].speed ?? 0)),
            handling: Math.min(MAX_UPGRADE_LEVEL, Math.max(0, parsed.upgrades[car.id].handling ?? 0)),
            brakes: Math.min(MAX_UPGRADE_LEVEL, Math.max(0, parsed.upgrades[car.id].brakes ?? 0)),
          };
        }
      }
    }
    return {
      ...fallback,
      ...parsed,
      selectedCarId: CAR_CATALOG[0].id,
      unlockedCarIds: [CAR_CATALOG[0].id],
      upgrades,
      completedMissionIds: Array.isArray(parsed.completedMissionIds)
        ? parsed.completedMissionIds
        : [],
      completedLevels: Array.isArray(parsed.completedLevels) ? parsed.completedLevels : [],
      selectedLevel: Math.max(1, Math.min(TOTAL_LEVELS, parsed.selectedLevel ?? 1)),
      highestLevelUnlocked: Math.max(1, Math.min(TOTAL_LEVELS, parsed.highestLevelUnlocked ?? 1)),
    };
  } catch {
    return fallback;
  }
}

export function persistSaveData(data: SaveData): void {
  try {
    window.localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Ignore quota errors in private sandboxes
  }
}
