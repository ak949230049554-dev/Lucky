export interface UnityScriptFile {
  id: string;
  filename: string;
  category: string;
  summary: string;
  code: string;
}

export interface UnityBuildStep {
  step: string;
  title: string;
  budgetImpact: string;
  details: string[];
}

export const UNITY_BUILD_STEPS: UnityBuildStep[] = [
  {
    step: '01',
    title: 'Project Template & Pipeline (Built-in RP)',
    budgetImpact: 'Saves ~3.2 MB vs URP',
    details: [
      'Use Unity 2022.3 LTS with the Built-in Render Pipeline (3D Core) — avoid URP/HDRP shader variants which bloat APK size by 3–6 MB.',
      'Remove unused packages in Package Manager: Timeline, Visual Scripting, Multiplayer, JetBrains Rider, Collaboration, Analytics, and Unity Ads.',
      'Keep only TextMeshPro (with a single ASCII-only subset SDF font atlas at 256x256) or standard legacy UI Text for minimal binary overhead.',
    ],
  },
  {
    step: '02',
    title: 'Retro Vertex-Colored Meshes & Baked Lightmaps',
    budgetImpact: '0 KB Texture Overhead · 60 FPS on 2GB RAM',
    details: [
      'Author cars, trees, ramps, and road tiles as low-poly meshes (150–650 tris per car) painted purely via Vertex Colors in Blender.',
      'Assign a single custom Unlit/VertexColor or Mobile/Diffuse VertexColor shader across all environment & vehicle props so Unity batches them into 1–3 draw calls (Dynamic Batching + GPU Instancing).',
      'For the Garage scene, bake a single 256x256 DXT/ETC2 Lightmap (Directional Mode: Non-Directional) and disable real-time shadows on 2GB RAM devices — use a 64x64 procedural blob shadow quad under every car.',
    ],
  },
  {
    step: '03',
    title: 'Android Player Settings (4MB–8MB APK Target)',
    budgetImpact: 'Final APK: ~4.6 MB – 6.8 MB',
    details: [
      'Scripting Backend: IL2CPP · Target Architecture: ARMv7 only (drop ARM64 only for ultra-small direct-sideload builds; for Play Store AAB enable Split APKs by ABI so each user downloads only 1 architecture).',
      'Managed Stripping Level: High + Strip Engine Code: ON. Disable unused built-in modules via link.xml (Physics2D, Terrain, Cloth, Video, VR/XR, Wind, AI Navigation).',
      'Compression Method: LZ4HC (smallest APK & fast streaming decompression on low-RAM Android CPUs).',
      'Graphics API: OpenGLES3 only (remove Vulkan to cut ~1.4 MB of shader compiler overhead on older 2GB RAM phones).',
    ],
  },
  {
    step: '04',
    title: 'Audio & 2GB RAM Zero-GC Discipline',
    budgetImpact: '< 120 KB Total Audio · Zero GC Spikes',
    details: [
      'Import SFX as Force To Mono, Vorbis Quality 20–35%, Sample Rate 22050 Hz (keeps engine loop, coin chime, and crash clip under 25–45 KB each).',
      'Zero WheelColliders: Use simple raycast/kinematic ArcadeCarController with fixed-size Object Pools for road chunks, traffic, coins, skid marks, and smoke particles.',
      'Set QualitySettings.vSyncCount = 0; Application.targetFrameRate = 60; and Physics.defaultSolverIterations = 2 for rock-solid 60 FPS on entry-level MediaTek/Snapdragon chipsets.',
    ],
  },
];

export const UNITY_CSHARP_SCRIPTS: UnityScriptFile[] = [
  {
    id: 'car',
    filename: 'ArcadeCarController.cs',
    category: 'Car Physics & Drift',
    summary: 'Zero-WheelCollider arcade controller with drift yaw, nitro boost, jump ramp arcs, skid trail, and smoke emission.',
    code: `using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class ArcadeCarController : MonoBehaviour
{
    [Header("Base Stats (Scaled by Garage Upgrades)")]
    public float maxSpeed = 62f;
    public float acceleration = 28f;
    public float steerSpeed = 16f;
    public float brakeDecel = 45f;
    public float roadHalfWidth = 7.2f;

    [Header("Drift & Nitro")]
    public float driftYawAngle = 22f;
    public float nitroMultiplier = 1.42f;
    public float nitroCapacity = 100f;
    public float nitroDrainRate = 28f;
    public float nitroDriftGain = 18f;

    [Header("FX References (Zero-Alloc)")]
    public Transform visualBody;
    public Transform[] wheels;
    public TrailRenderer[] skidTrails;
    public ParticleSystem tireSmokeFX;
    public ParticleSystem nitroFlameFX;

    public float CurrentSpeed { get; private set; }
    public float Nitro { get; private set; } = 100f;
    public bool IsDrifting { get; private set; }
    public bool IsBoosting { get; private set; }
    public bool IsGrounded { get; private set; } = true;

    private Rigidbody _rb;
    private float _steerInput;
    private float _verticalVel;
    private float _visualYaw;
    private float _visualRoll;

    void Awake()
    {
        _rb = GetComponent<Rigidbody>();
        _rb.useGravity = false; // Manual lightweight gravity for crisp jump arcs
        _rb.constraints = RigidbodyConstraints.FreezeRotation;
        ApplyGarageUpgrades();
    }

    public void ApplyGarageUpgrades()
    {
        int spdLv = GarageSaveManager.GetUpgradeLevel("speed");
        int hndLv = GarageSaveManager.GetUpgradeLevel("handling");
        int brkLv = GarageSaveManager.GetUpgradeLevel("brakes");
        maxSpeed += spdLv * 4.5f;
        steerSpeed += hndLv * 1.4f;
        brakeDecel += brkLv * 5.0f;
    }

    public void SetInputs(float steer, bool brakeOrDrift, bool nitroPressed)
    {
        _steerInput = Mathf.Clamp(steer, -1f, 1f);
        IsDrifting = IsGrounded && brakeOrDrift && Mathf.Abs(_steerInput) > 0.15f && CurrentSpeed > 18f;
        IsBoosting = nitroPressed && Nitro > 2f;
    }

    public void LaunchJump(float impulseY)
    {
        if (!IsGrounded) return;
        IsGrounded = false;
        _verticalVel = impulseY;
    }

    void FixedUpdate()
    {
        float dt = Time.fixedDeltaTime;
        float targetMax = IsBoosting ? maxSpeed * nitroMultiplier : maxSpeed;

        if (IsBoosting)
        {
            Nitro = Mathf.Max(0f, Nitro - nitroDrainRate * dt);
            CurrentSpeed = Mathf.MoveTowards(CurrentSpeed, targetMax, acceleration * 1.9f * dt);
        }
        else if (IsDrifting)
        {
            Nitro = Mathf.Min(nitroCapacity, Nitro + nitroDriftGain * dt);
            CurrentSpeed = Mathf.MoveTowards(CurrentSpeed, maxSpeed * 0.88f, brakeDecel * 0.25f * dt);
        }
        else
        {
            CurrentSpeed = Mathf.MoveTowards(CurrentSpeed, targetMax, acceleration * dt);
        }

        // Lateral arcade movement
        float lateralFactor = IsDrifting ? 1.25f : 1.0f;
        Vector3 pos = _rb.position;
        pos.z += CurrentSpeed * dt;
        pos.x = Mathf.Clamp(pos.x + _steerInput * steerSpeed * lateralFactor * dt, -roadHalfWidth, roadHalfWidth);

        // Lightweight manual jump arc
        if (!IsGrounded)
        {
            _verticalVel -= 34f * dt;
            pos.y += _verticalVel * dt;
            if (pos.y <= 0f)
            {
                pos.y = 0f;
                _verticalVel = 0f;
                IsGrounded = true;
            }
        }

        _rb.MovePosition(pos);
        UpdateVisuals(dt);
    }

    void UpdateVisuals(float dt)
    {
        float targetYaw = _steerInput * (IsDrifting ? driftYawAngle : 8f);
        float targetRoll = -_steerInput * (IsDrifting ? 6.5f : 3.2f);
        _visualYaw = Mathf.Lerp(_visualYaw, targetYaw, dt * 10f);
        _visualRoll = Mathf.Lerp(_visualRoll, targetRoll, dt * 10f);
        visualBody.localRotation = Quaternion.Euler(0f, _visualYaw, _visualRoll);

        float wheelSpin = CurrentSpeed * 120f * dt;
        for (int i = 0; i < wheels.Length; i++)
            wheels[i].Rotate(wheelSpin, 0f, 0f, Space.Self);

        for (int i = 0; i < skidTrails.Length; i++)
            skidTrails[i].emitting = IsDrifting;

        if (tireSmokeFX)
        {
            var em = tireSmokeFX.emission;
            em.enabled = IsDrifting;
        }
        if (nitroFlameFX)
        {
            var em = nitroFlameFX.emission;
            em.enabled = IsBoosting;
        }
    }
}`,
  },
  {
    id: 'camera',
    filename: 'MultiCameraSwitcher.cs',
    category: '4-View Smooth Camera',
    summary: 'Cycles Chase, Bonnet/Hood, Cinematic Wheel, and Top-Down views using frame-rate-independent exponential damping.',
    code: `using UnityEngine;

public class MultiCameraSwitcher : MonoBehaviour
{
    public enum CamMode { Chase = 0, Bonnet = 1, Wheel = 2, TopDown = 3 }

    public Transform targetCar;
    public ArcadeCarController carController;
    public CamMode currentMode = CamMode.Chase;

    [Header("Smooth Damping")]
    public float posDamping = 9f;
    public float rotDamping = 11f;
    public float baseFov = 62f;
    public float boostFov = 76f;

    private Camera _cam;

    void Awake()
    {
        _cam = GetComponent<Camera>();
        currentMode = (CamMode)PlayerPrefs.GetInt("CamMode", 0);
    }

    public void CycleCameraMode()
    {
        currentMode = (CamMode)(((int)currentMode + 1) % 4);
        PlayerPrefs.SetInt("CamMode", (int)currentMode);
    }

    void LateUpdate()
    {
        if (!targetCar) return;
        float dt = Time.deltaTime;
        Vector3 offset;
        Vector3 lookOffset;

        switch (currentMode)
        {
            case CamMode.Bonnet:
                offset = new Vector3(0f, 1.38f, 0.85f);
                lookOffset = new Vector3(0f, 1.1f, 24f);
                break;
            case CamMode.Wheel:
                offset = new Vector3(-2.35f, 0.72f, -2.6f);
                lookOffset = new Vector3(0.4f, 0.65f, 12f);
                break;
            case CamMode.TopDown:
                offset = new Vector3(0f, 21f, -5.5f);
                lookOffset = new Vector3(0f, 0f, 9.5f);
                break;
            default: // Chase
                offset = new Vector3(0f, 3.6f, -7.8f);
                lookOffset = new Vector3(0f, 1.2f, 14f);
                break;
        }

        Vector3 desiredPos = targetCar.position + offset;
        float posT = 1f - Mathf.Exp(-posDamping * dt);
        transform.position = Vector3.Lerp(transform.position, desiredPos, posT);

        Quaternion desiredRot = Quaternion.LookRotation((targetCar.position + lookOffset) - transform.position);
        float rotT = 1f - Mathf.Exp(-rotDamping * dt);
        transform.rotation = Quaternion.Slerp(transform.rotation, desiredRot, rotT);

        float targetFov = (carController && carController.IsBoosting) ? boostFov : baseFov;
        _cam.fieldOfView = Mathf.Lerp(_cam.fieldOfView, targetFov, 1f - Mathf.Exp(-6f * dt));
    }
}`,
  },
  {
    id: 'pool',
    filename: 'ObjectPoolManager.cs',
    category: 'Zero-GC Object Pooling',
    summary: 'Pre-warms fixed pools for rotating Coins, Gems, Traffic Cars, and Road Segments so 2GB RAM phones never trigger GC pauses.',
    code: `using System.Collections.Generic;
using UnityEngine;

public class ObjectPoolManager : MonoBehaviour
{
    [System.Serializable]
    public struct PoolConfig
    {
        public string key;
        public GameObject prefab;
        public int prewarmCount;
    }

    public static ObjectPoolManager Instance { get; private set; }
    public PoolConfig[] pools;

    private readonly Dictionary<string, Queue<GameObject>> _lookup = new();

    void Awake()
    {
        Instance = this;
        for (int i = 0; i < pools.Length; i++)
        {
            var q = new Queue<GameObject>(pools[i].prewarmCount);
            for (int c = 0; c < pools[i].prewarmCount; c++)
            {
                GameObject obj = Instantiate(pools[i].prefab, transform);
                obj.SetActive(false);
                q.Enqueue(obj);
            }
            _lookup[pools[i].key] = q;
        }
    }

    public GameObject Spawn(string key, Vector3 pos, Quaternion rot)
    {
        if (!_lookup.TryGetValue(key, out var q) || q.Count == 0) return null;
        GameObject obj = q.Dequeue();
        obj.transform.SetPositionAndRotation(pos, rot);
        obj.SetActive(true);
        return obj;
    }

    public void Despawn(string key, GameObject obj)
    {
        obj.SetActive(false);
        if (_lookup.TryGetValue(key, out var q)) q.Enqueue(obj);
    }
}`,
  },
  {
    id: 'road',
    filename: 'EndlessRoadAndEnvironment.cs',
    category: 'Road, Day/Night & Weather',
    summary: 'Recycles endless road segments, interpolates Day/Sunset/Night sky & fog colors, and toggles lightweight rain particles.',
    code: `using UnityEngine;

public class EndlessRoadAndEnvironment : MonoBehaviour
{
    public Transform player;
    public Transform[] roadSegments; // 8 pre-placed low-poly road chunks
    public float segmentLength = 30f;

    [Header("Day / Night Cycle")]
    public Light sunLight;
    public Gradient skyColorOverDay;
    public Gradient sunColorOverDay;
    public float cycleDurationSec = 90f;

    [Header("Dynamic Weather")]
    public ParticleSystem rainParticles;
    private float _cycleTime;
    private int _leadIndex;
    private float _nextZ;

    void Start()
    {
        for (int i = 0; i < roadSegments.Length; i++)
        {
            roadSegments[i].position = new Vector3(0f, 0f, i * segmentLength);
            _nextZ = (i + 1) * segmentLength;
        }
    }

    void Update()
    {
        // Recycle road segment behind player
        Transform oldest = roadSegments[_leadIndex];
        if (player.position.z - oldest.position.z > segmentLength * 1.6f)
        {
            oldest.position = new Vector3(0f, 0f, _nextZ);
            _nextZ += segmentLength;
            _leadIndex = (_leadIndex + 1) % roadSegments.Length;
        }

        // Smooth Day/Night sky, fog & sun transition
        _cycleTime = (_cycleTime + Time.deltaTime / cycleDurationSec) % 1f;
        Color sky = skyColorOverDay.Evaluate(_cycleTime);
        RenderSettings.fogColor = sky;
        Camera.main.backgroundColor = sky;

        if (sunLight)
        {
            sunLight.color = sunColorOverDay.Evaluate(_cycleTime);
            float elevation = Mathf.Sin(_cycleTime * Mathf.PI * 2f) * 55f + 20f;
            sunLight.transform.rotation = Quaternion.Euler(elevation, -30f, 0f);
        }
    }

    public void SetRainActive(bool active)
    {
        if (!rainParticles) return;
        var em = rainParticles.emission;
        em.enabled = active;
    }
}`,
  },
  {
    id: 'garage',
    filename: 'GarageSaveManager.cs',
    category: 'Offline PlayerPrefs Save',
    summary: 'Handles offline Coins, Gems, Car Unlocks, Speed/Handling/Brakes upgrades, High Score, and Daily Rewards via PlayerPrefs.',
    code: `using UnityEngine;

public static class GarageSaveManager
{
    public static int Coins
    {
        get => PlayerPrefs.GetInt("Coins", 200);
        set { PlayerPrefs.SetInt("Coins", value); PlayerPrefs.Save(); }
    }

    public static int Gems
    {
        get => PlayerPrefs.GetInt("Gems", 5);
        set { PlayerPrefs.SetInt("Gems", value); PlayerPrefs.Save(); }
    }

    public static int HighScore
    {
        get => PlayerPrefs.GetInt("HighScore", 0);
        set { if (value > HighScore) { PlayerPrefs.SetInt("HighScore", value); PlayerPrefs.Save(); } }
    }

    public static string SelectedCarId
    {
        get => PlayerPrefs.GetString("SelectedCar", "civic_88");
        set { PlayerPrefs.SetString("SelectedCar", value); PlayerPrefs.Save(); }
    }

    public static bool IsCarUnlocked(string carId)
        => carId == "civic_88" || PlayerPrefs.GetInt("Car_" + carId, 0) == 1;

    public static bool TryBuyCar(string carId, int coinCost, int gemCost)
    {
        if (Coins < coinCost || Gems < gemCost) return false;
        Coins -= coinCost;
        Gems -= gemCost;
        PlayerPrefs.SetInt("Car_" + carId, 1);
        SelectedCarId = carId;
        return true;
    }

    public static int GetUpgradeLevel(string stat)
        => PlayerPrefs.GetInt("Up_" + SelectedCarId + "_" + stat, 0);

    public static bool TryUpgradeStat(string stat, int cost)
    {
        int lv = GetUpgradeLevel(stat);
        if (lv >= 4 || Coins < cost) return false;
        Coins -= cost;
        PlayerPrefs.SetInt("Up_" + SelectedCarId + "_" + stat, lv + 1);
        PlayerPrefs.Save();
        return true;
    }
}`,
  },
  {
    id: 'shader',
    filename: 'RetroVertexColor.shader',
    category: '0-Texture Mobile Shader',
    summary: 'Ultra-fast Mobile Vertex-Color + Fog shader with zero texture samplers for vibrant retro visuals at 60 FPS.',
    code: `Shader "PolyDrift/MobileVertexColorLit"
{
    Properties
    {
        _AmbientTint ("Ambient Tint", Color) = (0.38, 0.42, 0.52, 1)
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 100

        Pass
        {
            Tags { "LightMode"="ForwardBase" }
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_fog
            #include "UnityCG.cginc"

            fixed4 _AmbientTint;
            fixed4 _LightColor0;

            struct appdata
            {
                float4 vertex : POSITION;
                float3 normal : NORMAL;
                fixed4 color  : COLOR;
            };

            struct v2f
            {
                float4 pos   : SV_POSITION;
                fixed4 color : COLOR;
                UNITY_FOG_COORDS(0)
            };

            v2f vert(appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                float3 worldNormal = UnityObjectToWorldNormal(v.normal);
                float ndotl = saturate(dot(worldNormal, _WorldSpaceLightPos0.xyz));
                // Bake crisp flat retro lighting right in the vertex stage!
                o.color.rgb = v.color.rgb * (_AmbientTint.rgb + _LightColor0.rgb * ndotl);
                o.color.a = 1.0;
                UNITY_TRANSFER_FOG(o, o.pos);
                return o;
            }

            fixed4 frag(v2f i) : SV_Target
            {
                fixed4 col = i.color;
                UNITY_APPLY_FOG(i.fogCoord, col);
                return col;
            }
            ENDCG
        }
    }
}`,
  },
];
