import { useCallback, useEffect, useRef, useState } from 'react';
import {
  CameraMode,
  CarSpec,
  CarUpgrades,
  GameScreen,
  HindiTrackId,
  HudSnapshot,
  MissionDef,
  ModalView,
  RunSummary,
  SaveData,
  SelectedMapHighway,
  UploadedSong,
} from './types/game';
import {
  CAR_CATALOG,
  DAILY_REWARDS,
  getLevelDef,
  getTodayKey,
  getUpgradeCost,
  HINDI_TRACK_PRESETS,
  loadSaveData,
  MAX_UPGRADE_LEVEL,
  persistSaveData,
  TOTAL_LEVELS,
} from './data/gameCatalog';
import { RacingEngine } from './game/RacingEngine';
import { TitleOverlay } from './components/TitleOverlay';
import { HudOverlay } from './components/HudOverlay';
import { GarageModal } from './components/GarageModal';
import { DailyRewardsModal } from './components/MissionsAndRewardsModal';
import { LevelsModal } from './components/LevelsModal';
import { HindiMusicModal } from './components/HindiMusicModal';
import { RouteMapModal } from './components/RouteMapModal';
import { GameOverModal, PauseModal } from './components/GameModals';
import { UnityGuideModal } from './components/UnityGuideModal';

const CAMERA_CYCLE: CameraMode[] = ['chase', 'bonnet', 'wheel', 'topdown'];

const INITIAL_HUD: HudSnapshot = {
  speedKmh: 0,
  maxSpeedKmh: 180,
  rpmNorm: 0.1,
  gear: 0,
  gearLabel: 'N',
  isReversing: false,
  gasActive: false,
  brakeActive: false,
  score: 0,
  distanceM: 0,
  runCoins: 0,
  runGems: 0,
  nitro: 80,
  isBoosting: false,
  isDrifting: false,
  driftScore: 0,
  driftDistanceM: 0,
  isAirborne: false,
  magnetTimer: 0,
  shieldActive: false,
  policeActive: false,
  policeDistanceM: 0,
  policeSurviveSec: 0,
  wantedStars: 0,
  nearMissCount: 0,
  timeOfDayLabel: 'Daylight',
  weather: 'sunny',
  missionProgress: 0,
  missionCurrentValue: 0,
  missionComplete: false,
  bannerText: null,
  bannerTone: 'amber',
  minimapBlips: [],
  playerLaneNorm: 0,
  steerNorm: 0,
};

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<RacingEngine | null>(null);
  const customAudioRef = useRef<HTMLAudioElement | null>(null);

  const [save, setSave] = useState<SaveData>(() => loadSaveData());
  const [screen, setScreen] = useState<GameScreen>('title');
  const [modal, setModal] = useState<ModalView>('none');
  const [activeMission, setActiveMission] = useState<MissionDef>(() =>
    getLevelDef(loadSaveData().selectedLevel)
  );
  const [garageViewingCarId, setGarageViewingCarId] = useState<string>(
    () => loadSaveData().selectedCarId
  );
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [runSummary, setRunSummary] = useState<RunSummary | null>(null);
  const [webglLost, setWebglLost] = useState(false);

  // Google Maps Case A Quota Defense state
  const [gmpQuotaExceeded, setGmpQuotaExceeded] = useState(false);

  // Hindi Song & Car Radio Player state
  const [uploadedSongs, setUploadedSongs] = useState<UploadedSong[]>([]);
  const [activeUploadedId, setActiveUploadedId] = useState<string | null>(null);
  const [isUploadedPlaying, setIsUploadedPlaying] = useState(false);
  const [isRadioPreviewing, setIsRadioPreviewing] = useState(false);

  const saveRef = useRef(save);
  saveRef.current = save;
  const screenRef = useRef(screen);
  screenRef.current = screen;
  const modalRef = useRef(modal);
  modalRef.current = modal;
  const activeMissionRef = useRef(activeMission);
  activeMissionRef.current = activeMission;
  const uploadedSongsRef = useRef(uploadedSongs);
  uploadedSongsRef.current = uploadedSongs;

  const selectedCar =
    CAR_CATALOG.find((c) => c.id === save.selectedCarId) ?? CAR_CATALOG[0];

  const activeUploadedSong =
    uploadedSongs.find((s) => s.id === activeUploadedId) ?? null;
  const activePresetTrack =
    HINDI_TRACK_PRESETS.find((t) => t.id === save.selectedHindiTrackId) ??
    HINDI_TRACK_PRESETS[0];

  const activeSongLabel =
    activeUploadedSong && isUploadedPlaying
      ? activeUploadedSong.name
      : activePresetTrack.title;

  const updateSave = useCallback((updater: (prev: SaveData) => SaveData) => {
    setSave((prev) => {
      const next = updater(prev);
      persistSaveData(next);
      return next;
    });
  }, []);

  // Listen for Google Maps Platform quota-exceeded notifications (Tier-1 + Tier-2)
  useEffect(() => {
    const onQuotaExceeded = () => setGmpQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
  }, []);

  // Revoke any uploaded song object URLs on unmount
  useEffect(() => {
    return () => {
      uploadedSongsRef.current.forEach((s) => URL.revokeObjectURL(s.url));
    };
  }, []);

  // Initialize isolated Three.js RacingEngine exactly once
  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    const initialSave = saveRef.current;
    const initCar =
      CAR_CATALOG.find((c) => c.id === initialSave.selectedCarId) ?? CAR_CATALOG[0];
    const initUp = initialSave.upgrades[initCar.id] ?? {
      speed: 0,
      handling: 0,
      brakes: 0,
    };

    let engine: RacingEngine;
    try {
      engine = new RacingEngine(
        mount,
        initCar,
        initUp,
        activeMissionRef.current,
        initialSave.cameraMode,
        initialSave.highScore,
        {
          onHudUpdate: (snapshot) => setHud(snapshot),
          onGameOver: (summary) => {
            setRunSummary(summary);
            setScreen('gameover');
            updateSave((prev) => {
              const totalCoins =
                prev.coins + summary.coinsEarned + summary.missionBonusCoins;
              const totalGems =
                prev.gems + summary.gemsEarned + summary.missionBonusGems;
              const completedMissions =
                summary.missionCompletedNow &&
                !prev.completedMissionIds.includes(activeMissionRef.current.id)
                  ? [...prev.completedMissionIds, activeMissionRef.current.id]
                  : prev.completedMissionIds;

              let completedLevels = prev.completedLevels;
              let highestLevelUnlocked = prev.highestLevelUnlocked;
              if (
                summary.missionCompletedNow &&
                typeof summary.levelNumber === 'number'
              ) {
                if (!prev.completedLevels.includes(summary.levelNumber)) {
                  completedLevels = [...prev.completedLevels, summary.levelNumber];
                }
                highestLevelUnlocked = Math.min(
                  TOTAL_LEVELS,
                  Math.max(prev.highestLevelUnlocked, summary.levelNumber + 1)
                );
              }

              return {
                ...prev,
                coins: totalCoins,
                gems: totalGems,
                highScore: Math.max(prev.highScore, summary.score),
                bestDistance: Math.max(prev.bestDistance, summary.distanceM),
                completedMissionIds: completedMissions,
                completedLevels,
                highestLevelUnlocked,
              };
            });
          },
          onContextLost: () => setWebglLost(true),
        }
      );
    } catch {
      setWebglLost(true);
      return;
    }

    engine.audio.setMuted(initialSave.sfxMuted, initialSave.musicMuted);
    engine.audio.setMusicConfig(
      initialSave.selectedHindiTrackId,
      initialSave.musicVolume,
      false
    );
    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, [updateSave]);

  // Keep engine synced with selected car, upgrades, mission, and audio settings
  useEffect(() => {
    const engine = engineRef.current;
    if (!engine) return;
    const activeCarId =
      modal === 'garage' ? garageViewingCarId : save.selectedCarId;
    const car = CAR_CATALOG.find((c) => c.id === activeCarId) ?? CAR_CATALOG[0];
    const up = save.upgrades[car.id] ?? { speed: 0, handling: 0, brakes: 0 };
    engine.updateConfig(
      car,
      up,
      activeMission,
      save.highScore,
      save.sfxMuted,
      save.musicMuted
    );
    engine.audio.setMusicConfig(
      save.selectedHindiTrackId,
      save.musicVolume,
      Boolean(activeUploadedId && isUploadedPlaying)
    );
    engine.setGarageShowcase(modal === 'garage');
    engine.setCameraMode(save.cameraMode);
  }, [
    save,
    modal,
    garageViewingCarId,
    activeMission,
    activeUploadedId,
    isUploadedPlaying,
  ]);

  // Sync HTML5 <audio> element with custom Hindi song playlist state
  useEffect(() => {
    const audioEl = customAudioRef.current;
    if (!audioEl) return;
    audioEl.volume = save.musicMuted ? 0 : Math.max(0, Math.min(1, save.musicVolume));

    if (!activeUploadedSong) {
      audioEl.pause();
      if (audioEl.src) {
        audioEl.removeAttribute('src');
        audioEl.load();
      }
      return;
    }

    if (audioEl.src !== activeUploadedSong.url) {
      audioEl.src = activeUploadedSong.url;
    }

    if (isUploadedPlaying && !save.musicMuted) {
      audioEl.play().catch(() => {
        setIsUploadedPlaying(false);
      });
    } else {
      audioEl.pause();
    }
  }, [activeUploadedSong, isUploadedPlaying, save.musicVolume, save.musicMuted]);

  const startRace = useCallback(
    (missionOverride?: MissionDef) => {
      const engine = engineRef.current;
      if (!engine) return;
      const m = missionOverride ?? activeMissionRef.current;
      if (missionOverride) {
        setActiveMission(missionOverride);
        if (typeof missionOverride.levelNumber === 'number') {
          const lv = missionOverride.levelNumber;
          updateSave((prev) => ({ ...prev, selectedLevel: lv }));
        }
      }
      setModal('none');
      setRunSummary(null);
      setScreen('playing');
      engine.audio.unlock();
      engine.audio.playUiClick();

      const equippedCar =
        CAR_CATALOG.find((c) => c.id === saveRef.current.selectedCarId) ??
        CAR_CATALOG[0];
      const equippedUp = saveRef.current.upgrades[equippedCar.id] ?? {
        speed: 0,
        handling: 0,
        brakes: 0,
      };
      engine.updateConfig(
        equippedCar,
        equippedUp,
        m,
        saveRef.current.highScore,
        saveRef.current.sfxMuted,
        saveRef.current.musicMuted
      );
      engine.startRun(m);
    },
    [updateSave]
  );

  const handleNextLevel = useCallback(() => {
    const curLv = runSummary?.levelNumber ?? activeMissionRef.current.levelNumber ?? 1;
    const nextLv = Math.min(TOTAL_LEVELS, curLv + 1);
    const nextMission = getLevelDef(nextLv);
    startRace(nextMission);
  }, [runSummary, startRace]);

  const cycleCamera = useCallback(() => {
    engineRef.current?.audio.unlock();
    engineRef.current?.audio.playUiClick();
    updateSave((prev) => {
      const idx = CAMERA_CYCLE.indexOf(prev.cameraMode);
      const next = CAMERA_CYCLE[(idx + 1) % CAMERA_CYCLE.length];
      return { ...prev, cameraMode: next };
    });
  }, [updateSave]);

  const handlePauseToggle = useCallback(() => {
    const engine = engineRef.current;
    if (!engine) return;
    if (screenRef.current === 'playing') {
      engine.setPaused(true);
      setScreen('paused');
    } else if (screenRef.current === 'paused') {
      engine.setPaused(false);
      setScreen('playing');
    }
  }, []);

  // Global keyboard shortcuts (Enter to start, C to switch camera, Esc to pause/close modal)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const target = e.target as HTMLElement | null;
      const isInputFocused =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable);
      if (isInputFocused && e.code !== 'Escape') return;

      if (e.code === 'Escape') {
        if (modalRef.current !== 'none') {
          setModal('none');
        } else if (
          screenRef.current === 'playing' ||
          screenRef.current === 'paused'
        ) {
          handlePauseToggle();
        }
      } else if (
        e.code === 'KeyC' &&
        screenRef.current === 'playing' &&
        modalRef.current === 'none'
      ) {
        cycleCamera();
      } else if (
        (e.code === 'Enter' || e.code === 'Space') &&
        screenRef.current === 'title' &&
        modalRef.current === 'none'
      ) {
        e.preventDefault();
        startRace();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [cycleCamera, handlePauseToggle, startRace]);

  // Garage actions
  const handleEquipCar = (carId: string) => {
    engineRef.current?.audio.unlock();
    engineRef.current?.audio.playUiClick();
    updateSave((prev) => ({ ...prev, selectedCarId: carId }));
  };

  const handleBuyCar = (car: CarSpec) => {
    engineRef.current?.audio.unlock();
    updateSave((prev) => {
      if (prev.unlockedCarIds.includes(car.id)) return prev;
      if (prev.coins < car.priceCoins || prev.gems < car.priceGems) return prev;
      engineRef.current?.audio.playGem();
      return {
        ...prev,
        coins: prev.coins - car.priceCoins,
        gems: prev.gems - car.priceGems,
        unlockedCarIds: [...prev.unlockedCarIds, car.id],
        selectedCarId: car.id,
      };
    });
  };

  const handleUpgradeStat = (carId: string, stat: keyof CarUpgrades) => {
    engineRef.current?.audio.unlock();
    updateSave((prev) => {
      const cur = prev.upgrades[carId] ?? { speed: 0, handling: 0, brakes: 0 };
      if (cur[stat] >= MAX_UPGRADE_LEVEL) return prev;
      const cost = getUpgradeCost(cur[stat]);
      if (prev.coins < cost) return prev;
      engineRef.current?.audio.playPowerup();
      return {
        ...prev,
        coins: prev.coins - cost,
        upgrades: {
          ...prev.upgrades,
          [carId]: { ...cur, [stat]: cur[stat] + 1 },
        },
      };
    });
  };

  // Daily rewards claim
  const handleClaimDailyReward = () => {
    const today = getTodayKey();
    engineRef.current?.audio.unlock();
    updateSave((prev) => {
      if (prev.lastClaimDate === today) return prev;
      const reward = DAILY_REWARDS[prev.dailyStreak % DAILY_REWARDS.length];
      engineRef.current?.audio.playGem();
      return {
        ...prev,
        coins: prev.coins + reward.coins,
        gems: prev.gems + reward.gems,
        dailyStreak: prev.dailyStreak + 1,
        lastClaimDate: today,
      };
    });
  };

  // Hindi Song & Radio handlers
  const handleSelectPresetTrack = (trackId: HindiTrackId) => {
    engineRef.current?.audio.unlock();
    engineRef.current?.audio.playUiClick();
    setIsUploadedPlaying(false);
    setActiveUploadedId(null);
    updateSave((prev) => ({
      ...prev,
      selectedHindiTrackId: trackId,
      musicMuted: false,
    }));
    setIsRadioPreviewing(true);
    engineRef.current?.audio.setRadioPreview(true);
  };

  const handleToggleRadioPreview = () => {
    engineRef.current?.audio.unlock();
    const next = !isRadioPreviewing;
    if (next) {
      setIsUploadedPlaying(false);
      updateSave((prev) => ({ ...prev, musicMuted: false }));
    }
    setIsRadioPreviewing(next);
    engineRef.current?.audio.setRadioPreview(next);
  };

  const handleUploadSongs = (files: FileList) => {
    const additions: UploadedSong[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!file) continue;
      const cleanName = file.name.replace(/\.[^/.]+$/, '');
      additions.push({
        id: `${Date.now()}_${i}_${Math.random().toString(36).slice(2, 7)}`,
        name: cleanName || file.name,
        url: URL.createObjectURL(file),
      });
    }
    if (additions.length === 0) return;
    setUploadedSongs((prev) => [...prev, ...additions]);
    setActiveUploadedId(additions[0].id);
    setIsUploadedPlaying(true);
    setIsRadioPreviewing(false);
    engineRef.current?.audio.setRadioPreview(false);
    updateSave((prev) => ({ ...prev, musicMuted: false }));
  };

  const handlePlayUploadedSong = (song: UploadedSong) => {
    setIsRadioPreviewing(false);
    engineRef.current?.audio.setRadioPreview(false);
    setActiveUploadedId(song.id);
    setIsUploadedPlaying(true);
    updateSave((prev) => ({ ...prev, musicMuted: false }));
  };

  const handleToggleUploadedPause = () => {
    if (!activeUploadedId && uploadedSongs.length > 0) {
      handlePlayUploadedSong(uploadedSongs[0]);
      return;
    }
    setIsUploadedPlaying((prev) => !prev);
  };

  const handleSkipUploaded = (dir: -1 | 1) => {
    if (uploadedSongs.length === 0) return;
    const idx = uploadedSongs.findIndex((s) => s.id === activeUploadedId);
    const nextIdx =
      idx === -1
        ? 0
        : (idx + dir + uploadedSongs.length) % uploadedSongs.length;
    handlePlayUploadedSong(uploadedSongs[nextIdx]);
  };

  const handleRemoveUploadedSong = (id: string) => {
    setUploadedSongs((prev) => {
      const target = prev.find((s) => s.id === id);
      if (target) URL.revokeObjectURL(target.url);
      const remaining = prev.filter((s) => s.id !== id);
      if (activeUploadedId === id) {
        if (remaining.length > 0) {
          setActiveUploadedId(remaining[0].id);
        } else {
          setActiveUploadedId(null);
          setIsUploadedPlaying(false);
        }
      }
      return remaining;
    });
  };

  const handleSelectHighway = (hw: SelectedMapHighway) => {
    engineRef.current?.audio.unlock();
    engineRef.current?.audio.playUiClick();
    updateSave((prev) => ({ ...prev, selectedHighway: hw }));
  };

  const handleRaceOnHighway = (hw: SelectedMapHighway) => {
    updateSave((prev) => ({ ...prev, selectedHighway: hw }));
    startRace();
  };

  const handleReturnToTitle = () => {
    engineRef.current?.returnToTitle();
    setScreen('title');
    setModal('none');
    setRunSummary(null);
  };

  return (
    <main className="relative h-screen w-screen overflow-hidden bg-slate-950 select-none">
      {/* Hidden HTML5 audio element for uploaded Hindi songs */}
      <audio
        ref={customAudioRef}
        onEnded={() => handleSkipUploaded(1)}
        className="hidden"
      />

      {/* Google Maps Platform Case A Quota Exceeded Top Banner */}
      {gmpQuotaExceeded && (
        <div
          role="alert"
          className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between gap-3 border-b border-amber-400/50 bg-amber-950/95 px-4 py-2 text-xs text-amber-100"
        >
          <span>
            This app&apos;s free Google Maps quota has been reached. To restore map features, add your own Google Maps Platform API key in your project settings —{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-300 hover:text-white"
            >
              learn more
            </a>
            .
          </span>
          <button
            type="button"
            onClick={() => setGmpQuotaExceeded(false)}
            className="shrink-0 rounded border border-amber-400/40 px-2 py-0.5 text-[11px] font-semibold text-amber-200 hover:bg-amber-900 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Isolated WebGL Canvas Container (never re-rendered by HUD ticks) */}
      <div ref={canvasMountRef} className="fixed inset-0 z-0 h-full w-full" />

      {/* Graceful fallback if WebGL context is lost */}
      {webglLost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950 p-6 text-center">
          <div className="max-w-sm rounded-xl border border-white/14 bg-slate-900 p-6">
            <h1 className="font-display text-xl font-bold text-white">
              Graphics Context Interrupted
            </h1>
            <p className="mt-2 text-xs text-slate-300">
              WebGL was reset by the browser. Reload the page to restore the 3D racing viewport.
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="mt-4 rounded-lg bg-amber-500 px-5 py-2 text-xs font-bold text-slate-950 cursor-pointer"
            >
              Reload Game
            </button>
          </div>
        </div>
      )}

      {/* Title Screen */}
      {screen === 'title' && modal === 'none' && (
        <TitleOverlay
          save={save}
          selectedCar={selectedCar}
          selectedMission={activeMission}
          activeSongLabel={activeSongLabel}
          onStartRace={() => startRace()}
          onOpenGarage={() => {
            engineRef.current?.audio.unlock();
            engineRef.current?.audio.playUiClick();
            setGarageViewingCarId(save.selectedCarId);
            setModal('garage');
          }}
          onOpenLevels={() => {
            engineRef.current?.audio.unlock();
            engineRef.current?.audio.playUiClick();
            setModal('levels');
          }}
          onOpenMusic={() => {
            engineRef.current?.audio.unlock();
            engineRef.current?.audio.playUiClick();
            setModal('music');
          }}
          onOpenMap={() => {
            engineRef.current?.audio.unlock();
            engineRef.current?.audio.playUiClick();
            setModal('map');
          }}
          onOpenRewards={() => {
            engineRef.current?.audio.unlock();
            engineRef.current?.audio.playUiClick();
            setModal('rewards');
          }}
          onOpenUnityGuide={() => {
            engineRef.current?.audio.unlock();
            engineRef.current?.audio.playUiClick();
            setModal('unity');
          }}
          onToggleAudio={() => {
            engineRef.current?.audio.unlock();
            updateSave((prev) => {
              const muteAll = !(prev.sfxMuted && prev.musicMuted);
              return { ...prev, sfxMuted: muteAll, musicMuted: muteAll };
            });
          }}
        />
      )}

      {/* Active In-Game HUD */}
      {screen === 'playing' && (
        <HudOverlay
          hud={hud}
          mission={activeMission}
          cameraMode={save.cameraMode}
          sfxMuted={save.sfxMuted}
          musicMuted={save.musicMuted}
          activeSongLabel={activeSongLabel}
          highwayName={save.selectedHighway?.name}
          onCycleCamera={cycleCamera}
          onToggleSfx={() =>
            updateSave((prev) => ({ ...prev, sfxMuted: !prev.sfxMuted }))
          }
          onToggleMusic={() =>
            updateSave((prev) => ({ ...prev, musicMuted: !prev.musicMuted }))
          }
          onOpenMusic={() => {
            engineRef.current?.setPaused(true);
            setScreen('paused');
            setModal('music');
          }}
          onPause={handlePauseToggle}
          onTouchControl={(input) => engineRef.current?.setTouchInput(input)}
          onSetMaxSpeedKmh={(kmh) => engineRef.current?.setMaxSpeedKmh(kmh)}
          onAdjustMaxSpeedKmh={(delta) => engineRef.current?.adjustMaxSpeedKmh(delta)}
        />
      )}

      {/* Pause Menu */}
      {screen === 'paused' && modal === 'none' && (
        <PauseModal
          cameraMode={save.cameraMode}
          onSelectCamera={(mode) => {
            engineRef.current?.audio.playUiClick();
            updateSave((prev) => ({ ...prev, cameraMode: mode }));
          }}
          onResume={handlePauseToggle}
          onRestart={() => startRace()}
          onOpenMusic={() => setModal('music')}
          onOpenUnityGuide={() => setModal('unity')}
          onMainMenu={handleReturnToTitle}
        />
      )}

      {/* Game Over Screen */}
      {screen === 'gameover' && runSummary && modal === 'none' && (
        <GameOverModal
          summary={runSummary}
          highScore={save.highScore}
          onRetry={() => startRace()}
          onNextLevel={handleNextLevel}
          onOpenGarage={() => {
            engineRef.current?.returnToTitle();
            setScreen('title');
            setGarageViewingCarId(save.selectedCarId);
            setModal('garage');
          }}
          onMainMenu={handleReturnToTitle}
        />
      )}

      {/* Garage Showcase Modal */}
      {modal === 'garage' && (
        <GarageModal
          save={save}
          viewingCarId={garageViewingCarId}
          onSelectViewingCar={(carId) => {
            engineRef.current?.audio.playUiClick();
            setGarageViewingCarId(carId);
          }}
          onEquipCar={handleEquipCar}
          onBuyCar={handleBuyCar}
          onUpgradeStat={handleUpgradeStat}
          onClose={() => setModal('none')}
          onRaceNow={() => startRace()}
        />
      )}

      {/* Levels 1-500 Modal */}
      {modal === 'levels' && (
        <LevelsModal
          save={save}
          activeMission={activeMission}
          onSelectMission={(m) => {
            engineRef.current?.audio.playUiClick();
            setActiveMission(m);
            if (typeof m.levelNumber === 'number') {
              const lv = m.levelNumber;
              updateSave((prev) => ({ ...prev, selectedLevel: lv }));
            }
          }}
          onStartMission={(m) => startRace(m)}
          onClose={() => setModal('none')}
        />
      )}

      {/* Hindi Song & Car Radio Player Modal */}
      {modal === 'music' && (
        <HindiMusicModal
          save={save}
          isRadioPlaying={isRadioPreviewing || (screen === 'playing' && !isUploadedPlaying && !save.musicMuted)}
          uploadedSongs={uploadedSongs}
          activeUploadedId={activeUploadedId}
          isUploadedPlaying={isUploadedPlaying}
          onSelectPresetTrack={handleSelectPresetTrack}
          onToggleRadioPreview={handleToggleRadioPreview}
          onUploadSongs={handleUploadSongs}
          onPlayUploadedSong={handlePlayUploadedSong}
          onToggleUploadedPause={handleToggleUploadedPause}
          onSkipUploaded={handleSkipUploaded}
          onRemoveUploadedSong={handleRemoveUploadedSong}
          onVolumeChange={(vol) =>
            updateSave((prev) => ({ ...prev, musicVolume: vol, musicMuted: false }))
          }
          onToggleMusicMute={() =>
            updateSave((prev) => ({ ...prev, musicMuted: !prev.musicMuted }))
          }
          onClose={() => setModal('none')}
        />
      )}

      {/* Real-World Google Maps Highway Route Explorer Modal */}
      {modal === 'map' && (
        <RouteMapModal
          selectedHighway={save.selectedHighway}
          onSelectHighway={handleSelectHighway}
          onRaceHere={handleRaceOnHighway}
          onClose={() => setModal('none')}
        />
      )}

      {/* Daily Rewards Modal */}
      {modal === 'rewards' && (
        <DailyRewardsModal
          save={save}
          onClaimReward={handleClaimDailyReward}
          onClose={() => setModal('none')}
        />
      )}

      {/* Unity C# & 4MB APK Guide Modal */}
      {modal === 'unity' && <UnityGuideModal onClose={() => setModal('none')} />}
    </main>
  );
}
