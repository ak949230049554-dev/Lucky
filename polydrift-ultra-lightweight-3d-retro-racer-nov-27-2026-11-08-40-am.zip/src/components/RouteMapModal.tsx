import React, { useCallback, useEffect, useState } from 'react';
import {
  APIProvider,
  APILoadingStatus,
  AdvancedMarker,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useAdvancedMarkerRef,
  useApiLoadingStatus,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import { MapPin, Play, Search, X } from 'lucide-react';
import { SelectedMapHighway } from '../types/game';

interface RouteMapModalProps {
  selectedHighway: SelectedMapHighway | null;
  onSelectHighway: (hw: SelectedMapHighway) => void;
  onRaceHere: (hw: SelectedMapHighway) => void;
  onClose: () => void;
}

const HIGHWAY_PRESET_QUERIES = [
  'Mumbai Pune Expressway, India',
  'Goa Coastal Highway NH66, India',
  'Yamuna Expressway, India',
  'Jaipur Agra Highway NH21, India',
  'Marine Drive Mumbai, India',
];

const INDIA_DEFAULT_CENTER = { lat: 20.5937, lng: 78.9629 };

interface HighwayPinItemProps {
  place: SelectedMapHighway;
  isSelected: boolean;
  onSelect: (p: SelectedMapHighway) => void;
  onRace: (p: SelectedMapHighway) => void;
}

const HighwayPinItem: React.FC<HighwayPinItemProps> = ({
  place,
  isSelected,
  onSelect,
  onRace,
}) => {
  const [markerRef, marker] = useAdvancedMarkerRef();

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={{ lat: place.lat, lng: place.lng }}
        title={place.name}
        onClick={() => onSelect(place)}
      >
        <Pin
          background={isSelected ? '#f59e0b' : '#06b6d4'}
          borderColor={isSelected ? '#fef3c7' : '#0e7490'}
          glyphColor="#0f172a"
          scale={isSelected ? 1.25 : 1.0}
        />
      </AdvancedMarker>
      {isSelected && marker && (
        <InfoWindow anchor={marker} maxWidth={240}>
          <div className="p-1 text-slate-900">
            <div className="text-xs font-bold">{place.name}</div>
            <div className="mt-0.5 text-[11px] text-slate-600">{place.formattedAddress}</div>
            <button
              type="button"
              onClick={() => onRace(place)}
              className="mt-2 w-full rounded bg-amber-500 px-2.5 py-1 text-xs font-bold text-slate-950 hover:bg-amber-400 cursor-pointer"
            >
              Race on This Highway
            </button>
          </div>
        </InfoWindow>
      )}
    </>
  );
};

interface MapWorkspaceProps {
  selectedHighway: SelectedMapHighway | null;
  onSelectHighway: (hw: SelectedMapHighway) => void;
  onRaceHere: (hw: SelectedMapHighway) => void;
}

const MapWorkspace: React.FC<MapWorkspaceProps> = ({
  selectedHighway,
  onSelectHighway,
  onRaceHere,
}) => {
  const map = useMap();
  const placesLib = useMapsLibrary('places');
  const loadingStatus = useApiLoadingStatus();

  const [query, setQuery] = useState('Mumbai Pune Expressway, India');
  const [results, setResults] = useState<SelectedMapHighway[]>(
    selectedHighway ? [selectedHighway] : []
  );
  const [activePlace, setActivePlace] = useState<SelectedMapHighway | null>(selectedHighway);
  const [searching, setSearching] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const runPlaceSearch = useCallback(
    async (textQuery: string) => {
      if (!placesLib || !textQuery.trim()) return;
      setSearching(true);
      setErrorMsg(null);
      try {
        const { places } = await placesLib.Place.searchByText({
          textQuery: textQuery.trim(),
          fields: ['id', 'displayName', 'formattedAddress', 'location'],
          maxResultCount: 5,
        });
        type PlaceLike = {
          id: string;
          displayName?: string | null;
          formattedAddress?: string | null;
          location?: { lat: () => number; lng: () => number } | null;
        };
        const rawPlaces = (places ?? []) as PlaceLike[];
        const mapped: SelectedMapHighway[] = rawPlaces
          .filter((p) => Boolean(p.location))
          .map((p) => ({
            id: p.id,
            name: p.displayName ?? textQuery,
            formattedAddress: p.formattedAddress ?? '',
            lat: p.location!.lat(),
            lng: p.location!.lng(),
          }));

        if (mapped.length === 0) {
          setErrorMsg('No matching highway or city found. Try another search.');
        } else {
          setResults(mapped);
          const first = mapped[0];
          setActivePlace(first);
          onSelectHighway(first);
          if (map) {
            map.panTo({ lat: first.lat, lng: first.lng });
            map.setZoom(11);
          }
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        if (
          msg.includes('OVER_QUERY_LIMIT') ||
          msg.includes('RESOURCE_EXHAUSTED') ||
          msg.includes('Quota')
        ) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        setErrorMsg('Could not load highway places right now. Check connection or try again.');
      } finally {
        setSearching(false);
      }
    },
    [placesLib, map, onSelectHighway]
  );

  // Trigger initial search once Places library is ready if no place is selected yet
  useEffect(() => {
    if (placesLib && results.length === 0) {
      runPlaceSearch('Mumbai Pune Expressway, India');
    }
  }, [placesLib, results.length, runPlaceSearch]);

  const handlePickResult = (place: SelectedMapHighway) => {
    setActivePlace(place);
    onSelectHighway(place);
    if (map) {
      map.panTo({ lat: place.lat, lng: place.lng });
      map.setZoom(12);
    }
  };

  if (
    loadingStatus === APILoadingStatus.FAILED ||
    loadingStatus === APILoadingStatus.AUTH_FAILURE
  ) {
    return (
      <div className="flex flex-1 items-center justify-center p-6 text-center text-xs text-slate-300">
        Unable to load Google Maps right now. You can still play all 500 levels offline.
      </div>
    );
  }

  return (
    <div className="grid min-h-0 flex-1 grid-cols-1 md:grid-cols-12">
      {/* Left Sidebar: Search & Quick Indian Highway Chips */}
      <div className="custom-scroll flex flex-col gap-3 overflow-y-auto border-b border-white/10 p-4 md:col-span-5 md:border-b-0 md:border-r">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            runPlaceSearch(query);
          }}
          className="flex items-center gap-2"
        >
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search any Indian highway or city..."
              className="w-full rounded-lg border border-white/12 bg-slate-900 py-2 pl-9 pr-3 text-xs text-white focus:border-amber-400 focus:outline-none"
            />
          </div>
          <button
            type="submit"
            disabled={searching}
            className="rounded-lg bg-amber-500 px-3.5 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400 disabled:opacity-50 whitespace-nowrap cursor-pointer"
          >
            {searching ? '...' : 'Find'}
          </button>
        </form>

        {/* Quick Preset Searches */}
        <div className="flex flex-wrap gap-1.5">
          {HIGHWAY_PRESET_QUERIES.map((preset) => (
            <button
              key={preset}
              type="button"
              onClick={() => {
                setQuery(preset);
                runPlaceSearch(preset);
              }}
              className="rounded-md border border-white/10 bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-slate-300 hover:border-amber-400/60 hover:text-white cursor-pointer"
            >
              {preset.replace(', India', '')}
            </button>
          ))}
        </div>

        {errorMsg && (
          <div className="rounded-lg border border-red-500/40 bg-red-950/35 px-3 py-2 text-xs text-red-200">
            {errorMsg}
          </div>
        )}

        {/* Live Places API (New) Results */}
        <div className="space-y-2">
          {results.map((place) => {
            const selected = activePlace?.id === place.id;
            return (
              <div
                key={place.id}
                onClick={() => handlePickResult(place)}
                className={`rounded-lg border p-3 transition-colors cursor-pointer ${
                  selected
                    ? 'border-amber-400/70 bg-slate-900 text-white'
                    : 'border-white/10 bg-slate-900/50 text-slate-300 hover:border-white/25'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-xs font-bold text-white">{place.name}</div>
                    <div className="mt-0.5 text-[11px] text-slate-400">
                      {place.formattedAddress}
                    </div>
                  </div>
                  <MapPin
                    className={`h-4 w-4 shrink-0 ${selected ? 'text-amber-400' : 'text-slate-500'}`}
                  />
                </div>
                {selected && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onRaceHere(place);
                    }}
                    className="font-display mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-md bg-amber-500 py-1.5 text-xs font-bold text-slate-950 hover:bg-amber-400 cursor-pointer"
                  >
                    <Play className="h-3.5 w-3.5 fill-slate-950" />
                    RACE ON THIS ROUTE
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Right: Interactive Google Map (explicit height so CF2 never collapses) */}
      <div className="relative h-[340px] w-full md:col-span-7 md:h-full">
        <GoogleMap
          mapId="DEMO_MAP_ID"
          defaultCenter={
            selectedHighway
              ? { lat: selectedHighway.lat, lng: selectedHighway.lng }
              : INDIA_DEFAULT_CENTER
          }
          defaultZoom={selectedHighway ? 11 : 5}
          gestureHandling="greedy"
          disableDefaultUI={false}
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          style={{ width: '100%', height: '100%' }}
        >
          {results.map((place) => (
            <HighwayPinItem
              key={place.id}
              place={place}
              isSelected={activePlace?.id === place.id}
              onSelect={handlePickResult}
              onRace={onRaceHere}
            />
          ))}
        </GoogleMap>
      </div>
    </div>
  );
};

export const RouteMapModal: React.FC<RouteMapModalProps> = ({
  selectedHighway,
  onSelectHighway,
  onRaceHere,
  onClose,
}) => {
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-slate-950/82 p-3 sm:p-6">
      <div className="flex h-[86vh] w-full max-w-5xl flex-col overflow-hidden rounded-xl border border-white/14 bg-slate-950 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
          <div className="flex items-center gap-2.5">
            <MapPin className="h-5 w-5 text-cyan-400" />
            <div>
              <h2 className="font-display text-xl font-bold tracking-wide text-white">
                REAL-WORLD HIGHWAY MAP
              </h2>
              <p className="text-xs text-slate-400">
                Search any Indian or global highway with Google Maps to set your race location
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close highway map"
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-slate-900 text-slate-300 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {apiKey ? (
          <APIProvider
            apiKey={apiKey}
            libraries={['places', 'marker']}
            language="en"
            region="IN"
          >
            <MapWorkspace
              selectedHighway={selectedHighway}
              onSelectHighway={onSelectHighway}
              onRaceHere={onRaceHere}
            />
          </APIProvider>
        ) : (
          <div className="flex flex-1 flex-col items-center justify-center gap-2 p-8 text-center">
            <MapPin className="h-8 w-8 text-slate-500" />
            <div className="text-sm font-semibold text-white">Google Maps Key Not Configured</div>
            <p className="max-w-md text-xs text-slate-400">
              Enable Google Maps in AI Studio settings to explore live highways on the map. All 500 career levels remain playable offline.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
