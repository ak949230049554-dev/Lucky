import React from 'react';
import {
  ArrowRight,
  Camera,
  Car,
  Code2,
  Home,
  Music,
  Play,
  RotateCcw,
  Trophy,
} from 'lucide-react';
import { CameraMode, RunSummary } from '../types/game';
import { TOTAL_LEVELS } from '../data/gameCatalog';

interface PauseModalProps {
  cameraMode: CameraMode;
  onSelectCamera: (mode: CameraMode) => void;
  onResume: () => void;
  onRestart: () => void;
  onOpenMusic: () => void;
  onOpenUnityGuide: () => void;
  onMainMenu: () => void;
}

const CAM_OPTIONS: { mode: CameraMode; label: string }[] = [
  { mode: 'chase', label: 'Chase' },
  { mode: 'bonnet', label: 'Hood' },
  { mode: 'wheel', label: 'Wheel' },
  { mode: 'topdown', label: 'Top-Down' },
];

export const PauseModal: React.FC<PauseModalProps> = ({
  cameraMode,
  onSelectCamera,
  onResume,
  onRestart,
  onOpenMusic,
  onOpenUnityGuide,
  onMainMenu,
}) => {
  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-slate-950/78 p-4">
      <div className="w-full max-w-md rounded-xl border border-white/14 bg-slate-950/96 p-6 shadow-2xl">
        <h2 className="font-display text-2xl font-bold tracking-wide text-white">RACE PAUSED</h2>
        <p className="mt-1 text-xs text-slate-400">
          Switch camera view or resume straight back onto the highway.
        </p>

        {/* Camera Mode Segmented Picker */}
        <div className="mt-5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300">
            <Camera className="h-3.5 w-3.5 text-amber-400" />
            <span>Camera Angle</span>
          </div>
          <div className="mt-2 grid grid-cols-4 gap-1.5 rounded-lg bg-slate-900 p-1">
            {CAM_OPTIONS.map((opt) => (
              <button
                key={opt.mode}
                type="button"
                onClick={() => onSelectCamera(opt.mode)}
                className={`rounded-md py-2 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                  cameraMode === opt.mode
                    ? 'bg-amber-500 text-slate-950'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="mt-6 flex flex-col gap-2.5">
          <button
            type="button"
            onClick={onResume}
            className="font-display flex w-full items-center justify-center gap-2 rounded-lg bg-amber-500 py-3 text-sm font-bold text-slate-950 hover:bg-amber-400 cursor-pointer"
          >
            <Play className="h-4 w-4 fill-slate-950" />
            RESUME RACE
          </button>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={onRestart}
              className="flex items-center justify-center gap-2 rounded-lg border border-white/12 bg-slate-900 py-2.5 text-xs font-semibold text-slate-100 hover:border-white/30 cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Restart
            </button>
            <button
              type="button"
              onClick={onMainMenu}
              className="flex items-center justify-center gap-2 rounded-lg border border-white/12 bg-slate-900 py-2.5 text-xs font-semibold text-slate-100 hover:border-white/30 cursor-pointer"
            >
              <Home className="h-3.5 w-3.5" />
              Main Menu
            </button>
          </div>

          <button
            type="button"
            onClick={onOpenMusic}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-rose-500/35 bg-rose-950/35 py-2.5 text-xs font-semibold text-rose-200 hover:bg-rose-950/55 cursor-pointer"
          >
            <Music className="h-3.5 w-3.5 text-rose-400" />
            Hindi Song & Car Radio
          </button>

          <button
            type="button"
            onClick={onOpenUnityGuide}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-emerald-500/30 bg-emerald-950/30 py-2.5 text-xs font-semibold text-emerald-300 hover:bg-emerald-950/50 cursor-pointer"
          >
            <Code2 className="h-3.5 w-3.5" />
            View Unity C# & 4MB APK Guide
          </button>
        </div>
      </div>
    </div>
  );
};

interface GameOverModalProps {
  summary: RunSummary;
  highScore: number;
  onRetry: () => void;
  onNextLevel?: () => void;
  onOpenGarage: () => void;
  onMainMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  summary,
  highScore,
  onRetry,
  onNextLevel,
  onOpenGarage,
  onMainMenu,
}) => {
  const canAdvanceLevel =
    summary.crashReason === 'finished' &&
    typeof summary.levelNumber === 'number' &&
    summary.levelNumber < TOTAL_LEVELS &&
    Boolean(onNextLevel);

  const headline =
    summary.crashReason === 'finished'
      ? summary.levelNumber
        ? `LEVEL ${summary.levelNumber} CLEARED!`
        : 'MISSION COMPLETE!'
      : summary.crashReason === 'police'
      ? 'BUSTED BY INTERCEPTOR'
      : 'WRECKED!';

  const totalCoins = summary.coinsEarned + summary.missionBonusCoins;
  const totalGems = summary.gemsEarned + summary.missionBonusGems;

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-slate-950/80 p-4">
      <div className="w-full max-w-lg rounded-xl border border-white/14 bg-slate-950/96 p-6 shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <div
              className={`text-xs font-semibold tracking-wider ${
                summary.crashReason === 'finished' ? 'text-emerald-400' : 'text-amber-400'
              }`}
            >
              {summary.missionTitle}
            </div>
            <h2 className="font-display mt-0.5 text-3xl font-bold tracking-wide text-white">
              {headline}
            </h2>
          </div>

          {summary.isNewHighScore && (
            <div className="flex items-center gap-1.5 rounded-lg border border-amber-400/50 bg-amber-500/15 px-3 py-1.5 text-xs font-bold text-amber-300">
              <Trophy className="h-4 w-4" />
              NEW BEST
            </div>
          )}
        </div>

        {/* Score & Best Score */}
        <div className="mt-4 flex items-baseline justify-between">
          <div>
            <div className="text-xs text-slate-400">FINAL SCORE</div>
            <div className="font-mono-num text-4xl font-bold text-white">
              {summary.score.toLocaleString()}
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs text-slate-400">ALL-TIME BEST</div>
            <div className="font-mono-num text-lg font-bold text-amber-300">
              {Math.max(highScore, summary.score).toLocaleString()}
            </div>
          </div>
        </div>

        {/* Clean Tabular Breakdown */}
        <div className="mt-5 grid grid-cols-2 gap-3 border-y border-white/10 py-4 text-xs sm:grid-cols-4">
          <div>
            <div className="text-slate-400">Distance</div>
            <div className="font-mono-num mt-0.5 text-base font-bold text-white">
              {summary.distanceM.toLocaleString()}m
            </div>
          </div>
          <div>
            <div className="text-slate-400">Drift Dist</div>
            <div className="font-mono-num mt-0.5 text-base font-bold text-white">
              {summary.driftDistanceM}m
            </div>
          </div>
          <div>
            <div className="text-slate-400">Near Misses</div>
            <div className="font-mono-num mt-0.5 text-base font-bold text-cyan-300">
              {summary.nearMisses}
            </div>
          </div>
          <div>
            <div className="text-slate-400">Earned</div>
            <div className="font-mono-num mt-0.5 text-base font-bold text-amber-300">
              +{totalCoins}C {totalGems > 0 ? `/ +${totalGems}G` : ''}
            </div>
          </div>
        </div>

        {summary.missionCompletedNow && (
          <div className="mt-4 rounded-lg border border-emerald-500/40 bg-emerald-950/35 px-4 py-2.5 text-xs font-medium text-emerald-200">
            Mission Bonus Awarded: +{summary.missionBonusCoins} Coins and +{summary.missionBonusGems} Gems banked offline!
          </div>
        )}

        {/* Primary & Secondary Actions */}
        <div className="mt-5 flex flex-col gap-2.5 sm:flex-row">
          {canAdvanceLevel && onNextLevel ? (
            <button
              type="button"
              onClick={onNextLevel}
              className="font-display flex flex-1 items-center justify-center gap-2 rounded-lg bg-emerald-500 py-3 text-sm font-bold text-slate-950 hover:bg-emerald-400 cursor-pointer"
            >
              NEXT LEVEL (LV. {(summary.levelNumber ?? 1) + 1})
              <ArrowRight className="h-4 w-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={onRetry}
              className="font-display flex flex-1 items-center justify-center gap-2 rounded-lg bg-amber-500 py-3 text-sm font-bold text-slate-950 hover:bg-amber-400 cursor-pointer"
            >
              <RotateCcw className="h-4 w-4" />
              RACE AGAIN
            </button>
          )}
          {canAdvanceLevel && (
            <button
              type="button"
              onClick={onRetry}
              className="flex items-center justify-center gap-2 rounded-lg border border-white/14 bg-slate-900 px-4 py-3 text-xs font-semibold text-white hover:border-amber-400/50 cursor-pointer"
            >
              <RotateCcw className="h-4 w-4 text-amber-400" />
              Replay
            </button>
          )}
          <button
            type="button"
            onClick={onOpenGarage}
            className="flex items-center justify-center gap-2 rounded-lg border border-white/14 bg-slate-900 px-4 py-3 text-xs font-semibold text-white hover:border-amber-400/50 cursor-pointer"
          >
            <Car className="h-4 w-4 text-amber-400" />
            Garage
          </button>
          <button
            type="button"
            onClick={onMainMenu}
            className="flex items-center justify-center gap-2 rounded-lg border border-white/14 bg-slate-900 px-4 py-3 text-xs font-semibold text-slate-200 hover:border-white/30 cursor-pointer"
          >
            <Home className="h-4 w-4" />
            Menu
          </button>
        </div>
      </div>
    </div>
  );
};
