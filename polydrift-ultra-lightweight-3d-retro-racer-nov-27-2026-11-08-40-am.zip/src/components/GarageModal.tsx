import React from 'react';
import { Check, ChevronLeft, ChevronRight, Lock, Wrench, X } from 'lucide-react';
import { CarSpec, CarUpgrades, SaveData } from '../types/game';
import { CAR_CATALOG, getCarEffectiveStats, getUpgradeCost, MAX_UPGRADE_LEVEL } from '../data/gameCatalog';

interface GarageModalProps {
  save: SaveData;
  viewingCarId: string;
  onSelectViewingCar: (carId: string) => void;
  onEquipCar: (carId: string) => void;
  onBuyCar: (car: CarSpec) => void;
  onUpgradeStat: (carId: string, stat: keyof CarUpgrades) => void;
  onClose: () => void;
  onRaceNow: () => void;
}

export const GarageModal: React.FC<GarageModalProps> = ({
  save,
  viewingCarId,
  onSelectViewingCar,
  onEquipCar,
  onBuyCar,
  onUpgradeStat,
  onClose,
  onRaceNow,
}) => {
  const index = Math.max(
    0,
    CAR_CATALOG.findIndex((c) => c.id === viewingCarId)
  );
  const car = CAR_CATALOG[index];
  const isUnlocked = save.unlockedCarIds.includes(car.id);
  const isEquipped = save.selectedCarId === car.id;
  const upgrades = save.upgrades[car.id] ?? { speed: 0, handling: 0, brakes: 0 };
  const stats = getCarEffectiveStats(car, upgrades);
  const canAffordCar = save.coins >= car.priceCoins && save.gems >= car.priceGems;

  const prevCar = () => {
    const nextIdx = (index - 1 + CAR_CATALOG.length) % CAR_CATALOG.length;
    onSelectViewingCar(CAR_CATALOG[nextIdx].id);
  };

  const nextCar = () => {
    const nextIdx = (index + 1) % CAR_CATALOG.length;
    onSelectViewingCar(CAR_CATALOG[nextIdx].id);
  };

  const upgradeRows: {
    key: keyof CarUpgrades;
    label: string;
    displayValue: string;
    percent: number;
  }[] = [
    {
      key: 'speed',
      label: 'Top Speed',
      displayValue: `${stats.topSpeedKmh} km/h`,
      percent: Math.min(100, (stats.topSpeedKmh / 355) * 100),
    },
    {
      key: 'handling',
      label: 'Handling & Drift',
      displayValue: `${stats.handling.toFixed(1)} / 10`,
      percent: stats.handling * 10,
    },
    {
      key: 'brakes',
      label: 'Brakes & Grip',
      displayValue: `${stats.brakes.toFixed(1)} / 10`,
      percent: stats.brakes * 10,
    },
  ];

  return (
    <div className="pointer-events-none fixed inset-0 z-20 flex flex-col justify-between p-4 sm:p-6">
      {/* Top Bar (keeps center 3D turntable car 100% visible) */}
      <div className="pointer-events-auto flex items-center justify-between gap-4">
        <div className="rounded-lg border border-white/12 bg-slate-950/90 px-4 py-2.5">
          <h2 className="font-display text-lg font-bold tracking-wide text-white">
            GARAGE & UPGRADES
          </h2>
          <p className="text-xs text-slate-400">
            Progress saved offline · Select car or tune Speed, Handling & Brakes
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-4 rounded-lg border border-white/12 bg-slate-950/90 px-4 py-2.5 text-xs font-semibold">
            <span className="tabular-nums text-amber-300">{save.coins.toLocaleString()} Coins</span>
            <span aria-hidden="true" className="text-slate-600">/</span>
            <span className="tabular-nums text-cyan-300">{save.gems.toLocaleString()} Gems</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close garage"
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/12 bg-slate-950/90 text-slate-200 hover:border-amber-400/60 hover:text-white cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Bottom Garage Workbench Dock */}
      <div className="pointer-events-auto mx-auto w-full max-w-4xl rounded-xl border border-white/14 bg-slate-950/92 p-4 sm:p-5 shadow-2xl">
        <div className="grid grid-cols-1 gap-5 md:grid-cols-12">
          {/* Left: Car Switcher & Purchase / Equip */}
          <div className="flex flex-col justify-between gap-4 md:col-span-5 md:border-r md:border-white/10 md:pr-5">
            <div>
              <div className="flex items-center justify-between gap-2">
                {CAR_CATALOG.length > 1 ? (
                  <button
                    type="button"
                    onClick={prevCar}
                    aria-label="Previous car"
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/12 bg-slate-900 text-slate-200 hover:border-amber-400/60 cursor-pointer"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                ) : (
                  <div className="w-2" />
                )}
                <div className={CAR_CATALOG.length > 1 ? 'text-center' : 'text-left flex-1'}>
                  <div className="text-[11px] font-medium text-amber-400">
                    {car.era}
                    {CAR_CATALOG.length > 1 ? ` · ${index + 1} / ${CAR_CATALOG.length}` : ''}
                  </div>
                  <h3 className="font-display text-xl font-bold text-white">{car.name}</h3>
                </div>
                {CAR_CATALOG.length > 1 && (
                  <button
                    type="button"
                    onClick={nextCar}
                    aria-label="Next car"
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/12 bg-slate-900 text-slate-200 hover:border-amber-400/60 cursor-pointer"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </button>
                )}
              </div>

              {/* Car Selector Dots (only when multiple cars exist) */}
              {CAR_CATALOG.length > 1 && (
                <div className="mt-3 flex items-center justify-center gap-2">
                  {CAR_CATALOG.map((c) => {
                    const active = c.id === car.id;
                    return (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => onSelectViewingCar(c.id)}
                        aria-label={c.name}
                        className={`h-2.5 rounded-full transition-all cursor-pointer ${
                          active ? 'w-7 bg-amber-400' : 'w-2.5 bg-slate-700 hover:bg-slate-500'
                        }`}
                      />
                    );
                  })}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              {isUnlocked ? (
                <>
                  <button
                    type="button"
                    onClick={() => onEquipCar(car.id)}
                    disabled={isEquipped}
                    className={`flex-1 rounded-lg px-4 py-2.5 text-sm font-semibold transition-colors whitespace-nowrap ${
                      isEquipped
                        ? 'border border-emerald-500/40 bg-emerald-500/15 text-emerald-300 cursor-default'
                        : 'bg-slate-800 text-white hover:bg-slate-700 cursor-pointer'
                    }`}
                  >
                    {isEquipped ? (
                      <span className="inline-flex items-center gap-1.5">
                        <Check className="h-4 w-4" /> Equipped
                      </span>
                    ) : (
                      'Equip Car'
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (!isEquipped) onEquipCar(car.id);
                      onRaceNow();
                    }}
                    className="font-display rounded-lg bg-amber-500 px-5 py-2.5 text-sm font-bold text-slate-950 hover:bg-amber-400 whitespace-nowrap cursor-pointer"
                  >
                    RACE
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  onClick={() => onBuyCar(car)}
                  disabled={!canAffordCar}
                  className={`flex w-full items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-bold transition-colors whitespace-nowrap ${
                    canAffordCar
                      ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 cursor-pointer'
                      : 'border border-white/10 bg-slate-900 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <Lock className="h-4 w-4" />
                  <span>
                    Unlock: {car.priceCoins.toLocaleString()} C
                    {car.priceGems > 0 ? ` + ${car.priceGems} G` : ''}
                  </span>
                </button>
              )}
            </div>
          </div>

          {/* Right: 3-Track Upgrade System */}
          <div className="flex flex-col justify-between gap-3 md:col-span-7">
            {upgradeRows.map((row) => {
              const lv = upgrades[row.key];
              const isMax = lv >= MAX_UPGRADE_LEVEL;
              const cost = getUpgradeCost(lv);
              const canUpgrade = isUnlocked && !isMax && save.coins >= cost;

              return (
                <div key={row.key} className="flex items-center justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-200">{row.label}</span>
                      <span className="font-mono-num text-slate-300">
                        {row.displayValue} · Lv.{lv + 1}/{MAX_UPGRADE_LEVEL + 1}
                      </span>
                    </div>
                    <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-slate-800">
                      <div
                        className="h-full bg-amber-400 transition-[width] duration-200"
                        style={{ width: `${row.percent}%` }}
                      />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onUpgradeStat(car.id, row.key)}
                    disabled={!canUpgrade}
                    className={`flex min-w-[112px] items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                      isMax
                        ? 'border border-emerald-500/30 bg-emerald-500/10 text-emerald-300 cursor-default'
                        : canUpgrade
                        ? 'bg-slate-800 text-amber-300 border border-amber-400/40 hover:bg-amber-500 hover:text-slate-950 cursor-pointer'
                        : 'border border-white/10 bg-slate-900 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    <Wrench className="h-3.5 w-3.5" />
                    {isMax ? 'MAXED' : `${cost} C`}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
