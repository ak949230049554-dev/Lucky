import React from 'react';
import { Check, Flame, Gift, X } from 'lucide-react';
import { SaveData } from '../types/game';
import { DAILY_REWARDS, getTodayKey } from '../data/gameCatalog';

interface DailyRewardsModalProps {
  save: SaveData;
  onClaimReward: () => void;
  onClose: () => void;
}

export const DailyRewardsModal: React.FC<DailyRewardsModalProps> = ({
  save,
  onClaimReward,
  onClose,
}) => {
  const today = getTodayKey();
  const canClaim = save.lastClaimDate !== today;
  const currentClaimIndex = save.dailyStreak % DAILY_REWARDS.length;

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-slate-950/75 p-4">
      <div className="w-full max-w-xl rounded-xl border border-white/14 bg-slate-950/96 p-5 shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-2.5">
            <Gift className="h-5 w-5 text-amber-400" />
            <div>
              <h2 className="font-display text-xl font-bold tracking-wide text-white">
                DAILY REWARDS
              </h2>
              <p className="text-xs text-slate-400">
                Streak Day {save.dailyStreak} · Saved offline for every visit
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close daily rewards"
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-slate-900 text-slate-300 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          {DAILY_REWARDS.map((item, idx) => {
            const isPast = idx < currentClaimIndex;
            const isToday = idx === currentClaimIndex;
            const isJackpot = item.day === 7;

            return (
              <div
                key={item.day}
                className={`flex flex-col justify-between rounded-lg border p-3 ${
                  isJackpot ? 'col-span-2' : ''
                } ${
                  isToday && canClaim
                    ? 'border-amber-400 bg-amber-500/15'
                    : isPast
                    ? 'border-emerald-500/30 bg-emerald-950/25'
                    : 'border-white/10 bg-slate-900/75'
                }`}
              >
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className={isToday && canClaim ? 'text-amber-300' : 'text-slate-300'}>
                    {item.label}
                  </span>
                  {isPast && <Check className="h-3.5 w-3.5 text-emerald-400" />}
                  {isJackpot && !isPast && <Flame className="h-3.5 w-3.5 text-amber-400" />}
                </div>
                <div className="mt-3 space-y-0.5 font-mono-num text-xs">
                  <div className="font-bold text-amber-300">+{item.coins} Coins</div>
                  <div className="font-semibold text-cyan-300">+{item.gems} Gems</div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-5 flex items-center justify-between gap-3 border-t border-white/10 pt-4">
          <p className="text-xs text-slate-400">
            {canClaim
              ? `Ready to claim Day ${currentClaimIndex + 1} reward!`
              : 'Today’s reward has been claimed. Come back tomorrow!'}
          </p>
          <button
            type="button"
            disabled={!canClaim}
            onClick={onClaimReward}
            className={`font-display rounded-lg px-5 py-2.5 text-sm font-bold whitespace-nowrap transition-colors ${
              canClaim
                ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 cursor-pointer'
                : 'border border-white/10 bg-slate-900 text-slate-500 cursor-not-allowed'
            }`}
          >
            {canClaim ? 'CLAIM REWARD' : 'CLAIMED TODAY'}
          </button>
        </div>
      </div>
    </div>
  );
};
