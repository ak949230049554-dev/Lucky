import React, { useRef, useState } from 'react';
import {
  Camera,
  CloudRain,
  Flame,
  Magnet,
  MapPin,
  Minus,
  Music,
  Pause,
  Plus,
  Shield,
  Sun,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { CameraMode, HudSnapshot, MissionDef, TouchDriveInput } from '../types/game';

interface HudOverlayProps {
  hud: HudSnapshot;
  mission: MissionDef;
  cameraMode: CameraMode;
  sfxMuted: boolean;
  musicMuted: boolean;
  activeSongLabel: string;
  highwayName?: string;
  onCycleCamera: () => void;
  onToggleSfx: () => void;
  onToggleMusic: () => void;
  onOpenMusic: () => void;
  onPause: () => void;
  onTouchControl: (input: TouchDriveInput) => void;
  onSetMaxSpeedKmh: (kmh: number) => void;
  onAdjustMaxSpeedKmh: (delta: number) => void;
}

const CAMERA_LABELS: Record<CameraMode, string> = {
  chase: 'Chase Cam',
  bonnet: 'Hood Cam',
  wheel: 'Wheel Cam',
  topdown: 'Top-Down',
};

const MAX_WHEEL_ROTATION_DEG = 135;

export const HudOverlay: React.FC<HudOverlayProps> = ({
  hud,
  mission,
  cameraMode,
  sfxMuted,
  musicMuted,
  activeSongLabel,
  highwayName,
  onCycleCamera,
  onToggleSfx,
  onToggleMusic,
  onOpenMusic,
  onPause,
  onTouchControl,
  onSetMaxSpeedKmh,
  onAdjustMaxSpeedKmh,
}) => {
  const touchStateRef = useRef<TouchDriveInput>({
    steer: 0,
    gas: false,
    brake: false,
    drift: false,
    nitro: false,
  });
  const wheelContainerRef = useRef<HTMLDivElement | null>(null);
  const dragPointerIdRef = useRef<number | null>(null);
  const prevPointerAngleRef = useRef(0);
  const prevPointerXRef = useRef(0);
  const accumWheelRadRef = useRef(0);
  const [draggingSteer, setDraggingSteer] = useState<number | null>(null);
  const [pedalPressed, setPedalPressed] = useState({ gas: false, brake: false, nitro: false });

  const updateTouch = (patch: Partial<TouchDriveInput>) => {
    touchStateRef.current = { ...touchStateRef.current, ...patch };
    onTouchControl({ ...touchStateRef.current });
  };

  const handlePedalDown = (
    key: 'gas' | 'brake' | 'nitro',
    e: React.PointerEvent<HTMLButtonElement>
  ) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    setPedalPressed((prev) => ({ ...prev, [key]: true }));
    updateTouch({ [key]: true });
  };

  const handlePedalUp = (
    key: 'gas' | 'brake' | 'nitro',
    e: React.PointerEvent<HTMLButtonElement>
  ) => {
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    setPedalPressed((prev) => ({ ...prev, [key]: false }));
    updateTouch({ [key]: false });
  };

  const computeWheelPointerAngle = (clientX: number, clientY: number): number => {
    const el = wheelContainerRef.current;
    if (!el) return 0;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width * 0.5;
    const cy = rect.top + rect.height * 0.5;
    return Math.atan2(clientY - cy, clientX - cx);
  };

  const MAX_WHEEL_RAD = (MAX_WHEEL_ROTATION_DEG * Math.PI) / 180;

  const handleWheelPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    dragPointerIdRef.current = e.pointerId;
    prevPointerXRef.current = e.clientX;
    prevPointerAngleRef.current = computeWheelPointerAngle(e.clientX, e.clientY);

    // If pressing left or right side of the rim, start turning immediately in that direction
    const rect = e.currentTarget.getBoundingClientRect();
    const relX = (e.clientX - (rect.left + rect.width * 0.5)) / (rect.width * 0.5);
    const relY = (e.clientY - (rect.top + rect.height * 0.5)) / (rect.height * 0.5);
    const initialSteer =
      Math.abs(relX) > 0.3 && Math.abs(relY) < 0.72
        ? Math.max(-1, Math.min(1, relX * 0.8))
        : 0;
    accumWheelRadRef.current = initialSteer * MAX_WHEEL_RAD;
    setDraggingSteer(initialSteer);
    updateTouch({ steer: initialSteer });
  };

  const handleWheelPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dragPointerIdRef.current !== e.pointerId) return;
    e.preventDefault();

    const el = wheelContainerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width * 0.5;
    const cy = rect.top + rect.height * 0.5;
    const distFromCenter = Math.hypot(e.clientX - cx, e.clientY - cy);

    const curAngle = computeWheelPointerAngle(e.clientX, e.clientY);
    const dx = e.clientX - prevPointerXRef.current;

    if (distFromCenter > rect.width * 0.14) {
      // Incremental unwrapped circular rotation: clockwise = right (+), counter-clockwise = left (-)
      let deltaAngle = curAngle - prevPointerAngleRef.current;
      while (deltaAngle > Math.PI) deltaAngle -= Math.PI * 2;
      while (deltaAngle < -Math.PI) deltaAngle += Math.PI * 2;
      accumWheelRadRef.current += deltaAngle * 1.15;
    } else {
      // Near center hub: smooth horizontal drag left/right
      accumWheelRadRef.current += (dx / (rect.width * 0.48)) * MAX_WHEEL_RAD;
    }

    prevPointerAngleRef.current = curAngle;
    prevPointerXRef.current = e.clientX;

    accumWheelRadRef.current = Math.max(
      -MAX_WHEEL_RAD,
      Math.min(MAX_WHEEL_RAD, accumWheelRadRef.current)
    );
    const nextSteer = accumWheelRadRef.current / MAX_WHEEL_RAD;
    setDraggingSteer(nextSteer);
    updateTouch({ steer: nextSteer });
  };

  const handleWheelPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dragPointerIdRef.current !== e.pointerId) return;
    dragPointerIdRef.current = null;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    accumWheelRadRef.current = 0;
    setDraggingSteer(null);
    updateTouch({ steer: 0 });
  };

  // Visual steering wheel rotation smoothly follows either active drag or keyboard steerNorm
  const visualSteer = draggingSteer !== null ? draggingSteer : hud.steerNorm;
  const wheelAngleDeg = visualSteer * MAX_WHEEL_ROTATION_DEG;

  // Speedometer SVG arc math (210-degree sweep)
  const arcRadius = 46;
  const arcCircumference = 2 * Math.PI * arcRadius;
  const sweepFraction = 0.65;
  const maxDash = arcCircumference * sweepFraction;
  const rpmFill = Math.max(0.05, Math.min(1, hud.rpmNorm)) * maxDash;

  const missionUnit =
    mission.goalType === 'coins'
      ? 'coins'
      : mission.goalType === 'police'
      ? 's'
      : 'm';

  const bannerColors = {
    amber: 'border-amber-400/70 bg-slate-950/90 text-amber-300',
    cyan: 'border-cyan-400/70 bg-slate-950/90 text-cyan-300',
    red: 'border-red-500/80 bg-red-950/90 text-red-200',
    emerald: 'border-emerald-400/70 bg-slate-950/90 text-emerald-300',
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-10 flex flex-col justify-between p-3 sm:p-5">
      {/* TOP PERIMETER CLUSTER */}
      <div className="flex items-start justify-between gap-3">
        {/* Top-Left: Score, Currencies & Mission Progress */}
        <div className="flex flex-col gap-2">
          <div className="rounded-lg border border-white/12 bg-slate-950/84 px-3.5 py-2.5 min-w-[205px]">
            <div className="flex items-baseline justify-between gap-4">
              <span className="text-[11px] font-semibold tracking-wider text-slate-400">SCORE</span>
              <span className="font-mono-num text-xl font-bold text-white">
                {hud.score.toLocaleString()}
              </span>
            </div>

            <div className="mt-1.5 flex items-center gap-3 text-xs tabular-nums text-slate-300">
              <span>{hud.distanceM.toLocaleString()} m</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="text-amber-300 font-semibold">{hud.runCoins} C</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="text-cyan-300 font-semibold">{hud.runGems} G</span>
            </div>

            {/* Mission / Distance goal bar */}
            <div className="mt-2 border-t border-white/10 pt-2">
              <div className="flex items-center justify-between gap-2 text-[11px] text-slate-300">
                <span className="truncate max-w-[138px] font-medium">
                  {mission.levelNumber ? `Lv.${mission.levelNumber}` : mission.title}
                  {mission.difficultyLabel ? ` · ${mission.difficultyLabel}` : ''}
                </span>
                <span className="font-mono-num text-amber-300 shrink-0">
                  {hud.missionCurrentValue}/{mission.targetValue}
                  {missionUnit}
                </span>
              </div>
              <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-amber-400 transition-[width] duration-150"
                  style={{ width: `${Math.round(hud.missionProgress * 100)}%` }}
                />
              </div>
              {highwayName && (
                <div className="mt-1.5 flex items-center gap-1 text-[10px] text-cyan-300 truncate max-w-[195px]">
                  <MapPin className="h-3 w-3 shrink-0" />
                  <span className="truncate">{highwayName}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Top-Center: Mini-Map / Road Radar + Weather/Time Readout */}
        <div className="hidden md:flex flex-col items-center gap-1.5">
          <div className="relative h-24 w-28 overflow-hidden rounded-lg border border-white/14 bg-slate-950/86">
            {/* Road lane guides */}
            <div className="absolute inset-y-0 left-1/4 w-px bg-white/10" />
            <div className="absolute inset-y-0 left-1/2 w-px bg-amber-400/35" />
            <div className="absolute inset-y-0 left-3/4 w-px bg-white/10" />

            {/* Ramp blips */}
            {hud.minimapBlips.map((b) => {
              const leftPct = 50 + b.laneNorm * 38;
              const topPct = Math.max(4, Math.min(94, 78 - b.relZ * 72));
              return (
                <div
                  key={b.id}
                  className="absolute -translate-x-1/2 -translate-y-1/2 rounded-[2px] h-2 w-2.5 bg-emerald-400"
                  style={{ left: `${leftPct}%`, top: `${topPct}%` }}
                />
              );
            })}

            {/* Player marker */}
            <div
              className="absolute h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-sm bg-amber-400"
              style={{ left: '50%', top: '78%' }}
            />
          </div>

          <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-200 drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]">
            {hud.weather === 'rain' ? (
              <CloudRain className="h-3.5 w-3.5 text-cyan-300" />
            ) : (
              <Sun className="h-3.5 w-3.5 text-amber-300" />
            )}
            <span>{hud.timeOfDayLabel}</span>
            <span aria-hidden="true" className="text-slate-400">·</span>
            <span className="capitalize">{hud.weather}</span>
          </div>
        </div>

        {/* Top-Right: Multi-Camera Switcher, Audio & Pause Controls */}
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            type="button"
            onClick={onCycleCamera}
            className="flex h-10 items-center gap-2 rounded-lg border border-white/14 bg-slate-950/86 px-3 text-xs font-semibold text-slate-100 transition-colors hover:border-amber-400/60 hover:text-amber-300 whitespace-nowrap cursor-pointer"
          >
            <Camera className="h-4 w-4 text-amber-400" />
            <span>{CAMERA_LABELS[cameraMode]}</span>
            <span className="font-mono-num text-[10px] text-slate-400">[C]</span>
          </button>

          <button
            type="button"
            onClick={onToggleSfx}
            aria-label={sfxMuted ? 'Unmute SFX' : 'Mute SFX'}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/14 bg-slate-950/86 text-slate-200 transition-colors hover:border-white/30 cursor-pointer"
          >
            {sfxMuted ? (
              <VolumeX className="h-4 w-4 text-slate-500" />
            ) : (
              <Volume2 className="h-4 w-4 text-amber-400" />
            )}
          </button>

          <button
            type="button"
            onClick={onOpenMusic}
            title={`Hindi Song Player: ${activeSongLabel}`}
            className="hidden sm:flex h-10 items-center gap-1.5 rounded-lg border border-white/14 bg-slate-950/86 px-3 text-xs font-semibold text-slate-100 transition-colors hover:border-rose-400/60 hover:text-rose-200 whitespace-nowrap cursor-pointer"
          >
            <Music className={`h-4 w-4 ${musicMuted ? 'text-slate-500' : 'text-rose-400'}`} />
            <span className="max-w-[105px] truncate">{activeSongLabel}</span>
          </button>

          <button
            type="button"
            onClick={onToggleMusic}
            aria-label={musicMuted ? 'Unmute Music' : 'Mute Music'}
            className="flex sm:hidden h-10 w-10 items-center justify-center rounded-lg border border-white/14 bg-slate-950/86 text-slate-200 transition-colors hover:border-white/30 cursor-pointer"
          >
            <Music className={`h-4 w-4 ${musicMuted ? 'text-slate-500' : 'text-rose-400'}`} />
          </button>

          <button
            type="button"
            onClick={onPause}
            aria-label="Pause game"
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/14 bg-slate-950/86 text-slate-100 transition-colors hover:border-amber-400/60 cursor-pointer"
          >
            <Pause className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* CENTER-TOP TRANSIENT EVENT BANNER (Ramp / Power-up / Drift) */}
      <div className="flex flex-col items-center gap-1.5">
        {hud.bannerText && (
          <div
            className={`font-display rounded-lg border px-4 py-1.5 text-sm font-bold tracking-wider shadow-lg ${bannerColors[hud.bannerTone]}`}
          >
            {hud.bannerText}
          </div>
        )}
        {hud.isDrifting && (
          <div className="font-display rounded-lg border border-amber-400/60 bg-slate-950/88 px-3.5 py-1 text-xs font-bold tracking-wider text-amber-300 tabular-nums">
            DRIFTING +{hud.driftScore}
          </div>
        )}
      </div>

      {/* BOTTOM PERIMETER CLUSTER */}
      <div className="flex items-end justify-between gap-4">
        {/* Bottom-Left: Active Power-ups + Responsive Interactive Steering Wheel */}
        <div className="flex flex-col items-start gap-2.5">
          {(hud.magnetTimer > 0 || hud.shieldActive) && (
            <div className="flex items-center gap-2">
              {hud.magnetTimer > 0 && (
                <div className="flex items-center gap-1.5 rounded-lg border border-rose-400/60 bg-slate-950/88 px-3 py-1.5 text-xs font-semibold text-rose-200 tabular-nums">
                  <Magnet className="h-3.5 w-3.5 text-rose-400" />
                  <span>Magnet {hud.magnetTimer.toFixed(1)}s</span>
                </div>
              )}
              {hud.shieldActive && (
                <div className="flex items-center gap-1.5 rounded-lg border border-cyan-400/60 bg-slate-950/88 px-3 py-1.5 text-xs font-semibold text-cyan-200">
                  <Shield className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Shield Armed</span>
                </div>
              )}
            </div>
          )}

          {/* Responsive On-Screen Steering Wheel (Mouse/Touch Drag + Keyboard Sync) */}
          <div className="pointer-events-auto flex flex-col items-center gap-1">
            <div
              ref={wheelContainerRef}
              role="slider"
              aria-label="Steering wheel"
              aria-valuemin={-100}
              aria-valuemax={100}
              aria-valuenow={Math.round(visualSteer * 100)}
              onPointerDown={handleWheelPointerDown}
              onPointerMove={handleWheelPointerMove}
              onPointerUp={handleWheelPointerUp}
              onPointerCancel={handleWheelPointerUp}
              className={`relative flex h-28 w-28 sm:h-32 sm:w-32 items-center justify-center rounded-full border bg-slate-950/82 shadow-xl touch-none select-none cursor-grab active:cursor-grabbing transition-colors ${
                draggingSteer !== null
                  ? 'border-amber-400/80'
                  : 'border-white/15 hover:border-amber-400/50'
              }`}
            >
              {/* Static outer directional indicator marks */}
              <span className="pointer-events-none absolute left-2 text-[9px] font-bold tracking-wider text-slate-400">
                L
              </span>
              <span className="pointer-events-none absolute right-2 text-[9px] font-bold tracking-wider text-slate-400">
                R
              </span>

              {/* Rotating Sport Racing Steering Wheel SVG */}
              <svg
                viewBox="0 0 120 120"
                className="pointer-events-none h-[88%] w-[88%]"
                style={{
                  transform: `rotate(${wheelAngleDeg.toFixed(1)}deg)`,
                  transition:
                    draggingSteer !== null ? 'none' : 'transform 75ms linear',
                }}
              >
                <defs>
                  <linearGradient id="swSpokeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#94a3b8" />
                    <stop offset="50%" stopColor="#475569" />
                    <stop offset="100%" stopColor="#1e293b" />
                  </linearGradient>
                </defs>

                {/* Outer leather/carbon rim */}
                <circle
                  cx="60"
                  cy="60"
                  r="48"
                  fill="none"
                  stroke="#0f172a"
                  strokeWidth="14"
                />
                <circle
                  cx="60"
                  cy="60"
                  r="48"
                  fill="none"
                  stroke="#334155"
                  strokeWidth="10"
                />
                <circle
                  cx="60"
                  cy="60"
                  r="48"
                  fill="none"
                  stroke="#1e293b"
                  strokeWidth="6"
                />

                {/* Top 12-o'clock racing centering stripe */}
                <path
                  d="M 55 11.5 A 48 48 0 0 1 65 11.5"
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="10"
                  strokeLinecap="butt"
                />

                {/* 9-o'clock & 3-o'clock textured grip bolsters */}
                <path
                  d="M 14 48 A 48 48 0 0 0 14 72"
                  fill="none"
                  stroke="#ef4444"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
                <path
                  d="M 106 48 A 48 48 0 0 1 106 72"
                  fill="none"
                  stroke="#ef4444"
                  strokeWidth="3"
                  strokeLinecap="round"
                />

                {/* 3-Spoke sport frame */}
                <path
                  d="M 16 56 L 46 56 L 46 65 L 16 64 Z"
                  fill="url(#swSpokeGrad)"
                />
                <path
                  d="M 104 56 L 74 56 L 74 65 L 104 64 Z"
                  fill="url(#swSpokeGrad)"
                />
                <path
                  d="M 54 72 L 66 72 L 64 104 L 56 104 Z"
                  fill="url(#swSpokeGrad)"
                />

                {/* Center horn hub */}
                <circle
                  cx="60"
                  cy="60"
                  r="17"
                  fill="#0f172a"
                  stroke="#64748b"
                  strokeWidth="2.5"
                />
                <circle cx="60" cy="60" r="9" fill="#1e293b" stroke="#f59e0b" strokeWidth="1.5" />
                <polygon points="60,55 64,63 56,63" fill="#f59e0b" />
              </svg>
            </div>
            <span className="text-[10px] font-semibold tracking-wider text-slate-300 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
              STEER · DRAG OR A / D
            </span>
          </div>
        </div>

        {/* Bottom-Right: Gas & Brake/Reverse Pedals + Live Speedometer & Max Speed Adjuster */}
        <div className="flex items-end gap-2.5 sm:gap-3">
          {/* On-Screen Gas & Brake/Reverse Pedals (Mouse/Touch Hold + W/S & Up/Down Sync) */}
          <div className="pointer-events-auto flex items-end gap-2">
            {/* Brake / Reverse Pedal */}
            <button
              type="button"
              aria-label="Brake or Reverse"
              onPointerDown={(e) => handlePedalDown('brake', e)}
              onPointerUp={(e) => handlePedalUp('brake', e)}
              onPointerCancel={(e) => handlePedalUp('brake', e)}
              className={`relative flex h-24 w-16 sm:h-28 sm:w-[70px] flex-col items-center justify-between rounded-xl border px-2 py-2.5 touch-none select-none cursor-pointer transition-transform ${
                pedalPressed.brake || hud.brakeActive
                  ? 'translate-y-0.5 border-rose-400 bg-rose-950/92 text-rose-100 shadow-[0_0_16px_rgba(244,63,94,0.35)]'
                  : 'border-white/16 bg-slate-950/88 text-slate-200 hover:border-rose-400/60'
              }`}
            >
              <span className="text-[10px] font-bold tracking-wider text-rose-300">
                {hud.isReversing ? 'REV' : 'BRAKE'}
              </span>
              {/* Metallic pedal tread bars */}
              <div className="flex w-full flex-col gap-1.5 px-1">
                <span className="h-1.5 w-full rounded-full bg-slate-700/90" />
                <span className="h-1.5 w-full rounded-full bg-slate-700/90" />
                <span className="h-1.5 w-full rounded-full bg-slate-700/90" />
              </div>
              <span className="font-mono-num text-[9px] font-semibold text-slate-400">
                S / ↓
              </span>
            </button>

            {/* Gas (Accelerate) Pedal */}
            <button
              type="button"
              aria-label="Gas Accelerate"
              onPointerDown={(e) => handlePedalDown('gas', e)}
              onPointerUp={(e) => handlePedalUp('gas', e)}
              onPointerCancel={(e) => handlePedalUp('gas', e)}
              className={`relative flex h-28 w-16 sm:h-32 sm:w-[74px] flex-col items-center justify-between rounded-xl border px-2 py-2.5 touch-none select-none cursor-pointer transition-transform ${
                pedalPressed.gas || hud.gasActive
                  ? 'translate-y-0.5 border-emerald-400 bg-emerald-950/92 text-emerald-100 shadow-[0_0_16px_rgba(16,185,129,0.35)]'
                  : 'border-white/16 bg-slate-950/88 text-slate-200 hover:border-emerald-400/60'
              }`}
            >
              <span className="text-[10px] font-bold tracking-wider text-emerald-300">
                GAS
              </span>
              {/* Sport accelerator pedal ribs */}
              <div className="flex w-full flex-col gap-1.5 px-1">
                <span className="h-1.5 w-full rounded-full bg-emerald-500/35" />
                <span className="h-1.5 w-full rounded-full bg-emerald-500/35" />
                <span className="h-1.5 w-full rounded-full bg-emerald-500/35" />
                <span className="h-1.5 w-full rounded-full bg-emerald-500/35" />
              </div>
              <span className="font-mono-num text-[9px] font-semibold text-slate-400">
                W / ↑
              </span>
            </button>
          </div>

          {/* Live Speedometer + Max Speed Slider / +/- Controls + Nitro Boost */}
          <div className="pointer-events-auto rounded-xl border border-white/14 bg-slate-950/90 p-3 w-[196px] sm:w-[214px] shadow-xl">
            <div className="relative flex items-center justify-center">
              <svg viewBox="0 0 116 84" className="h-[78px] w-[116px]">
                {/* Background RPM arc */}
                <circle
                  cx="58"
                  cy="58"
                  r={arcRadius}
                  fill="none"
                  stroke="rgba(148,163,184,0.22)"
                  strokeWidth="8"
                  strokeDasharray={`${maxDash} ${arcCircumference}`}
                  strokeLinecap="round"
                  transform="rotate(153 58 58)"
                />
                {/* Active RPM arc */}
                <circle
                  cx="58"
                  cy="58"
                  r={arcRadius}
                  fill="none"
                  stroke={
                    hud.isReversing
                      ? '#f43f5e'
                      : hud.isBoosting
                      ? '#22d3ee'
                      : hud.rpmNorm > 0.85
                      ? '#ef4444'
                      : '#f59e0b'
                  }
                  strokeWidth="8"
                  strokeDasharray={`${rpmFill} ${arcCircumference}`}
                  strokeLinecap="round"
                  transform="rotate(153 58 58)"
                />
              </svg>

              <div className="absolute inset-x-0 bottom-0.5 flex flex-col items-center">
                <span className="font-mono-num text-3xl font-bold leading-none text-white">
                  {hud.speedKmh}
                </span>
                <div className="mt-0.5 flex items-center gap-1.5 text-[10px] font-semibold tracking-wider text-slate-400">
                  <span>KM/H</span>
                  <span aria-hidden="true">·</span>
                  <span
                    className={
                      hud.isReversing
                        ? 'text-rose-400 font-bold'
                        : hud.gearLabel === 'N'
                        ? 'text-slate-300'
                        : 'text-amber-400'
                    }
                  >
                    {hud.gearLabel}
                  </span>
                </div>
              </div>
            </div>

            {/* Live Max Speed Adjustment Control (- / Slider / +) */}
            <div className="mt-2 border-t border-white/10 pt-2">
              <div className="flex items-center justify-between text-[10px] font-semibold tracking-wider">
                <span className="text-slate-400">TOP SPEED</span>
                <span className="font-mono-num text-amber-300">
                  {hud.maxSpeedKmh} km/h
                </span>
              </div>
              <div className="mt-1.5 flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={(e) => {
                    onAdjustMaxSpeedKmh(-20);
                    e.currentTarget.blur();
                  }}
                  aria-label="Decrease max speed"
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md border border-white/14 bg-slate-900 text-slate-200 hover:border-amber-400/70 hover:text-amber-300 active:bg-slate-800 cursor-pointer"
                >
                  <Minus className="h-3.5 w-3.5" />
                </button>
                <input
                  type="range"
                  min={40}
                  max={360}
                  step={10}
                  value={hud.maxSpeedKmh}
                  aria-label="Max speed limit in km/h"
                  onChange={(e) => onSetMaxSpeedKmh(Number(e.target.value))}
                  onPointerUp={(e) => e.currentTarget.blur()}
                  className="h-1.5 w-full cursor-pointer accent-amber-400"
                />
                <button
                  type="button"
                  onClick={(e) => {
                    onAdjustMaxSpeedKmh(20);
                    e.currentTarget.blur();
                  }}
                  aria-label="Increase max speed"
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md border border-white/14 bg-slate-900 text-slate-200 hover:border-amber-400/70 hover:text-amber-300 active:bg-slate-800 cursor-pointer"
                >
                  <Plus className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* Nitro Tank Bar + Press-to-Boost Trigger */}
            <div className="mt-2 border-t border-white/10 pt-2">
              <button
                type="button"
                aria-label="Nitro boost"
                onPointerDown={(e) => handlePedalDown('nitro', e)}
                onPointerUp={(e) => handlePedalUp('nitro', e)}
                onPointerCancel={(e) => handlePedalUp('nitro', e)}
                className="w-full text-left touch-none select-none cursor-pointer"
              >
                <div className="flex items-center justify-between text-[10px] font-semibold tracking-wider">
                  <span className="flex items-center gap-1 text-cyan-300">
                    <Flame className="h-3 w-3" />
                    NITRO
                  </span>
                  <span className="font-mono-num text-slate-300">{hud.nitro}%</span>
                </div>
                <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-slate-800">
                  <div
                    className={`h-full transition-[width] duration-100 ${
                      pedalPressed.nitro || hud.isBoosting ? 'bg-cyan-300' : 'bg-cyan-500'
                    }`}
                    style={{ width: `${hud.nitro}%` }}
                  />
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
