import React, { useRef } from 'react';
import {
  Disc3,
  Music,
  Pause,
  Play,
  SkipBack,
  SkipForward,
  Trash2,
  Upload,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { HindiTrackId, SaveData, UploadedSong } from '../types/game';
import { HINDI_TRACK_PRESETS } from '../data/gameCatalog';

interface HindiMusicModalProps {
  save: SaveData;
  isRadioPlaying: boolean;
  uploadedSongs: UploadedSong[];
  activeUploadedId: string | null;
  isUploadedPlaying: boolean;
  onSelectPresetTrack: (trackId: HindiTrackId) => void;
  onToggleRadioPreview: () => void;
  onUploadSongs: (files: FileList) => void;
  onPlayUploadedSong: (song: UploadedSong) => void;
  onToggleUploadedPause: () => void;
  onSkipUploaded: (dir: -1 | 1) => void;
  onRemoveUploadedSong: (id: string) => void;
  onVolumeChange: (vol: number) => void;
  onToggleMusicMute: () => void;
  onClose: () => void;
}

export const HindiMusicModal: React.FC<HindiMusicModalProps> = ({
  save,
  isRadioPlaying,
  uploadedSongs,
  activeUploadedId,
  isUploadedPlaying,
  onSelectPresetTrack,
  onToggleRadioPreview,
  onUploadSongs,
  onPlayUploadedSong,
  onToggleUploadedPause,
  onSkipUploaded,
  onRemoveUploadedSong,
  onVolumeChange,
  onToggleMusicMute,
  onClose,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const activeUploaded = uploadedSongs.find((s) => s.id === activeUploadedId) ?? null;

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-slate-950/80 p-4">
      <div className="flex max-h-[88vh] w-full max-w-2xl flex-col overflow-hidden rounded-xl border border-white/14 bg-slate-950/98 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
          <div className="flex items-center gap-2.5">
            <Music className="h-5 w-5 text-amber-400" />
            <div>
              <h2 className="font-display text-xl font-bold tracking-wide text-white">
                HINDI SONG & CAR RADIO
              </h2>
              <p className="text-xs text-slate-400">
                Play built-in Desi Highway beats or load your own Hindi MP3 songs while racing
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Hindi music player"
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-slate-900 text-slate-300 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="custom-scroll flex-1 space-y-5 overflow-y-auto p-5">
          {/* Master Music Volume & Mute Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-white/10 bg-slate-900/75 px-4 py-3">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onToggleMusicMute}
                className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/12 bg-slate-950 text-slate-200 hover:border-amber-400/60 cursor-pointer"
              >
                {save.musicMuted ? (
                  <VolumeX className="h-4 w-4 text-slate-500" />
                ) : (
                  <Volume2 className="h-4 w-4 text-amber-400" />
                )}
              </button>
              <div>
                <div className="text-xs font-semibold text-white">
                  {activeUploaded
                    ? `Your Song: ${activeUploaded.name}`
                    : HINDI_TRACK_PRESETS.find((t) => t.id === save.selectedHindiTrackId)?.title ??
                      'Desi Highway Beat'}
                </div>
                <div className="text-[11px] text-slate-400">
                  {save.musicMuted
                    ? 'Music muted'
                    : activeUploaded && isUploadedPlaying
                    ? 'Playing your custom Hindi audio'
                    : isRadioPlaying
                    ? 'Car Radio ON'
                    : 'Plays automatically when you start racing'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <span className="text-[11px] font-semibold text-slate-400">Volume</span>
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(save.musicVolume * 100)}
                onChange={(e) => onVolumeChange(Number(e.target.value) / 100)}
                className="h-1.5 w-28 accent-amber-400 cursor-pointer"
              />
              <span className="font-mono-num w-9 text-right text-xs text-slate-300">
                {Math.round(save.musicVolume * 100)}%
              </span>
            </div>
          </div>

          {/* Section 1: Play Your Own Hindi MP3 / Audio Files */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h3 className="font-display text-sm font-bold tracking-wide text-amber-300">
                  YOUR HINDI SONGS (MP3 / WAV / M4A)
                </h3>
                <p className="text-[11px] text-slate-400">
                  Pick any Hindi songs from your phone or PC to play inside the car stereo
                </p>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="audio/*"
                multiple
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    onUploadSongs(e.target.files);
                    e.target.value = '';
                  }
                }}
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-3.5 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400 whitespace-nowrap cursor-pointer"
              >
                <Upload className="h-3.5 w-3.5" />
                Add Hindi Song
              </button>
            </div>

            {uploadedSongs.length > 0 ? (
              <div className="space-y-2">
                {activeUploaded && (
                  <div className="flex items-center justify-between rounded-lg border border-amber-400/45 bg-amber-500/10 px-3.5 py-2.5">
                    <div className="min-w-0 pr-3">
                      <div className="truncate text-xs font-bold text-amber-200">
                        {activeUploaded.name}
                      </div>
                      <div className="text-[11px] text-amber-300/80">
                        {isUploadedPlaying ? 'Playing in Car Stereo' : 'Paused'}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => onSkipUploaded(-1)}
                        aria-label="Previous song"
                        className="flex h-8 w-8 items-center justify-center rounded-md border border-white/10 bg-slate-900 text-slate-200 hover:text-white cursor-pointer"
                      >
                        <SkipBack className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={onToggleUploadedPause}
                        aria-label={isUploadedPlaying ? 'Pause song' : 'Play song'}
                        className="flex h-8 w-8 items-center justify-center rounded-md bg-amber-500 text-slate-950 hover:bg-amber-400 cursor-pointer"
                      >
                        {isUploadedPlaying ? (
                          <Pause className="h-3.5 w-3.5 fill-slate-950" />
                        ) : (
                          <Play className="h-3.5 w-3.5 fill-slate-950" />
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => onSkipUploaded(1)}
                        aria-label="Next song"
                        className="flex h-8 w-8 items-center justify-center rounded-md border border-white/10 bg-slate-900 text-slate-200 hover:text-white cursor-pointer"
                      >
                        <SkipForward className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                )}

                <div className="space-y-1.5">
                  {uploadedSongs.map((song) => {
                    const active = song.id === activeUploadedId;
                    return (
                      <div
                        key={song.id}
                        className={`flex items-center justify-between rounded-lg border px-3 py-2 text-xs ${
                          active
                            ? 'border-amber-400/50 bg-slate-900 text-white'
                            : 'border-white/10 bg-slate-900/50 text-slate-300'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => onPlayUploadedSong(song)}
                          className="flex min-w-0 flex-1 items-center gap-2 text-left cursor-pointer"
                        >
                          <Play className="h-3.5 w-3.5 text-amber-400 shrink-0" />
                          <span className="truncate font-medium">{song.name}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onRemoveUploadedSong(song.id)}
                          aria-label={`Remove ${song.name}`}
                          className="ml-2 p-1 text-slate-500 hover:text-red-400 cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="rounded-lg border border-dashed border-white/15 bg-slate-900/40 px-4 py-4 text-center text-xs text-slate-400">
                No local Hindi MP3 added yet — click <strong className="text-slate-200">Add Hindi Song</strong> to play any track from your device, or pick a built-in Desi Radio station below.
              </div>
            )}
          </div>

          {/* Section 2: Built-in Hindi / Desi Highway Radio Stations */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-sm font-bold tracking-wide text-cyan-300">
                BUILT-IN DESI HIGHWAY RADIO (OFFLINE · 0 KB)
              </h3>
              <button
                type="button"
                onClick={onToggleRadioPreview}
                className="flex items-center gap-1.5 rounded-lg border border-white/12 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:border-cyan-400/50 cursor-pointer"
              >
                {isRadioPlaying && !activeUploaded ? (
                  <>
                    <Pause className="h-3.5 w-3.5 text-amber-400" /> Stop Preview
                  </>
                ) : (
                  <>
                    <Play className="h-3.5 w-3.5 text-cyan-400" /> Preview Radio
                  </>
                )}
              </button>
            </div>

            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {HINDI_TRACK_PRESETS.map((track) => {
                const selected = !activeUploaded && save.selectedHindiTrackId === track.id;
                return (
                  <button
                    key={track.id}
                    type="button"
                    onClick={() => onSelectPresetTrack(track.id)}
                    className={`flex items-start justify-between gap-2 rounded-lg border p-3 text-left transition-colors cursor-pointer ${
                      selected
                        ? 'border-amber-400/70 bg-slate-900 text-white'
                        : 'border-white/10 bg-slate-900/50 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <Disc3
                          className={`h-4 w-4 shrink-0 ${
                            selected ? 'text-amber-400' : 'text-slate-500'
                          }`}
                        />
                        <span className="font-semibold text-xs text-white">{track.title}</span>
                      </div>
                      <div className="mt-0.5 text-xs text-amber-300/90">{track.hindiTitle}</div>
                      <div className="mt-1 text-[11px] text-slate-400">
                        {track.vibe} · {track.bpm} BPM
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
