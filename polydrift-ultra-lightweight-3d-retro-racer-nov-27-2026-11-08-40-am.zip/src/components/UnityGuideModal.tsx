import React, { useState } from 'react';
import { Check, Code2, Copy, Cpu, X } from 'lucide-react';
import { UNITY_BUILD_STEPS, UNITY_CSHARP_SCRIPTS } from '../data/unityBlueprint';

interface UnityGuideModalProps {
  onClose: () => void;
}

export const UnityGuideModal: React.FC<UnityGuideModalProps> = ({ onClose }) => {
  const [tab, setTab] = useState<'scripts' | 'setup'>('scripts');
  const [selectedScriptId, setSelectedScriptId] = useState(UNITY_CSHARP_SCRIPTS[0].id);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const activeScript =
    UNITY_CSHARP_SCRIPTS.find((s) => s.id === selectedScriptId) ?? UNITY_CSHARP_SCRIPTS[0];

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopiedId(id);
    window.setTimeout(() => setCopiedId(null), 1600);
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-3 sm:p-6">
      <div className="flex h-[90vh] w-full max-w-5xl flex-col overflow-hidden rounded-xl border border-white/14 bg-slate-950 shadow-2xl">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-5 py-4">
          <div>
            <h2 className="font-display text-xl font-bold tracking-wide text-white">
              UNITY 3D C# ARCHITECTURE & 4MB APK SETUP GUIDE
            </h2>
            <p className="text-xs text-slate-400">
              Production scripts and Android build pipeline for 60 FPS on 2GB RAM devices (Target APK: 4MB–8MB)
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 rounded-lg bg-slate-900 p-1">
              <button
                type="button"
                onClick={() => setTab('scripts')}
                className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                  tab === 'scripts'
                    ? 'bg-amber-500 text-slate-950'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Code2 className="h-3.5 w-3.5" />
                C# Scripts & Shader
              </button>
              <button
                type="button"
                onClick={() => setTab('setup')}
                className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                  tab === 'setup'
                    ? 'bg-amber-500 text-slate-950'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Cpu className="h-3.5 w-3.5" />
                4MB APK & 2GB RAM Guide
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close Unity guide"
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-slate-900 text-slate-300 hover:text-white cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        {tab === 'scripts' ? (
          <div className="grid min-h-0 flex-1 grid-cols-1 md:grid-cols-12">
            {/* Script Sidebar */}
            <div className="custom-scroll flex gap-1.5 overflow-x-auto border-b border-white/10 p-3 md:col-span-4 md:flex-col md:overflow-y-auto md:border-b-0 md:border-r">
              {UNITY_CSHARP_SCRIPTS.map((script) => {
                const active = script.id === activeScript.id;
                return (
                  <button
                    key={script.id}
                    type="button"
                    onClick={() => setSelectedScriptId(script.id)}
                    className={`rounded-lg border px-3 py-2.5 text-left transition-colors shrink-0 cursor-pointer ${
                      active
                        ? 'border-amber-400/60 bg-slate-900 text-white'
                        : 'border-transparent bg-slate-900/40 text-slate-300 hover:bg-slate-900/80'
                    }`}
                  >
                    <div className="font-mono-num text-xs font-semibold text-amber-300">
                      {script.filename}
                    </div>
                    <div className="mt-0.5 text-[11px] text-slate-400">{script.category}</div>
                  </button>
                );
              })}
            </div>

            {/* Code Pane */}
            <div className="flex min-h-0 flex-col md:col-span-8">
              <div className="flex items-center justify-between gap-3 border-b border-white/10 bg-slate-900/60 px-4 py-3">
                <div>
                  <div className="font-mono-num text-xs font-semibold text-white">
                    {activeScript.filename}
                  </div>
                  <p className="text-[11px] text-slate-400">{activeScript.summary}</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(activeScript.id, activeScript.code)}
                  className="flex items-center gap-1.5 rounded-lg border border-white/12 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:border-amber-400/50 hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {copiedId === activeScript.id ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-400" /> Copied
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" /> Copy C#
                    </>
                  )}
                </button>
              </div>
              <pre className="custom-scroll flex-1 overflow-auto bg-[#070b13] p-4 font-mono-num text-xs leading-relaxed text-slate-200 select-text">
                <code>{activeScript.code}</code>
              </pre>
            </div>
          </div>
        ) : (
          <div className="custom-scroll flex-1 overflow-y-auto p-5">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              {UNITY_BUILD_STEPS.map((item) => (
                <div
                  key={item.step}
                  className="rounded-lg border border-white/10 bg-slate-900/65 p-4"
                >
                  <div className="flex items-baseline justify-between gap-2">
                    <h3 className="font-display text-base font-bold text-white">
                      {item.step}. {item.title}
                    </h3>
                  </div>
                  <div className="mt-1 text-xs font-semibold text-emerald-400">
                    {item.budgetImpact}
                  </div>
                  <ul className="mt-3 space-y-2 text-xs leading-relaxed text-slate-300">
                    {item.details.map((line, i) => (
                      <li key={i} className="flex gap-2">
                        <span className="text-amber-400 font-bold">·</span>
                        <span>{line}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <div className="mt-5 rounded-lg border border-amber-400/30 bg-amber-950/20 p-4 text-xs leading-relaxed text-slate-200">
              <div className="font-display text-sm font-bold text-amber-300">
                RECOMMENDED APK SIZE BREAKDOWN (TOTAL ~5.4 MB)
              </div>
              <p className="mt-1.5 text-slate-300">
                Stripped Unity IL2CPP ARMv7 Runtime (LZ4HC): ~4.4 MB · Vertex-Colored Low-Poly Meshes (5 cars + road + traffic + props): ~320 KB · 1 Baked Garage Lightmap (256x256 ETC2): ~64 KB · 4 Mono Vorbis Audio Clips (&lt;45 KB each): ~140 KB · UI + C# Logic: ~450 KB.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
