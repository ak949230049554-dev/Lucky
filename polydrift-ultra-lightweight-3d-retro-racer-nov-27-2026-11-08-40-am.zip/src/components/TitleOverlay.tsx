import React from 'react';
import {
  Car,
  Code2,
  Gift,
  Layers,
  MapPin,
  Music,
  Play,
  Trophy,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { CarSpec, MissionDef, SaveData } from '../types/game';
import { getTodayKey, TOTAL_LEVELS } from '../data/gameCatalog';

interface TitleOverlayProps {
  save: SaveData;
  selectedCar: CarSpec;
  selectedMission: MissionDef;
  activeSongLabel: string;
  onStartRace: () => void;
  onOpenGarage: () => void;
  onOpenLevels: () => void;
  onOpenMusic: () => void;
  onOpenMap: () => void;
  onOpenRewards: () => void;
  onOpenUnityGuide: () => void;
  onToggleAudio: () => void;
}

export const TitleOverlay: React.FC<TitleOverlayProps> = ({
  save,
  selectedCar,
  selectedMission,
  activeSongLabel,
  onStartRace,
  onOpenGarage,
  onOpenLevels,
  onOpenMusic,
  onOpenMap,
  onOpenRewards,
  onOpenUnityGuide,
  onToggleAudio,
}) => {
  const canClaimDaily = save.lastClaimDate !== getTodayKey();
  const audioOff = save.sfxMuted && save.musicMuted;

  return (
    <div className="pointer-events-none fixed inset-0 z-10 flex flex-col justify-between p-5 sm:p-8">
      {/* Top Bar: Quiet Currency Readout + Audio Toggle */}
      <div className="flex items-start justify-between gap-4">
        {/* Bespoke inline SVG Title Lockup positioned over calm upper-left space */}
        <div className="flex flex-col gap-2">
          <svg
            viewBox="0 0 360 76"
            className="h-12 w-auto sm:h-16 drop-shadow-[0_4px_14px_rgba(0,0,0,0.65)]"
            aria-label="PolyDrift 3D Retro Racer"
          >
            <defs>
              <linearGradient id="pdSunGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fde047" />
                <stop offset="52%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#ef4444" />
              </linearGradient>
              <linearGradient id="pdMetalGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="55%" stopColor="#e2e8f0" />
                <stop offset="100%" stopColor="#94a3b8" />
              </linearGradient>
            </defs>
            {/* Geometric speed chevrons */}
            <polygon points="8,54 24,18 36,18 20,54" fill="#f59e0b" />
            <polygon points="26,54 42,18 50,18 34,54" fill="#ef4444" />
            {/* Main wordmark */}
            <text
              x="58"
              y="48"
              fill="url(#pdMetalGrad)"
              fontFamily="'Chakra Petch', sans-serif"
              fontWeight="700"
              fontStyle="italic"
              fontSize="44"
              letterSpacing="1.5"
            >
              POLY
            </text>
            <text
              x="176"
              y="48"
              fill="url(#pdSunGrad)"
              fontFamily="'Chakra Petch', sans-serif"
              fontWeight="700"
              fontStyle="italic"
              fontSize="44"
              letterSpacing="1.5"
            >
              DRIFT
            </text>
            <rect x="58" y="56" width="268" height="3" fill="url(#pdSunGrad)" />
            <text
              x="58"
              y="71"
              fill="#cbd5e1"
              fontFamily="'JetBrains Mono', monospace"
              fontWeight="600"
              fontSize="11"
              letterSpacing="2.4"
            >
              RETRO LOW-POLY 3D RACER · 500 LEVELS
            </text>
          </svg>

          <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-200 drop-shadow-[0_2px_4px_rgba(0,0,0,0.85)]">
            <span className="text-amber-300 font-semibold">{selectedCar.name}</span>
            <span aria-hidden="true" className="text-slate-400">·</span>
            <span>
              {selectedMission.levelNumber
                ? `Level ${selectedMission.levelNumber} / ${TOTAL_LEVELS}`
                : selectedMission.title}
            </span>
            {selectedMission.difficultyLabel && (
              <>
                <span aria-hidden="true" className="text-slate-400">·</span>
                <span className="text-emerald-300 font-semibold">
                  {selectedMission.difficultyLabel}
                </span>
              </>
            )}
            {save.selectedHighway && (
              <>
                <span aria-hidden="true" className="text-slate-400">·</span>
                <span className="inline-flex items-center gap-1 text-cyan-300">
                  <MapPin className="h-3 w-3" />
                  {save.selectedHighway.name}
                </span>
              </>
            )}
            {save.highScore > 0 && (
              <>
                <span aria-hidden="true" className="text-slate-400">·</span>
                <span className="inline-flex items-center gap-1 tabular-nums text-slate-100">
                  <Trophy className="h-3.5 w-3.5 text-amber-400" />
                  Best {save.highScore.toLocaleString()}
                </span>
              </>
            )}
          </div>
        </div>

        {/* Right Wallet + Audio */}
        <div className="pointer-events-auto flex items-center gap-3">
          <div className="flex items-center gap-4 rounded-lg border border-white/12 bg-slate-950/85 px-4 py-2 text-xs font-semibold">
            <div className="flex items-center gap-1.5 tabular-nums text-amber-300">
              <span className="inline-block h-2.5 w-2.5 rounded-full bg-amber-400" />
              <span>{save.coins.toLocaleString()}</span>
              <span className="text-slate-400 font-normal">Coins</span>
            </div>
            <span aria-hidden="true" className="text-slate-600">/</span>
            <div className="flex items-center gap-1.5 tabular-nums text-cyan-300">
              <span className="inline-block h-2.5 w-2.5 rotate-45 bg-cyan-400" />
              <span>{save.gems.toLocaleString()}</span>
              <span className="text-slate-400 font-normal">Gems</span>
            </div>
          </div>

          <button
            type="button"
            onClick={onToggleAudio}
            aria-label={audioOff ? 'Unmute audio' : 'Mute audio'}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/12 bg-slate-950/85 text-slate-200 transition-colors hover:border-amber-400/60 hover:text-white cursor-pointer"
          >
            {audioOff ? <VolumeX className="h-4 w-4 text-slate-400" /> : <Volume2 className="h-4 w-4 text-amber-400" />}
          </button>
        </div>
      </div>

      {/* Bottom Unified Action Dock (keeps center 3D car showcase completely unobstructed) */}
      <div className="flex flex-col items-center gap-3">
        <div className="pointer-events-auto flex flex-wrap items-center justify-center gap-2 rounded-xl border border-white/12 bg-slate-950/90 p-2.5 shadow-2xl">
          <button
            type="button"
            onClick={onStartRace}
            className="font-display flex items-center gap-2.5 rounded-lg bg-amber-500 px-6 py-3 text-base font-bold tracking-wide text-slate-950 transition-transform duration-150 hover:bg-amber-400 active:scale-[0.98] whitespace-nowrap cursor-pointer"
          >
            <Play className="h-4 w-4 fill-slate-950" />
            {selectedMission.levelNumber ? `RACE LV.${selectedMission.levelNumber}` : 'RACE NOW'}
          </button>

          <button
            type="button"
            onClick={onOpenLevels}
            className="flex items-center gap-2 rounded-lg border border-white/10 bg-slate-900/90 px-3.5 py-3 text-sm font-semibold text-slate-100 transition-colors hover:border-cyan-400/50 hover:bg-slate-800 whitespace-nowrap cursor-pointer"
          >
            <Layers className="h-4 w-4 text-cyan-400" />
            Levels 1–500
          </button>

          <button
            type="button"
            onClick={onOpenMusic}
            className="flex items-center gap-2 rounded-lg border border-white/10 bg-slate-900/90 px-3.5 py-3 text-sm font-semibold text-slate-100 transition-colors hover:border-rose-400/50 hover:bg-slate-800 whitespace-nowrap cursor-pointer"
          >
            <Music className="h-4 w-4 text-rose-400" />
            <span className="max-w-[130px] truncate">{activeSongLabel}</span>
          </button>

          <button
            type="button"
            onClick={onOpenMap}
            className="flex items-center gap-2 rounded-lg border border-white/10 bg-slate-900/90 px-3.5 py-3 text-sm font-semibold text-slate-100 transition-colors hover:border-emerald-400/50 hover:bg-slate-800 whitespace-nowrap cursor-pointer"
          >
            <MapPin className="h-4 w-4 text-emerald-400" />
            Highway Map
          </button>

          <button
            type="button"
            onClick={onOpenGarage}
            className="flex items-center gap-2 rounded-lg border border-white/10 bg-slate-900/90 px-3.5 py-3 text-sm font-semibold text-slate-100 transition-colors hover:border-amber-400/50 hover:bg-slate-800 whitespace-nowrap cursor-pointer"
          >
            <Car className="h-4 w-4 text-amber-400" />
            Garage
          </button>

          <button
            type="button"
            onClick={onOpenRewards}
            className={`flex items-center gap-2 rounded-lg border px-3.5 py-3 text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer ${
              canClaimDaily
                ? 'border-amber-400/70 bg-amber-500/15 text-amber-200 hover:bg-amber-500/25'
                : 'border-white/10 bg-slate-900/90 text-slate-100 hover:border-white/25 hover:bg-slate-800'
            }`}
          >
            <Gift className="h-4 w-4 text-amber-400" />
            {canClaimDaily ? 'Daily Gift' : 'Rewards'}
          </button>

          <button
            type="button"
            onClick={onOpenUnityGuide}
            className="flex items-center gap-2 rounded-lg border border-white/10 bg-slate-900/90 px-3.5 py-3 text-sm font-semibold text-slate-200 transition-colors hover:border-emerald-400/50 hover:bg-slate-800 whitespace-nowrap cursor-pointer"
          >
            <Code2 className="h-4 w-4 text-emerald-400" />
            Unity C#
          </button>
        </div>

        {/* Single flat control-hint line */}
        <p className="text-center text-xs font-medium tracking-wide text-slate-200 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
          A / D or Arrows Steer · S / Down Drift · Space / Shift Nitro · C Camera · Esc Pause · Enter Start
        </p>
      </div>
    </div>
  );
};
