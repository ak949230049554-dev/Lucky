import React, { useState } from 'react';
import { Check, CloudRain, Infinity as InfinityIcon, Play, Search, Siren, Sun, X } from 'lucide-react';
import { MissionDef, SaveData } from '../types/game';
import {
  ENDLESS_MISSION,
  getChapterForLevel,
  getLevelDef,
  LEVEL_CHAPTERS,
  TOTAL_LEVELS,
} from '../data/gameCatalog';

interface LevelsModalProps {
  save: SaveData;
  activeMission: MissionDef;
  onSelectMission: (mission: MissionDef) => void;
  onStartMission: (mission: MissionDef) => void;
  onClose: () => void;
}

export const LevelsModal: React.FC<LevelsModalProps> = ({
  save,
  activeMission,
  onSelectMission,
  onStartMission,
  onClose,
}) => {
  const initialLevel = activeMission.levelNumber ?? save.selectedLevel ?? 1;
  const [chapterIdx, setChapterIdx] = useState<number>(
    getChapterForLevel(initialLevel).index
  );
  const [previewLevel, setPreviewLevel] = useState<number>(initialLevel);
  const [jumpInput, setJumpInput] = useState<string>(String(initialLevel));

  const chapter = LEVEL_CHAPTERS[chapterIdx] ?? LEVEL_CHAPTERS[0];
  const selectedDef = getLevelDef(previewLevel);
  const completedSet = new Set(save.completedLevels);

  const levelNumbers: number[] = [];
  for (let lv = chapter.startLevel; lv <= chapter.endLevel; lv++) {
    levelNumbers.push(lv);
  }

  const handlePickLevel = (lv: number) => {
    const clamped = Math.max(1, Math.min(TOTAL_LEVELS, lv));
    setPreviewLevel(clamped);
    setJumpInput(String(clamped));
    setChapterIdx(getChapterForLevel(clamped).index);
    onSelectMission(getLevelDef(clamped));
  };

  const handleJumpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseInt(jumpInput, 10);
    if (!Number.isNaN(parsed)) {
      handlePickLevel(parsed);
    }
  };

  const tierColor = (tier?: string) => {
    switch (tier) {
      case 'Halka (Easy)':
        return 'text-emerald-300';
      case 'Easy':
        return 'text-lime-300';
      case 'Medium':
        return 'text-amber-300';
      case 'Hard':
        return 'text-orange-300';
      case 'Pro':
        return 'text-rose-300';
      default:
        return 'text-purple-300';
    }
  };

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-slate-950/80 p-3 sm:p-5">
      <div className="flex max-h-[90vh] w-full max-w-4xl flex-col overflow-hidden rounded-xl border border-white/14 bg-slate-950/98 shadow-2xl">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-5 py-4">
          <div>
            <h2 className="font-display text-xl font-bold tracking-wide text-white">
              CAREER LEVELS 1 – {TOTAL_LEVELS}
            </h2>
            <p className="text-xs text-slate-400">
              Level 1 starts Halka (Easy) and smoothly ramps up to Level 500 · Cleared{' '}
              <span className="font-mono-num text-amber-300">
                {save.completedLevels.length}/{TOTAL_LEVELS}
              </span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Direct Level Jump 1-500 */}
            <form onSubmit={handleJumpSubmit} className="flex items-center gap-1.5">
              <div className="relative">
                <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                <input
                  type="number"
                  min={1}
                  max={TOTAL_LEVELS}
                  value={jumpInput}
                  onChange={(e) => setJumpInput(e.target.value)}
                  aria-label="Jump to level 1 to 500"
                  placeholder="1-500"
                  className="w-24 rounded-lg border border-white/12 bg-slate-900 py-1.5 pl-8 pr-2 font-mono-num text-xs text-white focus:border-amber-400 focus:outline-none"
                />
              </div>
              <button
                type="submit"
                className="rounded-lg border border-white/12 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:border-amber-400/60 hover:text-white cursor-pointer"
              >
                Go
              </button>
            </form>

            <button
              type="button"
              onClick={() => onStartMission(ENDLESS_MISSION)}
              className="flex items-center gap-1.5 rounded-lg border border-cyan-400/40 bg-cyan-950/40 px-3 py-1.5 text-xs font-semibold text-cyan-200 hover:bg-cyan-900/50 whitespace-nowrap cursor-pointer"
            >
              <InfinityIcon className="h-3.5 w-3.5" />
              Endless Mode
            </button>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close levels"
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-slate-900 text-slate-300 hover:text-white cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Chapter Range Tabs (10 chapters x 50 levels = 500) */}
        <div className="custom-scroll flex items-center gap-1.5 overflow-x-auto border-b border-white/10 bg-slate-900/50 px-5 py-2.5">
          {LEVEL_CHAPTERS.map((ch) => {
            const active = ch.index === chapterIdx;
            return (
              <button
                key={ch.index}
                type="button"
                onClick={() => {
                  setChapterIdx(ch.index);
                  setPreviewLevel(ch.startLevel);
                  setJumpInput(String(ch.startLevel));
                  onSelectMission(getLevelDef(ch.startLevel));
                }}
                className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'bg-amber-500 text-slate-950'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                Lv {ch.startLevel}–{ch.endLevel}
              </button>
            );
          })}
        </div>

        {/* Selected Level Preview Strip */}
        <div className="flex flex-col gap-3 border-b border-white/10 bg-slate-900/75 px-5 py-3.5 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-display text-lg font-bold text-white">
                {selectedDef.title}
              </span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className={`text-xs font-semibold ${tierColor(selectedDef.difficultyLabel)}`}>
                {selectedDef.difficultyLabel}
              </span>
              {selectedDef.policeFromStart && (
                <>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-red-400">
                    <Siren className="h-3.5 w-3.5" /> Police Boss
                  </span>
                </>
              )}
            </div>
            <p className="text-xs text-slate-300">{selectedDef.subtitle}</p>
            <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400">
              <span className="inline-flex items-center gap-1 capitalize">
                {selectedDef.weather === 'rain' ? (
                  <CloudRain className="h-3.5 w-3.5 text-cyan-400" />
                ) : (
                  <Sun className="h-3.5 w-3.5 text-amber-400" />
                )}
                {selectedDef.timePreset === 'cycle' ? 'Day/Night' : selectedDef.timePreset} ·{' '}
                {selectedDef.weather}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-num text-slate-300">
                Pace {Math.round((selectedDef.speedScale ?? 1) * 100)}%
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-num text-amber-300">
                Reward +{selectedDef.rewardCoins} C / +{selectedDef.rewardGems} G
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onStartMission(selectedDef)}
            className="font-display flex items-center justify-center gap-2 rounded-lg bg-amber-500 px-6 py-2.5 text-sm font-bold text-slate-950 hover:bg-amber-400 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Play className="h-4 w-4 fill-slate-950" />
            PLAY LEVEL {previewLevel}
          </button>
        </div>

        {/* 50-Level Paginated Grid */}
        <div className="custom-scroll flex-1 overflow-y-auto p-5">
          <div className="mb-3 flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold text-slate-200">
              Chapter {chapter.index + 1}: {chapter.name}
            </span>
            <span>Click any level to select · Double-click to race</span>
          </div>

          <div className="grid grid-cols-5 gap-2 sm:grid-cols-10">
            {levelNumbers.map((lv) => {
              const isSelected = lv === previewLevel;
              const isCleared = completedSet.has(lv);
              const isPoliceBoss =
                (lv >= 20 && lv % 10 === 0) || (lv >= 351 && lv <= 400 && lv % 3 === 0);

              return (
                <button
                  key={lv}
                  type="button"
                  onClick={() => handlePickLevel(lv)}
                  onDoubleClick={() => onStartMission(getLevelDef(lv))}
                  className={`relative flex h-12 flex-col items-center justify-center rounded-lg border font-mono-num text-xs font-bold transition-colors cursor-pointer ${
                    isSelected
                      ? 'border-amber-400 bg-amber-500 text-slate-950'
                      : isCleared
                      ? 'border-emerald-500/45 bg-emerald-950/35 text-emerald-200 hover:border-emerald-400'
                      : isPoliceBoss
                      ? 'border-red-500/40 bg-red-950/25 text-red-200 hover:border-red-400'
                      : 'border-white/10 bg-slate-900/75 text-slate-200 hover:border-amber-400/50 hover:text-white'
                  }`}
                >
                  <span>{lv}</span>
                  {lv === 1 && !isCleared && (
                    <span
                      className={`text-[9px] font-sans font-semibold leading-none ${
                        isSelected ? 'text-slate-900' : 'text-emerald-400'
                      }`}
                    >
                      Halka
                    </span>
                  )}
                  {isCleared && (
                    <Check
                      className={`h-3 w-3 ${isSelected ? 'text-slate-950' : 'text-emerald-400'}`}
                    />
                  )}
                  {!isCleared && isPoliceBoss && (
                    <Siren
                      className={`h-3 w-3 ${isSelected ? 'text-slate-950' : 'text-red-400'}`}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
