export type CameraMode = 'chase' | 'bonnet' | 'wheel' | 'topdown';

export type WeatherMode = 'sunny' | 'rain';

export type TimePreset = 'cycle' | 'day' | 'sunset' | 'night';

export type GameScreen = 'title' | 'playing' | 'paused' | 'gameover';

export type ModalView = 'none' | 'garage' | 'levels' | 'rewards' | 'music' | 'map' | 'unity';

export type CarBodyStyle = 'hatch' | 'coupe' | 'tuner' | 'wedge' | 'hyper';

export type HindiTrackId =
  | 'desi_highway'
  | 'punjabi_dhol'
  | 'mumbai_lofi'
  | 'retro_90s'
  | 'arcade_synth';

export interface HindiTrackPreset {
  id: HindiTrackId;
  title: string;
  hindiTitle: string;
  vibe: string;
  bpm: number;
}

export interface UploadedSong {
  id: string;
  name: string;
  url: string;
}

export interface SelectedMapHighway {
  id: string;
  name: string;
  formattedAddress: string;
  lat: number;
  lng: number;
}

export interface CarSpec {
  id: string;
  name: string;
  era: string;
  style: CarBodyStyle;
  primaryColor: string;
  accentColor: string;
  stripeColor: string;
  rimColor: string;
  priceCoins: number;
  priceGems: number;
  baseTopSpeed: number; // km/h display ceiling
  baseHandling: number; // 1 - 10 scale
  baseBrakes: number; // 1 - 10 scale
}

export interface CarUpgrades {
  speed: number; // 0..4 (Level 1..5)
  handling: number; // 0..4
  brakes: number; // 0..4
}

export type MissionGoalType = 'coins' | 'drift' | 'distance' | 'police' | 'endless';

export type DifficultyTier = 'Halka (Easy)' | 'Easy' | 'Medium' | 'Hard' | 'Pro' | 'Legend';

export interface MissionDef {
  id: string;
  title: string;
  subtitle: string;
  goalType: MissionGoalType;
  targetValue: number;
  rewardCoins: number;
  rewardGems: number;
  timePreset: TimePreset;
  weather: WeatherMode | 'dynamic';
  policeFromStart: boolean;
  difficulty: number; // 1..6
  levelNumber?: number; // 1..500 when part of 500-level career
  chapterName?: string;
  difficultyLabel?: DifficultyTier;
  speedScale?: number; // 0.72 (Lv 1 halka) -> 1.48 (Lv 500)
  trafficGapScale?: number; // 1.5 (Lv 1 wide gaps) -> 0.58 (Lv 500)
  maxTrafficWave?: number; // 1 at early easy levels, 2 mid, 3 hard
}

export interface DailyRewardDay {
  day: number;
  coins: number;
  gems: number;
  label: string;
}

export interface SaveData {
  coins: number;
  gems: number;
  highScore: number;
  bestDistance: number;
  selectedCarId: string;
  unlockedCarIds: string[];
  upgrades: Record<string, CarUpgrades>;
  completedMissionIds: string[];
  completedLevels: number[];
  selectedLevel: number;
  highestLevelUnlocked: number;
  dailyStreak: number; // 0..7
  lastClaimDate: string | null; // YYYY-MM-DD
  sfxMuted: boolean;
  musicMuted: boolean;
  musicVolume: number; // 0..1
  selectedHindiTrackId: HindiTrackId;
  cameraMode: CameraMode;
  selectedHighway: SelectedMapHighway | null;
}

export interface MinimapBlip {
  id: number;
  laneNorm: number; // -1..1
  relZ: number; // 0..1 ahead, negative behind
  kind: 'traffic' | 'police' | 'ramp' | 'powerup';
}

export interface TouchDriveInput {
  steer: number; // -1..1 continuous analog from steering wheel
  gas: boolean;
  brake: boolean;
  drift: boolean;
  nitro: boolean;
}

export interface HudSnapshot {
  speedKmh: number;
  maxSpeedKmh: number;
  rpmNorm: number; // 0..1
  gear: number;
  gearLabel: string; // 'R' | 'N' | '1'..'6'
  isReversing: boolean;
  gasActive: boolean;
  brakeActive: boolean;
  score: number;
  distanceM: number;
  runCoins: number;
  runGems: number;
  nitro: number; // 0..100
  isBoosting: boolean;
  isDrifting: boolean;
  driftScore: number;
  driftDistanceM: number;
  isAirborne: boolean;
  magnetTimer: number;
  shieldActive: boolean;
  policeActive: boolean;
  policeDistanceM: number;
  policeSurviveSec: number;
  wantedStars: number;
  nearMissCount: number;
  timeOfDayLabel: string;
  weather: WeatherMode;
  missionProgress: number; // 0..1
  missionCurrentValue: number;
  missionComplete: boolean;
  bannerText: string | null;
  bannerTone: 'amber' | 'cyan' | 'red' | 'emerald';
  minimapBlips: MinimapBlip[];
  playerLaneNorm: number;
  steerNorm: number;
}

export interface RunSummary {
  score: number;
  isNewHighScore: boolean;
  distanceM: number;
  coinsEarned: number;
  gemsEarned: number;
  nearMisses: number;
  driftDistanceM: number;
  missionCompletedNow: boolean;
  missionBonusCoins: number;
  missionBonusGems: number;
  missionTitle: string;
  levelNumber?: number;
  crashReason: 'traffic' | 'police' | 'finished';
}
